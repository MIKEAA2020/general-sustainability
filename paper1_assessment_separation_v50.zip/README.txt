Aggregate Indices and Transition Safety: A Quantifier-Order Separation
Between Scalarized and Coordinate-Wise Feasibility
(A. Abaee - submission source package)

Package contents
- paper1_assessment_separation_v50.tex : LaTeX source (elsarticle). Compiles
  with tectonic, pdflatex, or xelatex.
- paper1_assessment_separation_v50.pdf : compiled paper (34 pp.).
- figs_p1/ : the four manuscript figures (PNG, deposited copies).
- graphical_abstract/ : graphical abstract (PDF/PNG/TIFF).

Supplementary material (S1-S12) ships separately as
paper1_safetransition_ems_supplementary_v6.md.
Verification deposit: https://doi.org/10.6084/m9.figshare.33764023
(verification/typed_false_positive_instantiation.py re-runs the 25 exact
grid checks; stdlib only, ~36 s). Software companion: SafeTransition 1.3.0
(EMS submission v8: SafeTransition).
