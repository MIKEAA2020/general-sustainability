Stochastic-selector paper v1 source package: "The Stochastic Selector:
Exact Rational Belief-State Safety Values under Partial Observation" (the
D1 theory of the obstruction programme: piecewise-linear value iteration
with rational alpha-vectors, deterministic-limit degeneration, deficit
bounds for the companion certificates, and the certificate-value agreement
theorem on the audited classes), plus the exact-arithmetic verification
script (10 check families; standard library).
Run: python3 paper2_stochastic_selector_v1_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
