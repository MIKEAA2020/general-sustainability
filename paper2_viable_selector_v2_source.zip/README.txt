Viable-selector paper v2 source package (layout repair release; content
identical to v1): main tex+pdf and the unchanged exact-arithmetic
verification script (7 check families).
Run: python3 paper2_viable_selector_v1_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
