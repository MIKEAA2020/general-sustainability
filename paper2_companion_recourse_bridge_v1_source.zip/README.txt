Companion paper v1 source package: "Finite Nonviability Certificates under
Delayed Information" (main + supplementary with complete proofs and the
verification record), plus two exact-arithmetic verification scripts:
paper2c_lp_campaign.py (solver-certified mesh campaign; regenerates the mesh
table verbatim; 9 checks) and paper2_nonstandard_verification.py (51 checks).
Run: python3 paper2c_lp_campaign.py; python3 paper2_nonstandard_verification.py
(scipy required for the campaign; standard library otherwise).
Mirror: https://github.com/MIKEAA2020/general-sustainability
