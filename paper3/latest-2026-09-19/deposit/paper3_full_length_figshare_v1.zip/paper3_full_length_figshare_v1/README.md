# Full-length Figshare-ready deposit

**Working package:** paper3 full-length line, with journal-specific cuts and a route-C prototype.
**Source line:** v49, 2026-09-19. **License:** CC BY 4.0 for the author's manuscript and accompanying
original code, subject to the third-party notices and source restrictions recorded below.

## Contents

- `manuscript/`: the four full-length documents, each in Markdown, LaTeX and PDF where applicable;
- `code/`: the executable reproduction exhibits, manifests and recorded outputs;
- `analysis/nfa_tau/`: the overshoot-date recomputation, derived tables, checksums and source manifest;
- `journal_variants/`: the 6,000-word JIE cut, 8,000-word Ecological Economics cut, technical proof
  supplement, diagram and route-C prototype;
- `metadata.json`: proposed Figshare metadata;
- `CHECKSUMS.sha256`: checksums of every file in this deposit.

## Boundaries and omissions

This deposit preserves the full-length article and its provenance. The 16 MB third-party National
Footprint and Biocapacity Accounts source tables are **not copied**. Their source manifest and checksums
remain in `analysis/nfa_tau/source/`; the publisher's licence and retrieval conditions are recorded in
the analysis README and the full-length data-availability statement. No third-party table is silently
redistributed here.

The route-C implementation is a tested reference prototype, not yet a supported software package. It
implements typed declarations, incidence construction, balance residuals, componentwise barriers and a
non-compensation witness. It does not claim the complete eight-predicate solver or a production API.

The journal cuts are derived working surfaces. The full-length v49 manuscript remains the authoritative
complete article. A journal-specific mathematical edit must be made in the full-length source first and
then re-extracted and re-verified.

## Reproduction

The full-length build record and current v49 archive remain in the workspace. The code exhibits run with
the environment recorded in `code/MANIFEST.md`. The journal-variant gate is rerun with:

```sh
python3 journal_variants/validate_journal_variants.py
python3 -m pytest -q journal_variants/route_c_prototype/test_typed_ledger.py
```

The zip digest belongs in the Figshare record or the sidecar next to the downloadable zip, not in a file
inside the zip.
