An Obstruction Calculus for Viability under Incomplete Observation
(paper 2, version v42)

CONTENTS
  root.tex           main manuscript (compiles standalone)
  supplementary.tex  supplementary material (compiles standalone)
  figs_p2/           all figure files (PNG)

BUILD
  Compile with any standard TeX distribution, e.g.
      pdflatex root.tex        (run twice for references)
  or with Tectonic:
      tectonic root.tex

REQUIREMENTS
  No custom style/class/bibliography files are used. Only these standard
  TeX packages are required (included in a full TeX Live / MikTeX install):
      amsmath, amssymb, amsthm, graphicx, booktabs, array, calc,
      caption, hyperref, etoolbox, geometry

NOTES
  - Figures are referenced relative to this directory (figs_p2/...), so keep
    root.tex, supplementary.tex and the figs_p2/ folder together.
  - The main text cross-references the Supplementary Material as a separate
    document; it does not \input it.

CHANGES IN v42 (vs v41)
  - Supplementary: removed a duplicated "References" heading.
