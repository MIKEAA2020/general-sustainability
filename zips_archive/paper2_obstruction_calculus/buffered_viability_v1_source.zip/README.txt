Source package: buffered_viability_v1 (D-item of the obstruction
programme generalization catalogue). Contains the LaTeX source, the compiled
paper, and the exact-arithmetic verification script (6 check families;
standard library).
Run: python3 buffered_viability_v1_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
