Source package: paper2_applications_note_v1 (applications-and-limitations
satellite statement of the obstruction programme; utility joint audit).
Contains the LaTeX source, the compiled statement, and the pointer-check
script (9 pointer families; requires pymupdf for PDF extraction).
Run: python3 paper2_applications_note_v1_pointers.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
