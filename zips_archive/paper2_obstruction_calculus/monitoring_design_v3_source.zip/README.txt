Source package: monitoring_design_v3 . Contains the LaTeX source, the compiled paper,
and the exact-arithmetic verification script (standard library).
Run: python3 monitoring_design_v3_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
