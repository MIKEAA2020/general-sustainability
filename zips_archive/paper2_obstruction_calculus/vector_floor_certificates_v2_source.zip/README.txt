Source package: vector_floor_certificates_v2 (second edition, revised after a joint audit;
Track-D catalogue note). Contains the LaTeX source, the compiled paper,
and the exact-arithmetic verification script (8 check families;
standard library).
Run: python3 vector_floor_certificates_v2_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
