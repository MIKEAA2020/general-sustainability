Successor paper v1 source package: "Five Layers of Obstruction: A Successor
Architecture for Viability under Incomplete Observation" (C3 of the
obstruction programme, absorbing D2 general information structures and D3
exit-time value functions), plus the exact-arithmetic verification script
(7 check families; standard library).
Run: python3 successor_five_layer_v1_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
