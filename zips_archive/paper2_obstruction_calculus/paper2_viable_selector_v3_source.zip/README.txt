Source package: paper2_viable_selector_v3 (third edition, revised after a
joint audit; unifying framework of the obstruction programme). Contains the
LaTeX source, the compiled paper, and the exact-arithmetic verification
script (12 check families; standard library).
Run: python3 paper2_viable_selector_v3_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
