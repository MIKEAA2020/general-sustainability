Source package: paper2_selector_concordance_v1 . Contains the LaTeX source, the compiled paper,
and the exact-arithmetic verification script (standard library).
Run: python3 paper2_selector_concordance_v1_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
