Source package: paper2_stochastic_selector_v2 (second edition, revised after a
joint audit; D1 theory of the obstruction programme). Contains the LaTeX
source, the compiled paper, and the exact-arithmetic verification script
(15 check families; standard library).
Run: python3 paper2_stochastic_selector_v2_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
