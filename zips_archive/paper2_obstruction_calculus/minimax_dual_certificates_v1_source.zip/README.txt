Source package: minimax_dual_certificates_v1 (new standalone paper on the
measure dual of the common-action obstruction, with a verified audit of a
proposed universal duality). Contains the LaTeX source, the compiled
paper, and the exact-arithmetic verification script (8 check families;
standard library).
Run: python3 minimax_dual_certificates_v1_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
