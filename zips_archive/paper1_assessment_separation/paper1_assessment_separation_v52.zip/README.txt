Aggregate Indices and Transition Safety: A Quantifier-Order Separation
Between Scalarized and Coordinate-Wise Feasibility
(A. Abaee - submission source package)

Package contents
- paper1_assessment_separation_v52.tex : LaTeX source (elsarticle). Compiles
  with tectonic, pdflatex, or xelatex. v52 adds the Gao et al. (2023)
  composite-index citation (in text and reference list).
- paper1_assessment_separation_v52.pdf : compiled paper (34 pp.).
- figs_p1/ : the four manuscript figures (PNG, deposited copies).
- graphical_abstract/ : graphical abstract (PDF/PNG/TIFF).

Supplementary material (S1-S11, incl. the 25-check enumeration) ships
separately as paper1_supplementary_v11.md.
Verification deposit: https://doi.org/10.6084/m9.figshare.33764023
Software companion: SafeTransition (EMS submission, with its own
supplement paper1_safetransition_ems_supplementary_v7.md, S1-S11).
