Aggregate Indices and Transition Safety
(A. Abaee - submitted to Environmental Modeling & Assessment)
Package contents
- paper1_assessment_separation_v43.tex : LaTeX source (elsarticle). All tables
  (action table, claim-layer table, region dictionary, policy-instruments table)
  are embedded in this file. v43 adds the List of Abbreviations and the
  journal-required Declarations (ethics, consent, data availability, competing
  interests, funding, authors' contributions, acknowledgements); data
  availability points to the figshare deposit
  https://doi.org/10.6084/m9.figshare.33764023
- paper1_assessment_separation_v43.pdf : compiled PDF (54 pages), for reading.
- figs_p1/ : the three manuscript figures referenced by the .tex.
    fig1_witness_v40.png            Figure 1 - floor-margin view
    fig2_weight_intervals_v35.png   Figure 2 - weight-interval view
    fig3_path_view_v31.png          Figure 3 - path view
- graphical_abstract/ : graphical abstract candidates (NOT part of the manuscript;
  upload separately in the submission system's graphical-abstract field).
    * graphical_abstract_p1.pdf/.png/.tiff  - existing vector design,
      "One number from many capitals" framing; part of the p1/p3/p4/p5/e2 set.
    * graphical_abstract_floors_view.pdf/.png/.tif - alternative raster design,
      four-panel s1/s2 floors story.
Compile with:  pdflatex paper1_assessment_separation_v43.tex
(the .tex resolves figures from the figs_p1/ subfolder next to it).
