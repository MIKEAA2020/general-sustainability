Aggregate Indices and Transition Safety: A Quantifier-Order Separation
Between Scalarized and Coordinate-Wise Feasibility
(A. Abaee - submission source package)

Package contents
- paper1_assessment_separation_v49.tex : LaTeX source (elsarticle). Compiles
  with tectonic, pdflatex, or xelatex. v49 = joint-audit alignment pass:
  the abstract's gap sentence now matches the corrected failure-set
  formulation (the gap is the aggregate-certified part of the reserve-short
  states; blends close exactly the aggregate-certified states, Theorem 9),
  and the 25 grid-verifier checks are enumerated in Supplementary S12
  (pointer updated from S8). All v47/v48 audit fixes included.
- paper1_assessment_separation_v49.pdf : compiled paper (34 pp.).
- figs_p1/ : the four manuscript figures (PNG, deposited copies).
- graphical_abstract/ : graphical abstract (PDF/PNG/TIFF).

Supplementary material (S1-S12) ships separately as paper1_supplementary_v5.md.
Verification deposit: https://doi.org/10.6084/m9.figshare.33764023
(verification/typed_false_positive_instantiation.py re-runs the 25 exact
grid checks; stdlib only, ~36 s). Software companion: SafeTransition 1.3.0.
