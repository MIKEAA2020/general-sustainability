Paper 2 v45 source package: main tex+pdf, supplementary (v44), all figures,
coverage-audit script (regenerates Table 1 and the figure verbatim).
Run: python3 paper2_coverage_audit.py (numpy, matplotlib).
Mirror: https://github.com/MIKEAA2020/general-sustainability
