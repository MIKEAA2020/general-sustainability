#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for kind in main SI; do
  for pass in 1 2 3; do
    pdflatex -interaction=nonstopmode -halt-on-error \
      -output-directory=build "ecomod_C20_A01_${kind}.tex" \
      > "build/tex_${kind}_pass${pass}.txt" 2>&1
  done
  cp "build/ecomod_C20_A01_${kind}.pdf" .
done
printf 'Built ecomod_C20_A01_main.pdf and ecomod_C20_A01_SI.pdf\n'
