# LaTeX source archive — ECOMOD C20

**Manuscript:** *A rising biocapacity total can mask ecological-capital land drawdown: a two-land model*  
**Author:** Amin Abaee  
**Archive date:** 2026-10-31
**Preprint DOI:** https://doi.org/10.20944/preprints202611.0852.v1 (version 1)

This archive contains the complete manuscript-specific LaTeX source needed to rebuild the main manuscript and its Supplementary Information. It is intended for the Preprints.org source-file request for the deposited version.

## Build

Run from this directory:

```bash
bash build_documents.sh
```

The script runs three `pdflatex` passes per document and creates:

- `ecomod_C20_A01_main.pdf` — expected 38 pages
- `ecomod_C20_A01_SI.pdf` — expected 31 pages

Intermediate files and logs are placed in `build/`. No Python, network access, external bibliography processor, or numerical pipeline is required for document compilation.

A TeX installation with `pdflatex` and the standard packages used by the sources is required. On Debian, the original build environment is supplied by `texlive-latex-base`, `texlive-latex-extra`, and `texlive-publishers`. The exact `elsarticle.cls` used for the original C19 build is included for convenience.

## Bibliographies

There are **no external `.bib` files**. Both documents use embedded `thebibliography` environments with complete `\bibitem` records. No BibTeX/Biber run is needed.

## Included manuscript-specific dependencies

- Main and SI `.tex` sources
- Three main-text figure PDFs and five SI figure PDFs
- Nine `\input` table-fragment files under `tables/` and `inherited_C17/tables/`
- `elsarticle.cls`
- C19 data-attribution/license notice
- `SOURCE_MANIFEST.json` with file sizes and SHA-256 hashes

Generated manuscript PDFs are intentionally not included in this source archive; the build script creates them. Numerical input data and analysis pipelines are not needed to compile the documents and are therefore not duplicated here. The manuscript's Data availability statement identifies the complete scientific reproduction package.

The included `elsarticle.cls` is unmodified, retains its copyright header, and is distributed under the LaTeX Project Public License 1.3 or later, as stated in that header. NFA-derived figures retain the attribution and CC BY-SA 4.0 terms described in `DATA_LICENSE_C19_A01.md`.
