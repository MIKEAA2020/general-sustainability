#!/usr/bin/env python3
"""Deposit this package as a NEW Zenodo dataset record.

Usage
    export ZENODO_TOKEN=...      # never commit or paste the token anywhere
    python zenodo/upload_to_zenodo.py --package-root . --dry-run
    python zenodo/upload_to_zenodo.py --package-root .

Sandbox: add --sandbox (use a sandbox.zenodo.org token).

The script never prints the token and never writes it to disk. It does not touch the existing
record 22554480: the new record is standalone and points to that record only as a related identifier.
"""
import argparse, json, os, sys, mimetypes
from pathlib import Path
import urllib.request, urllib.error

SKIP = {"zenodo"}          # do not upload the deposit metadata folder itself


def api(base, token, path, method="GET", data=None, content_type="application/json"):
    req = urllib.request.Request(f"{base}/{path}", method=method, data=data)
    req.add_header("Authorization", f"Bearer {token}")
    if data is not None:
        req.add_header("Content-Type", content_type)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            body = r.read()
            return json.loads(body) if body else {}
    except urllib.error.HTTPError as e:
        sys.exit(f"HTTP {e.code} on {method} {path}\n{e.read().decode('utf-8', 'replace')[:800]}")


def files_to_upload(root):
    out = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            rel = p.relative_to(root)
            if rel.parts and rel.parts[0] in SKIP:
                continue
            out.append((p, rel.as_posix()))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--package-root", default="..")
    ap.add_argument("--sandbox", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--metadata", default="zenodo/zenodo_metadata.json")
    args = ap.parse_args()

    base = "https://sandbox.zenodo.org/api" if args.sandbox else "https://zenodo.org/api"
    root = Path(args.package_root).resolve()
    payload = json.loads((root / args.metadata).read_text())["metadata"]
    uploads = files_to_upload(root)
    total = sum(p.stat().st_size for p, _ in uploads)

    print(f"target:  NEW dataset record at {base}")
    print(f"title:   {payload['title']}")
    print(f"files:   {len(uploads)}  ({total/1e6:.1f} MB)")
    if args.dry_run:
        for p, rel in uploads:
            print(f"  {rel}  ({p.stat().st_size} bytes)")
        print("\nDRY RUN: metadata that would be applied:")
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return

    token = os.environ.get("ZENODO_TOKEN")
    if not token:
        sys.exit("ZENODO_TOKEN is not set")

    print("\n1/4 creating empty deposit ...")
    dep = api(base, token, "deposit/depositions", method="POST", data=b"{}")
    dep_id, bucket = dep["id"], dep["links"]["bucket"]

    print("2/4 uploading ...")
    for p, rel in uploads:
        req = urllib.request.Request(f"{bucket}/{rel}", method="PUT", data=p.read_bytes())
        req.add_header("Authorization", f"Bearer {token}")
        req.add_header("Content-Type", mimetypes.guess_type(p.name)[0] or "application/octet-stream")
        with urllib.request.urlopen(req, timeout=600) as r:
            if r.status not in (200, 201):
                sys.exit(f"upload failed for {rel}: {r.status}")
        print(f"    {rel}")

    print("3/4 applying metadata ...")
    api(base, token, f"deposit/depositions/{dep_id}", method="PUT",
        data=json.dumps({"metadata": payload}).encode())

    print("4/4 publishing ...")
    rec = api(base, token, f"deposit/depositions/{dep_id}/actions/publish", method="POST")
    print(f"\npublished DOI: {rec.get('doi')}\nconcept DOI:   {rec.get('conceptdoi') or 'see record page'}")


if __name__ == "__main__":
    main()
