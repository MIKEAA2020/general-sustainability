# ECOMOD C20 A01 — reproduction package

**Manuscript:** A rising biocapacity total can mask ecological-capital land drawdown: a two-land model
**Author:** Amin Abaee (Independent Researcher, Tehran, Iran; ORCID 0000-0002-0019-1842)
**Version:** ECOMOD C20 A01, 31 October 2026
**Preprint:** https://doi.org/10.20944/preprints202611.0852.v1
**Deposit type:** standalone dataset record. Supersedes the reproduction files of Zenodo 22554480 (ECOMOD v35) without modifying that preprint record.

This package contains the manuscript sources, the Supplementary Information, all figure files, the table fragments, the executable analysis code, the frozen empirical inputs and the numerical outputs. It is the deposit supporting the manuscript's Data availability statement.

## Contents

| Directory | Contents |
|---|---|
| `manuscript/` | `Manuscript_ECOMOD_C20_A01.tex` (editable source) and `.pdf` (38 pp) |
| `supplementary/` | `Supplementary_Information_ECOMOD_C20_A01.tex` and `.pdf` (31 pp) |
| `figures/` | Figures 1–3 and S1–S5 as vector PDFs (fonts embedded) |
| `tables/`, `inherited_C17/tables/` | The nine `\input` table fragments used by the two documents |
| `code/` | Three reproduction scripts and pinned requirements |
| `data/` | 26 numerical outputs (CSV/JSON) referenced by the manuscript and SI |
| `repository_sources/` | Frozen empirical inputs: NFA Edition 2026 workbook and the OWID cropland-area and cereal-yield series; one historical v44 drawdown CSV required for the vintage comparison |
| `inherited_C17/code/` | The baseline budget solver module imported by the two-land reproduction script |
| `zenodo/` | Deposit metadata and upload instructions |

## Rebuilding the documents

```bash
cd manuscript && pdflatex -interaction=nonstopmode Manuscript_ECOMOD_C20_A01.tex   # three passes
cd ../supplementary && pdflatex -interaction=nonstopmode Supplementary_Information_ECOMOD_C20_A01.tex
```

The sources reference `figures/` and `tables/` by relative path. To compile them, either place the two `.tex` files beside the `figures/` and `tables/` directories at the package root, or copy those directories next to the sources. Bibliographies are embedded: no BibTeX step is required. Verified result: 39 and 31 pages, zero LaTeX warnings, zero overfull boxes, no unresolved references or citations.

Requirements: TeX Live with `elsarticle`, `amsmath`, `amssymb`, `amsthm`, `booktabs`, `array`, `tabularx`, `graphicx`, `enumitem`, `xurl`, `hyperref` (Debian: `texlive-latex-base`, `texlive-latex-extra`, `texlive-publishers`). Built with TeX Live 2025/Debian.

## Re-executing the analysis

```bash
python -m pip install -r code/requirements.txt
python code/reproduce_two_land_C18_A01.py    # two-land model, budgets, refinement, ladders -> data/, figures/
python code/reproduce_empirical_C18_A01.py  # NFA Edition 2026 decomposition, proxy -> data/, figures/
python code/reproduce_comparator_C18_A01.py # one-stock comparator, SI S7 -> data/, figures/
```

Scripts resolve their paths from their own location, so they run from any working directory. Pinned environment: `numpy==2.3.5`, `scipy==1.17.1`, `numba==0.66.0`, `matplotlib==3.10.9`, `openpyxl==3.1.5`, `requests==2.33.0`.

**Verification performed for this deposit:** all three scripts executed in a clean copy of this package, and the regenerated `data/` files matched the shipped files **byte-for-byte, 26/26**. No network access is used: the empirical script reads the frozen workbook and CSVs in `repository_sources/`, not live sources.

## Reported quantities and where they come from

| Quantity | Value | Script / file |
|---|---|---|
| Baseline model biocapacity | 0.594 → 0.825 gha (+38.97%) | `reproduce_two_land_C18_A01.py`; `fig1_model_dynamics` |
| Capital-land area | 1.500 → 0.808 ha (−46.16%) | same |
| Capital-land contribution Υ(q)A_c | −51.72% | same |
| Demand ceiling E_ceil | ≈1.138 gha | same |
| Conversion / maintenance / net, 100 yr | +0.547925 / −0.311098 / +0.231310 gha | `data/two_land_summary_C18_A01.json` |
| Closure error, Δt 0.05 → 0.00078 yr | 5.144e-3 → 8.040e-5 | `data/` refinement outputs |
| NFA world biocapacity 1961–2023 | 9.7254 → 12.1428 ×10⁹ gha (+24.86%) | `data/empirical_endpoints_C18_A01.csv` |
| Biocapacity per person | −52.71% | same |
| Production footprint per person | +16.73% | same |
| Component contributions | cropland +24.06, built-up +7.44, forest −5.95, fishing −0.42, grazing −0.27 pp | `data/empirical_components_C18_A01.csv` |

## Units

Annual account amounts `B`, `E`, `Y_f`, `Y_c`, `S` are in gha with the annual basis implicit. The internal accumulated deficit `D` is the only stock-like quantity, in gha·yr. Per-capita footprint `e` is in gha cap⁻¹. Areas in ha; `q` dimensionless.

## Scope

The model parameters are representative, not fitted. The simulations are conditional illustrations, not forecasts or historical reconstructions. The NFA analysis measures account composition, not physical ecological stock. No field data were collected for this study. The no-fold and no-critical-slowing result is restricted to the reduced fixed-demand equality relation.

## Licenses and attribution

See `LICENSE_DATA_ATTRIBUTION.md`. In summary: NFA inputs and all NFA-derived data and figures retain **CC BY-SA 4.0** attribution to Lo et al. (2026); the OWID cropland-area and cereal-yield series retain their upstream terms; manuscript text and the author's code are offered under **CC BY 4.0** unless stated otherwise in the record metadata. No provider endorsement is implied, and no third-party copyrighted provider document is redistributed here.

## Provenance

The manuscript sources derive from the versioned ECOMOD C19 A01 package, with one documented change in this version: the Preprints.org deposit DOI was added to the main text and the SI, and the keyword list was reduced to six. Numerical outputs and inputs are byte-inherited from the C19 A01 package, whose manifest records SHA-256 hashes for every file. `SHA256SUMS.txt` records the identity of every file in this deposit.
