# Supplementary material package — Paper 4 (delay dynamics)

**Manuscript:** *Governance delay and the stability of harvested stocks: mobilising and protective feedback rules, and the review interval as a design parameter* — `paper4_delay_dynamics_v39.md` (md5 `5ca3850f3dd3b22f917cc4b0e5dcd583`), LaTeX `paper4_delay_dynamics_v39.tex` (md5 `629a97ae7a92c4146f2be1ff4fd3f1fe`; three consecutive byte-identical tectonic builds), rendered PDF `paper4_delay_dynamics_v39.pdf` (md5 `65971aae315f74065b02104d00d28cf8`; 45 pages).

**Supplementary document:** `paper4_supplementary_v8.md` (md5 `20156536b537265f1220ce17646dc799`) — sections S1–S12 exactly as listed by the manuscript's *Supplementary material* paragraph (the v8 refresh: the retitle round — the H1, the *Accompanies* line, and the opening subject phrase follow the manuscript's new title; no numerical content, S-structure element, or object label changed).

**Package built:** 2026-09-18 (the same day as the v7 refresh), from repository `MIKEAA2020/general-sustainability` (Task 98, the retitle round; the v8 refresh of the v7 package built at commit `4568560`/Task 97). Every file under `code_and_records/` and `figure/` is a **byte-identical copy** of the repository file — unchanged from the v7 package and verified file-by-file against it (79 payload files, sha256) — and the supplementary document is the v8 file as committed this round; see `MANIFEST.sha256` and the source-path table below.

This package is the concrete artifact behind the manuscript's Data availability statement: *"The parameter tables, the certified enclosures, and the numerical protocols are available from the authors and are deposited with the supplementary material. The recovered stage-analysis machinery of Section 9 is archived verbatim with the deposited material and re-executable; its recovery audit and the 21-gate registration campaign that certifies the Section 9 records (gate log and fine-map table, Supplementary S9) are deposited with the supplementary material."*

---

## 1. Contents and repository sources

| Package path | Repository source (payload identical since commit `36475e5`) | What it certifies |
|---|---|---|
| `paper4_supplementary_v8.md` | `arena agent 1/paper rewrites/paper4_supplementary_v8.md` | the supplementary document (S1–S12) |
| `code_and_records/interval_hopf_pipeline/` | `research_program/validated_computations/a025_fold/` (whole folder) | S1's interval Hopf enclosures (τ₋ ∈ [3.6661490142739, 3.6661490142743] yr, τ₊ ∈ [150.3584773101408, 150.3584773101421] yr); S2's collocation / small-branch / fold machinery; S3's discrete interval-Krawczyk fold certificate (enclosure [5.587236198689, 5.587236198691]) |
| `code_and_records/five_regime_campaign/` | `research_program/validated_computations/p4_five_regime_campaign/` (whole folder) | §8.2's five-regime attractor topology: 148 branch records, 87 basin runs, solver + environment archives, the execution report (`p4_campaign_report.md`), and the campaign's own figure |
| `code_and_records/five_regime_preregistration.md` | `arena agent 1/other documents/rerun_campaigns/p4_continuation_campaign_preregistration.md` | the five-regime campaign's pre-registered plan (frozen 2026-09-03, before any run) |
| `code_and_records/second_fold_campaign/` | `research_program/validated_computations/a025_second_fold/` (whole folder, incl. `SECOND_FOLD_PREREGISTRATION.md`) | §8.2's second fold (τ_f2 ∈ [64.402327203368, 64.402327203372] yr): 200 branch records, 45 basin runs, the interval-Krawczyk certificate, the preserved frozen-box failure record, the report |
| `code_and_records/dr_registration/` | `arena agent 1/other documents/rerun_campaigns/` (P4 subset) | §9 / Supplementary S9's maturation-delayed recruitment records: the 21-gate registration campaign, the recovered stage machinery (verbatim archive incl. the recovery record `readme.txt`/`recover.txt`), the stage-reconstruction pre-registration, and the gate log + fine-map table |
| `code_and_records/review_interval_monodromy/` | `arena agent 1/other documents/rerun_campaigns/` (P4 subset) | §6.4/§7's review-interval monodromy records: the exact held-measurement monodromy (Proposition 7.1, T_r = 6.50 yr), the scheme-dependence determination, the M_ZOH crossings, the verification note, and the committed output record |
| `figure/fig2_five_regime_topology.py` + `figure/fig2_five_regime_topology_v2.png` | `arena agent 1/paper rewrites/figs_p4/` | Figure 1 (the four-panel five-regime topology figure) — the exact PNG included by the manuscript's LaTeX source (`\includegraphics{figs_p4/fig2_five_regime_topology_v2.png}`) and its generator script, drawn only from the deposited campaign CSVs |
| `verification/` | (this packaging round) | the packaging-time re-execution record (`packaging_rerun_2026-09-18.md` + logs; carried over unchanged from the v7 package — the payload bytes are identical, so the re-execution record stands) and the refresh notes (`packaging_refresh_2026-09-18_v7.md`, `packaging_refresh_2026-09-18_v8.md`) |
| `MANIFEST.sha256` | (this packaging round) | sha256 of every packaged file |

## 2. Code → record map

- **S1 (interval Hopf enclosures):** `interval_hopf_pipeline/a025_interval_hopf.py` (with `a025_model.py`; mpmath interval arithmetic, dps = 50) — outward-rounded interval Newton on the Hopf cubic and branch-safe phase evaluation; writes `a025_interval_hopf.json`.
- **S2–S3 (collocation, small branch, fold certificate):** `interval_hopf_pipeline/a025_fold_pipeline.py` and `interval_hopf_pipeline/a025_fold_krawczyk.py` — the m = 64/96/128 Moore–Spence machinery and the discrete interval-Krawczyk certificate.
- **§8.2 (five-regime topology):** `five_regime_campaign/p4_campaign.py` + `p4_kernels.py` (numba method-of-steps RK4 basin integrator + variational segment map); records in the CSV / JSON / npz archives and `p4_campaign_report.md`.
- **§8.2 (second fold):** `second_fold_campaign/second_fold_search.py` + `second_fold_krawczyk.py`; records in `second_fold_branch.csv`, `second_fold_basin.csv`, the JSONs, and `second_fold_report.md`.
- **§6.4 / §7 (review-interval monodromy):** `review_interval_monodromy/p4_exact_hold_monodromy.py` (exact held-measurement monodromy; reproduces the Euler-artefact crossings 47.536 / 79.143 yr and locates the exact crossing T_r ≈ 6.50 yr), `p4_scheme_dependence_check.py` (start-of-period vs end-of-period measurement vs native zero-order hold), `p4_mzoh_verify.py` (measurement-ZOH crossings and the rank-one large-T limit), with `p4_exact_hold_verification.md` and `results/p4_exact_hold_monodromy.txt` as the committed record.
- **§9 / S9 (maturation-delayed recruitment):** `dr_registration/campaign_p4_dr_registration.py` — the 21 gates G1–G5 over the recovered machinery in `dr_registration/stage_scan_recovered/` (verbatim archive); outputs `results/p4_dr_registration_gates.txt` and `results/p4_dr_finemap_bands.csv`.
- **Figure 1:** `figure/fig2_five_regime_topology.py`, reading the campaign CSVs (see its header for the record-to-panel mapping).

## 3. Re-execution verification at packaging time (2026-09-18; payload unchanged in v8)

Environment: Python 3.12.14, numpy 2.1.3, scipy 1.14.1, mpmath 1.3.0 (Linux x86_64). Log excerpts and full logs: `verification/`.

1. `a025_interval_hopf.py` — exit 0; `a025_interval_hopf.json` reproduced **byte-identical** to the committed record (the S1 enclosures reproduce exactly with outward rounding).
2. `campaign_p4_dr_registration.py` — exit 0; **21/21 gates PASS**: G1a–G1e sign-flip certificates (original pair 3.666149/150.358477; flipped fundamentals 128.374373/70.696578; branch mechanism ±π/ω; flipped loop gain 1.019 vs the paper's 1.016 — the strict inequality is the load-bearing claim; simplicity + transversality), G2 base windows, G3 fine-map bands at the recorded ±0.03 grid resolution, G3-wide mesh cells stable, G3-probe cohort-regime confirmation, G4 nonlinear ground truth (P = 358.7 / 20.1 / 16.95 / 4.00 / 8.05 yr), G5 compute-core Hopf pair (3.666, 249.4) / (150.358, 159.3).
3. `p4_exact_hold_monodromy.py` — exit 0; Euler-artefact crossings 47.5371 (complex pair) and 79.1427 (real −1) reproduced; protective exact ρ(1) = 0.983810 with no crossing on [0.2, 120]; mobilising exact crossing **T_r = 6.5013 yr** (the paper's 6.50, Proposition 7.1).
4. `p4_mzoh_verify.py` — exit 0; protective M_ZOH no crossings on [0.2, 200], ρ(1) = 0.992808; mobilising rank-one large-T limit confirmed.
5. `p4_scheme_dependence_check.py` — exit 0; L(0) = 0 filter identity; rank-one limit at large T.

**Not re-executed at packaging time** (runtime-scale campaigns, executed once each under their pre-registered plans on 2026-09-02/03, with first-run status stated in the paper): `p4_campaign.py`, `second_fold_search.py`, `second_fold_krawczyk.py`, `a025_fold_pipeline.py`, `a025_fold_krawczyk.py`. Their committed records (CSVs, JSONs, npz, logs, reports) are included unmodified.

**Environment note (absolute paths).** The recovered stage modules (`stage_scan_recovered/compute_core.py`, `stage_core.py`, `verify_floquet_points.py`) and the figure script carry the original authoring environment's absolute paths (`/home/user/figures`, `/home/user/dde_floquet/…`, and the figure script's `BASE` mirror constant). Re-execution in a fresh environment requires redirecting those constants to local directories — a path-only adaptation with no numerical effect (this is exactly how the packaging-time re-run above was performed; the sandbox copies were patched, the packaged scripts are the unmodified committed bytes).

## 4. Requirements

Python 3.12; `numpy` and `scipy` (all scripts); `mpmath` (interval Hopf pipeline); `numba` (five-regime campaign kernels); `pandas` and `matplotlib` (figure script). The campaigns' recorded environments are archived in `five_regime_campaign/p4_environment.json` and `second_fold_campaign/second_fold_environment.json`.

## 5. Status discipline (as the paper states)

The five-regime and second-fold campaigns are **pre-registered, executed once, and not yet independently replicated** — §8.2 of the manuscript carries exactly this status. The interval Hopf pipeline is independently re-executable and was re-executed byte-identically at packaging time (item 1 above). The fold certificates are discrete-collocation-scope certificates; the continuum off-grid residual stage and the continuous-delay lift remain open (Supplementary S3 and the S12 status note).

## 6. Reproducing and auditing this package

`MANIFEST.sha256` lists the sha256 of every packaged file. Every file except `README.md`, `MANIFEST.sha256`, and `verification/` is a byte-identical copy of the repository file (source paths in the table above; the payload is identical to the v7 package's, whose sources were pinned at commit `36475e5`), so the package can be reconstructed or audited directly against the repository.
