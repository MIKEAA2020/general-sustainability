# Packaging refresh — 2026-09-19 (v40; Task 99)

The manuscript advanced v39 -> v40 (the wave-23 cleanup round: exactly
one anchored edit — Section 1.1's phantom-strawman clause
"rather than opposed in caricature" removed; every frozen block
byte-identical; 45 pages unchanged; three byte-identical tectonic
builds, tex md5 0ce11af0262a80b15a2a24bf1695254f).  The supplementary
document is UNCHANGED at v8 (the wave-23 artifact scan found zero
supplement sites), so the package version stays v8 and this refresh is
in place (the built-asset precedent; the previous zip's sha256
6af7de2051f98271f3b6f2d7708ce470c0f3ed65ce1b298e3b02f838d1339846 is
preserved in git history and in the round record).

Changed in this refresh: the README's Manuscript line (v40 filename and
checksums) and this note; MANIFEST.sha256 regenerated.  Everything
else — the 79 payload files under code_and_records/ and figure/, the
supplementary document paper4_supplementary_v8.md, the prior
verification notes and logs — is byte-identical to the previous
package, verified file-by-file by this refresh script before rebuild.
