# Packaging-time re-execution record — 2026-09-18

All scripts were re-executed in a fresh sandbox (copies of the committed bytes; the recovered
stage modules' authoring-environment absolute output paths `/home/user/...` redirected to local
sandbox directories — a path-only adaptation, no numerical change). Environment: Python 3.12.14,
numpy 2.1.3, scipy 1.14.1, mpmath 1.3.0, Linux x86_64. Full logs: `logs/`.

## 1. Interval Hopf certification (`code_and_records/interval_hopf_pipeline/a025_interval_hopf.py`)

Exit 0. The written record `a025_interval_hopf.json` is **byte-identical** to the committed
repository record (verified by `diff`). Key reproduced values (from the JSON, shown at full
recorded precision):

- τ₋ (lower family, k=0): `[3.666149014274113480686433902801168166391563725373792359, 3.666149014274113480686433902801168166391563725412151878]` — Supplementary S1.2's displayed enclosure is τ₋ ∈ [3.6661490142739, 3.6661490142743]; crossing direction left (stabilising), dRe/dτ < 0.
- τ₊ (upper family, k=1): `[150.3584773101413847720118643399526401401540495666468638, 150.3584773101413847720118643399526401401540495667621561]` — S1.2's displayed enclosure is τ₊ ∈ [150.3584773101408, 150.3584773101421]; crossing direction right (destabilising).
- Both roots certified simple (`simple_root: true`).

## 2. The 21-gate registration campaign (`code_and_records/dr_registration/campaign_p4_dr_registration.py`)

Exit 0. **TOTAL: 21/21 gates. PASS gates: 21, FAIL gates: 0.** Gate-log tail:

```
PASS  G1b flipped fundamental delays  128.374373 / 70.696578 (paper: 128.374 / 70.697)
PASS  G1c branch mechanism  +pi/o1 lower, -pi/o2 upper; omega=(0.0251915,0.0394366)
PASS  G1d flipped loop gain  Gamma=1.019221 (paper: 1.016)
PASS  G1e simplicity+transversality at shifted points  dlam_dtau Re = -6.073e-06, 1.829e-05
PASS  G2a g=0 eta=0.914 base window  [0.00796,0.02191] vs (0.00796,0.02191)
PASS  G2b g=0 eta=3.0 base window  [0.00676,0.06028] vs (0.00676,0.06028)
PASS  G3 g=1.0 band  rerun (1.5643, 1.5857) vs recorded (1.565,1.585) at +/-0.03 ...
PASS  G3 g=2.0 band  rerun (0.7669, 0.8049) vs recorded (0.77,0.81) at +/-0.03 ...
PASS  G3 g=3.0 band  rerun (0.4919, 0.5466) vs recorded (0.5,0.55) at +/-0.03 ...
PASS  G3 g=5.0 band  rerun (0.2603, 0.3324) vs recorded (0.28,0.33) at +/-0.03 ...
PASS  G3-wide eta=0.914 band cells stable on the wide mesh  8 cells, all R_max<0 with crossings
PASS  G3-probe (g=5, eta=3, r=1.57) wide mesh: cohort regime, recorded 'none' confirmed  R_max(wide)=+0.24453 > 0
PASS  G4a slow-r cohort cycle (r=0.02,g=5,tau=0)  oscillatory, P=358.7 (recorded 358.8), tail amp=66.9 (recorded 66.9)
PASS  G4b fish-r cohort cycle (r=0.5,g=5,tau=0)  oscillatory, P=20.1 (recorded ~20)
PASS  G4c (r=0.3,g=5): tau=0 stable, two crossings  stable, crossings=2
PASS  G4d institutional cycle (r=0.3,g=5,tau=10)  P=16.95 (recorded 16.96), amp=9.36 (recorded 8.66)
PASS  G4e (r=0.3,g=5,tau=21) stable  amp=0.000 (recorded: stable)
PASS  G4f band centre g=1 (r=1.57,tau=2.5,eta=3)  P=4.00 (recorded 4.0), amp=3.49 (recorded 3.5)
PASS  G4g band centre g=2 (r=0.8,tau=5.5,eta=3)  P=8.05 (recorded 8.04), amp=12.35 (recorded 12.4)
PASS  G5 compute_core A_gated Hopf pair  [(3.666, 249.4), (150.358, 159.3)]
```

(G1a, the original committed pair 3.666149 / 150.358477, passed earlier in the log; the tail above
is reproduced from `logs/dr_run.log`.)

## 3. Exact held-measurement monodromy (`code_and_records/review_interval_monodromy/p4_exact_hold_monodromy.py`)

Exit 0. Key reproduced lines:

```
[mobilising Euler] crossings of rho=1: [(47.5371, 'complex-pair'), (79.1427, 'real', -1.0)]
  mobilising Euler rho(1)   = 1.000545 (paper 1.00055)
[protective exact] crossings of rho=1: []
  protective exact rho(1)   = 0.983810 vs Euler 0.983796
  protective exact max rho on [0.2,120]: 0.996740
[mobilising exact [0.2,120]] crossings of rho=1: [(6.5013, 'complex-pair', 0.9846, 0.1746)]
  mobilising exact rho(1)   = 1.000351 vs Euler 1.000545
  mobilising exact rho(47.5) = 0.786054
  mobilising exact rho(79.1) = 0.597207
```

The Euler-artefact crossings (47.536 / 79.143 yr), the protective no-crossing record, and the
exact crossing T_r = 6.5013 yr (the paper's Proposition 7.1 value 6.50 yr) all reproduce.

## 4. Measurement-ZOH verification (`p4_mzoh_verify.py`) and scheme-dependence (`p4_scheme_dependence_check.py`)

Both exit 0. Key reproduced lines:

```
protective M_ZOH crossings [0.2,200]: []
protective M_ZOH rho(1): 0.992808
mobilising M_ZOH rho(200)=0.242228  rank=3
mobilising M_ZOH rho(500)=0.016502  rank=2
mobilising M_ZOH rho(2000)=0.000000  rank=1
det AZ = -0.0002132
```
```
L(0) = B_E*0 = 0.000000  (filter identity)
M_exact rho(200.0) = 0.202560
M_exact rho(500.0) = 0.013797
M_exact rho(1000.0) = 0.000157
```

## 5. Commands used

```
# sandbox: byte-identical copies of the committed scripts; /home/user -> local redirect in the copies only
python3 a025_interval_hopf.py            # -> a025_interval_hopf.json (byte-identical to committed)
python3 campaign_p4_dr_registration.py   # -> 21/21 gates PASS
python3 p4_exact_hold_monodromy.py       # -> T_r = 6.5013 yr exact crossing
python3 p4_mzoh_verify.py                # -> protective M_ZOH stable, rank-one limit
python3 p4_scheme_dependence_check.py    # -> L(0)=0, rank-one limit
```

Not re-executed at packaging time (runtime-scale, first-run status per the paper): the five-regime
campaign (`p4_campaign.py`), the second-fold search and certification (`second_fold_search.py`,
`second_fold_krawczyk.py`), and the fold pipeline / Krawczyk stage of the interval pipeline
(`a025_fold_pipeline.py`, `a025_fold_krawczyk.py`). Their committed records ship unmodified in this
package.
