# Packaging refresh — 2026-09-19 (v41; Task 102)

The manuscript advanced v40 -> v41 (the wave-24 round: the 16
Crossref-verified reference DOIs inserted as anchored suffixes — 23
doi: suffixes in the reference list after this round; the abstract's
Task-97 phrase flag resolved for honesty — "ecological or
informational" with the recorded compensating one-word trim, 259
journal words, below the 260 bound; every other block byte-identical
to v40's; 45 pages; three byte-identical tectonic builds, tex md5
9690145302dd5ffe790a5cee799de0b7).  The supplementary document is
UNCHANGED at v8 (no supplement file was touched this round), so the
package version stays v8 and this refresh is in place (the built-asset
precedent; the previous zip's sha256
ed8e99679494e32e106c9af64587ab0ebabdac379c6850ce36b643cf00a776bd is
preserved in git history and in the round record).

Changed in this refresh: the README's Manuscript line (v41 filename
and checksums) and this note; MANIFEST.sha256 regenerated.  Everything
else — the payload files under code_and_records/ and figure/, the
supplementary document paper4_supplementary_v8.md, the prior
verification notes and logs — is byte-identical to the previous
package, verified file-by-file by this refresh script before rebuild.
