# v7 packaging refresh note (2026-09-18, Task 97)

This package is the v7 refresh of `paper4_supplementary_v6.zip`, matching the
manuscript's v38 round (the reference round + artifact-class removal).

**What changed (the supplementary document only):**
- `paper4_supplementary_v6.md` -> `paper4_supplementary_v7.md` (md5
  `e8dcce49469ea48132e273a4d5c4a2b1`): the artifact-class removal round -
  repository-speak ("the committed pipeline/coefficients/fundamental pair/
  certificates") replaced by the paper's register (deposited / registered);
  the dangling internal-audit pointers ("the audit document",
  "audits/tikhonov_unh_verification.md") and the process date stamp
  "(verified 2026-09-03)" removed; the change-of-state "now"s removed; the
  S11 heading retitled "Relocated MPF Material" -> "MPF Material"; the
  Hocherman citation corrected to the three-author house form
  ("Hocherman, Trop, and Ghermandi (2025)"). No numerical value, theorem
  statement, or S-structure element changed (machine-verified: the v7 file
  differs from v6 in exactly 10 lines; the only numeric tokens removed are
  the date stamp's 2026/09/03).

**What did NOT change (verified file-by-file against the v6 package):**
- every file under `code_and_records/` and `figure/` is byte-identical to
  the v6 package's payload (sha256 comparison, all files).

**Re-execution status:** the packaging-time re-execution record of
2026-09-18 (`packaging_rerun_2026-09-18.md`) stands unchanged for the code
payload (byte-identical bytes => identical behaviour): the interval-Hopf
JSON byte-identity, the 21/21 registration gates, and the exact-hold
T_r = 6.5013 yr record verified at v6 packaging time carry over verbatim.
The document-only refresh requires no re-execution.
