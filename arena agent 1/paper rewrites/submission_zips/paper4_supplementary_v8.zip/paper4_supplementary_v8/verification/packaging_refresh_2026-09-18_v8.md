# v8 packaging refresh note (2026-09-18, Task 98)

This package is the v8 refresh of `paper4_supplementary_v7.zip`, matching the
manuscript's v39 round (the retitle round: the owner-delegated title choice
for Theoretical Ecology).

**What changed (the supplementary document only):**
- `paper4_supplementary_v7.md` -> `paper4_supplementary_v8.md` (md5
  `20156536b537265f1220ce17646dc799`): the retitle round - the H1
  ("Supplementary Material — Governance delay and the stability of harvested
  stocks"), the *Accompanies* line (the full new title "Governance delay and
  the stability of harvested stocks: mobilising and protective feedback
  rules, and the review interval as a design parameter"), and the opening
  subject phrase follow the manuscript's new title. No numerical value,
  theorem statement, S-structure element, or object label changed
  (machine-verified: the v8 file differs from v7 in exactly 3 lines; the
  numeric multisets are identical).
- `README.md`: the manuscript line retitled with the v39 checksums; this
  refresh note added.
- `MANIFEST.sha256`: regenerated for the v8 tree.

**What did NOT change (verified file-by-file against the v7 package):**
- every file under `code_and_records/` and `figure/` is byte-identical to
  the v7 package's payload (sha256 comparison, all 79 files).

**Re-execution status:** the packaging-time re-execution record of
2026-09-18 (byte-identical `a025_interval_hopf.json`, 21/21 registration
gates, exact-hold T_r = 6.5013) stands for the unchanged payload bytes;
it is carried over unchanged under `verification/`.
