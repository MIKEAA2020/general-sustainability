Submission package - paper4_delay_dynamics_v41
===============================================

Journal: Theoretical Ecology (LaTeX source package for peer review)

Contents
--------
latex/paper4_delay_dynamics_v41.tex
    The main LaTeX source file. Standard article class, standard
    packages only (no custom .cls or .sty required). The reference
    list is part of the source, so no BibTeX run is needed; tables are
    inline environments; there is exactly one figure file.

latex/paper4_delay_dynamics_v41.pdf
    The compiled PDF (45 pages, one figure), as built from this source.

latex/figs_p4/fig2_five_regime_topology_v2.png
figs_p4/fig2_five_regime_topology_v2.png
    Figure 1, placed at both resolution paths (beside the source and
    at the archive root). The source compiles with the directory
    structure as shipped, or with the .tex moved to the archive root.

README.txt
    This note.

How to compile
--------------
The main file is latex/paper4_delay_dynamics_v41.tex. Any standard
LaTeX engine works (tectonic, pdflatex, or xelatex; two passes
recommended for cross-references). The compile is fully
self-contained: no bibliography run, no external table files, and the
single figure is included in this archive at the path the source asks
for. All journal-article references carry DOIs.
