Paper 2 v46 source package: main tex+pdf, supplementary tex, all figures,
coverage-audit script (regenerates Table 1 and the figure verbatim), and the
exact-arithmetic verification script for the linear-programming instantiation
theorem and the two-phase decomposition propositions (standard library only).
Run: python3 paper2_coverage_audit.py (numpy, matplotlib);
python3 paper2_v46_a5a6_verification.py (standard library; 12 checks).
Mirror: https://github.com/MIKEAA2020/general-sustainability
