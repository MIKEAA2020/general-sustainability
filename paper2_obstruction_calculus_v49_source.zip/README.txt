Paper 2 v49 source package: main tex+pdf, supplementary (v46, unchanged),
all figures, the coverage-audit script, and the two exact-arithmetic
verification records (v46 LP-instantiation/decomposition; v47 two-patch audit
and belief-state safety values). v49 inserts the selector-principle
consolidation section (Section 8) and renumbers Sections 8-10 to 9-11; it
claims no new theorem and repairs the two-patch table's residual overfull.
Content provenance and the change table are in the v49 addendum.
Run: python3 paper2_coverage_audit.py (numpy, matplotlib);
python3 paper2_v46_a5a6_verification.py; python3 paper2_v47_verification.py
(standard library only).
Mirror: https://github.com/MIKEAA2020/general-sustainability
