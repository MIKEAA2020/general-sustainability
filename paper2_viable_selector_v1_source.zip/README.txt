Viable-selector paper v1 source package: "The Viable Selector: A Unifying
Framework for Obstruction Certificates under Incomplete Observation" (the
successor spine: recursive viable-selector correspondence, finite-horizon
exactness with the measurable-selection qualification, the meta-theorem,
the ladder/timing/label-selection bridges), plus the exact-arithmetic
verification script (7 check families on the companion papers worked
systems; standard library).
Run: python3 paper2_viable_selector_v1_verify.py
Mirror: https://github.com/MIKEAA2020/general-sustainability
