# Revised Optimal Publication Architecture for the Full A001–A025 Programme

## Correction

The prior two-assured-paper architecture over-applied the “minimum papers when in doubt” rule. It treated source consolidation as publication consolidation and used a technical supplement as an unlimited repository. That is incompatible with the simultaneous non-loss requirement, journal-length constraints, distinct theorem/evidence standards, and the now-mature independent contributions developed after the early publication decisions.

The correct objective is:

> minimize fragmentation subject to complete substantive retention, coherent research questions, audience fit, reproducibility, and publishable length.

The number of source manuscripts is not the number of final papers, but neither can twenty-five heterogeneous sources plus the master corpus be compressed into two ordinary articles without destructive condensation or disguising additional papers as supplements.

## Corrected minimum feasible core: five assured papers

### Paper 1 — General Theory and Research Architecture of Sustainability

**Primary question:** What is the typed, domain-agnostic architecture of sustainability, viability, observation, governance, transformation, and composition?

**Sources:** master manuscript, A001–A002, substantively relevant corrected material from A006–A007/A010, and negative lessons from A008–A009/A015/A017. Source provenance alone does not determine destination.

**Content:** axioms and typing; viability and recovery; observation/epistemic limits; authority and implementation; noncompensation; transformation operator; restricted composition; intergenerational and institutional structures; research architecture and admission standards.

**Independent-result gate:** `paper1_finite_architecture_transformation_theorem.md` now closes proof availability for a restricted finite-architecture, fixed-review, exact-tube Operator II theorem. Paper 1 remains a journal article only if the pending novelty/nonduplication audit establishes that theorem—preferably with a nontrivial instantiation—as an independently citable contribution. If novelty or contribution fit fails, this material becomes the monograph/series introduction.

**Excludes:** full proof corpus, long computational bifurcation studies, domain calibration, and programme-wide results supported only by forward references.

### Paper 2 — Formal Mathematical Foundations and Theorem Atlas

**Primary question:** Which theorem families are rigorously established, under which exact assumptions, and how do they compose or fail?

**Sources:** proof-heavy A001–A002 material, canonical formal specification, repaired A006/A007 fragments, theorem/counterexample registers, selected A013 results.

**Content:** complete proofs and counterexamples for conservation, positivity, viability, robust/epistemic kernels, sampled/hybrid restrictions, noncompensation, substitution feasibility, information value, institutional rescue, intergenerational obstructions, bounded composition, and explicit failure boundaries.

**Rationale for separation:** this is an independently citable mathematical contribution and prevents Paper 1 from becoming unreadable or forcing proof loss into appendices.

### Paper 3 — Conserved Material Ledgers and Componentwise Depletion Diagnostics

**Primary question:** How should material stocks, services, products, waste, active/geological pools, and depletion diagnostics be represented without compensatory or double-counting errors?

**Sources:** A013, accounting/ledger portions of A018–A019, A024, compatible A004/A005 examples, relevant A002 general results.

**Content:** primitive-flux ledger; conservation/nonnegativity; active/geological and detritus closures; service readouts; componentwise deficit; substitution/support gaps; depletion horizons and first-passage semantics; verified groundwater/phosphate/fisheries examples at their exact status.

**Rationale:** coherent accounting/diagnostic audience and independent analytical contribution.

### Paper 4 — Delay-Driven Capital Liquidation and Nonlinear Institutional Dynamics

**Primary question:** How do delayed scarcity-mobilising and protective institutional channels generate or suppress Hopf crossings, cycles, bistability, and global periodic events in named C3/C4 models?

**Sources:** A003, A012, dynamical core of A018, A020, A025, relevant A019 corrections.

**Content:** named gated/ungated C3/C4 systems; equilibrium and characteristic equations; complete Hopf cubic; verified crossings and Lyapunov coefficients; branch continuation and Floquet evidence; fold status discipline; protective channel and two-delay identity; parameter windows; reproducibility and certification hierarchy.

**Rationale:** already meets the independence and technical depth expected of an applied nonlinear-dynamics paper. It should not be buried inside an accounting article.

**A018 seam decision:** the gate is closed by `A018_ledger_to_dynamics_interface_contract.md`. The natural cut is accounting/diagnostics versus named nonlinear dynamics. The exact shared object is the single-resource deficit identity `qEN-R=-dot N`; there is explicitly no exact dynamic reduction from the closed primitive finite-donor ledger to the working C4 field. Paper 4 therefore states its full named RFDEs and open/frozen-donor mass status locally, while Paper 3 owns the closed ledger and conservation proofs. This gives a reproducible, noncircular seam without pretending the two vector fields are identical.

### Paper 5 — Sampled Governance, Empirical Identification, and Falsification Design

**Primary question:** How do periodic review, observation, implementation delay, and uncertainty alter the mechanism, and how can it be tested empirically?

**Sources:** A011 V2, sampled-governance portions of A018, A014 corrected cod case, eligible A016 social/adaptive-capacity material, prospective MSE and event-panel designs.

**Content:** sample-and-hold model; review-interval spectrum; positivity; power analysis; case-screening and negative result; event panels/quasi-experimental timing; human-in-loop design; MSE; cod and other cases at correct causal status; distributive/adaptive constraints where reproducible.

**Rationale:** distinct empirical and methodological question, data requirements, audience, and validation standard.

## Sixth paper: near-ready but conditional on theorem completion

### Paper 6 — Yield-Gap Reduction and Periodic NAIM Persistence for Coupled RFDEs

**Primary question:** When does a weak vector-Liebig coupling preserve a compact periodic normally attracting invariant manifold and yield a vertical representation over the perturbed projected base?

**Sources:** A021, internal/external proof audits, A018-to-A021 crosswalk, C4 periodic-orbit/Floquet/CAP programme.

**Current content:** finite-time tracking; slack tube; equilibrium continuation; direct characteristic crossing; exact conditional Banach-semiflow template; selected C4 cycle and slack scaffold; numerical Floquet/product-bunching evidence; self-contained graph-transform theorem; CAP specification and partial interval work.

**Gate:** validated continuum orbit/Floquet/projection/product certificate and a declared coupling class or source-derived `G,f,g`.

**Until gate closure:** maintain as a technical preprint/research dossier, not force it into Paper 4's supplement.

## Conditional seventh paper

### Paper 7 — Stage-Structured and Spatial Delay Extensions

**Sources:** A022–A023 plus stage/spatial parts of the consolidated scaffold.

**Gate:** corrected stage modal theorem, complete parameter-version crosswalk, and an independent validated spatial or stage theorem/result.

**Fallback:** if the gate is not met, retain these as a substantial supplement to Paper 4. If the supplement reaches independent article scale and audience, count it honestly as Paper 7.

## Domain papers conditional on empirical closure

The phosphorus (A004), groundwater (A005), and distributive/adaptive (A016) modules should not be discarded. They become separate domain papers only after calibration, held-out comparison, and reproducible source pipelines. Until then their valid theory/examples belong in Papers 1, 3, and 5, with full technical material preserved in the programme archive.

## Rejected/superseded branches

A008, A009, A015, and A017 do not merit standalone positive-result papers. Their valid negative findings, counterexamples, and redesign requirements belong in Papers 1–2 and the traceability archive. “No separate paper” does not mean deletion.

## Final count

- **Assured minimum now:** 5 papers.
- **Near-ready conditional:** Paper 6 (A021 RFDE theorem).
- **Conditional methods extension:** Paper 7.
- **Possible later domain papers:** 1–3, only after empirical closure.

Thus the honest current architecture is **five assured papers, likely six, potentially seven or more as independent gates close**—not two or three.

## Federated orchestration and citation closure

The series uses Papers 1–2 as navigation anchors only, not as an unpublished proof hub. Papers 1–5 must each be independently readable, refereeable, and reproducible. A cross-citation may provide context, provenance, or reuse of a stably available result, but it may not carry a locally load-bearing definition, proof, dataset, or computational object. The publication graph therefore permits contextual and noncircular reuse edges but prohibits a chain in which Paper 1 depends on Paper 2 for its own result or Paper 2 depends on Papers 3–5 to supply theorem objects.

Each application paper carries a **Minimal Working Realization** of the canonical system: local variables/domains/units, exact state equation or model map, assumptions and boundary/event semantics, interface proposition, claim-status/version identifiers, and reproducibility pointers. It need not repeat the full ontology.

## Readiness-triggered release protocol

1. **Wave 0 — closure:** freeze the typed canonical schema/version; complete the A001–A025 destination concordance; close Paper 1's independent-result test; complete Paper 2's theorem-family map and length budget; decide the A018 seam; and create per-paper artifact manifests.
2. **Wave 1 — stable anchors:** release and submit any citation-closed Paper 1 and/or Paper 2 that passes its own gate. Use the actual repository identifier supplied; do not describe every preprint identifier as a DOI.
3. **Wave 2 — core problem papers:** release and submit Papers 3–5 independently as each passes its local proof/evidence, reproducibility, venue-policy, and length checks. No paper must wait for a particular editorial stage of another if citation closure is satisfied.
4. **Wave 3 — extensions:** release Paper 6 only after the A021 continuum/coupling gate and Paper 7+ only after its own independent gate.

Specific journals remain candidates until current scope, article type, length, companion-paper, preprint, and open-science policies are checked. Route by primary contribution and audience, not prestige alone.

## Synthesis products

The definitive monograph will reintegrate the uncompressed canonical narrative after sufficient module closure. The versioned reproducibility compendium will hold proof/data/code/version artifacts and retained conditional material. Neither product is an unlimited supplement, and neither changes the journal-paper count.

## Non-loss rule

Every valid source proposition must map to:

1. a specific paper section;
2. a proof/technical appendix or companion;
3. a conditional future-paper docket; or
4. an explicit negative/counterexample record.

No valid result may disappear merely because its source manuscript does not retain a standalone identity.