# Typed Canonical System and Theorem Schema — Version 1.0

## 0. Status and authority

**Status:** frozen programme interface specification, version `TCS-1.0`.  
**Scope:** source-to-source and source-to-publication interoperability across A001–A025.  
**Supersedes:** the object-level portions of `canonical_formal_specification_post_joint_audit.md`; source corrections and theorem cautions in that document remain in force.  
**Does not do:** assert that every module is one ordinary differential equation, promote conditional claims, or replace local equations and proofs.

A source result enters the integrated theory only through one of the admitted mappings in §7 and a concordance row carrying its assumptions, evidence status, destination, and artifacts.

## 1. Frozen specification

A sustainability specification is

\[
\Omega=(\mathcal T,\mathcal C,\mathcal N,\mathcal R,\mathcal H,\mathcal E),
\]

where:

- `𝒯` is the type and unit system;
- `𝒞` is the physical, functional, procedural, and outcome constraint registry;
- `𝒩` records declared normative authorities, populations, floors, and noncompensation rules;
- `ℛ` records identity, liability, obligation, and relationship semantics;
- `ℋ` declares horizons and decision/event clocks;
- `ℰ` declares epistemic status, uncertainty classes, and admissible evidence.

Changing a threshold, authority, population, horizon, information pattern, or admissible action class changes `Ω` unless an explicit comparison map is supplied.

## 2. Architecture realization

For architecture index `q∈Q`, define

\[
\mathfrak A_q=(\mathsf Z_q,\mathsf M_q,\mathsf D_q,\mathsf G_q,
\mathsf U_q,\mathsf W_q,\mathsf O_q,\mathsf B_q,
\mathsf P_q,\mathsf I_q,\mathsf L_q,\mathsf S_q,\mathsf K_{q,\Omega}).
\]

### 2.1 State object `𝖹_q`

`𝖹_q` is a typed product whose declared blocks may include:

- physical stocks/fields `x`;
- functional or capacity states `y`;
- RFDE histories `x_t`;
- algebraic/DAE variables `a`;
- institutional mode and memory `m`;
- observation/filter or belief state `b`;
- held commands, queues, and implementation states `c`;
- cumulative harm, obligation, or accounting states `h`.

The phase space is chosen by model class: finite-dimensional state, Banach history space, function space for spatial fields, hybrid/càdlàg state, probability/information state, or a typed product. A projection to physical coordinates is never silently treated as a closed state.

### 2.2 Model class `𝖬_q`

`𝖬_q` declares one or more well-posed evolution mechanisms:

\[
\begin{aligned}
\dot z(t)&\in F_q(t,z_t,u(t),w(t);\theta), && t\notin\mathcal E_q,\\
0&=G_q(t,z_t,u(t),w(t);\theta), && \text{algebraic constraints},\\
z(t^+)&\in R_{q e}(z(t^-),u_e,w_e), && e\in\mathcal E_q,\\
q^+&\in\rho_e(q,z(t^-),u_e,w_e), && \text{architecture/mode event},
\end{aligned}
\]

with an explicitly declared solution concept. This display is a **schema**:

- ODEs use memoryless single-valued `F_q`;
- RFDEs use history-valued `z_t`;
- PDE/RFDE systems use an operator on a declared function/history space;
- sampled systems use flows between review times plus a held command and reset/update map;
- stochastic systems replace or augment `F_q,R_q` by adapted coefficients, transition kernels, or disturbance laws;
- discrete-time systems use only the reset/update part;
- DAE blocks retain `G_q=0` and require consistency/regularity conditions.

No theorem transfers between these classes without the hypotheses required by the target solution concept.

### 2.3 Governance and uncertainty

- `𝖴_q(z)` is the physically admissible command/prescription correspondence.
- `𝖶_q` is the declared disturbance, adversary, model, or stochastic uncertainty class.
- `𝖮_q` is the observation map/kernel.
- `𝖡_q` is the assessment/filter/update operator producing information state `b`.
- `𝖯_q` is the causal policy class relative to the declared information filtration.
- `𝖨_q` maps prescribed actions through authority, compliance, enforcement, budget, latency, and deployment to realized actions.

Prescribed and realized actions are different types. Action-set inclusion supports existential viability monotonicity only when state, information, disturbance, horizon, and solution semantics are aligned.

### 2.4 Physical ledger and services

- `𝕃_q` is the typed ledger/flux object, including boundary flows, internal transfers, reactions, discrepancies, and jump balances.
- `𝕊_q` is the service/readout correspondence; it is not the observation operator.
- Conservation is conditional on a declared closure and moiety; positivity is conditional on boundary tangency, donor limits, and reset preservation.

### 2.5 Admissible set

`𝕂_{q,Ω}⊂𝖹_q` is generated from the typed registry and includes only constraints applicable to architecture `q`. It may encode physical, functional, distributive, procedural, relational, epistemic, and cumulative-harm conditions. Thresholds are declared normative/model inputs, not universal constants.

## 3. Canonical execution chain

At a decision time, the typed chain is

\[
\text{physical/history state}
\xrightarrow{\mathsf O_q}
\text{observation}
\xrightarrow{\mathsf B_q}
\text{information state}
\xrightarrow{\pi\in\mathsf P_q}
\text{prescription}
\xrightarrow{\mathsf I_q}
\text{realized action}
\xrightarrow{\mathsf M_q}
\text{trajectory/event law}.
\]

Every empirical or governance instantiation must specify each arrow or mark it absent. Observation, assessment, prescription, and implementation cannot be collapsed without an exact identification.

## 4. Canonical judgments

For fixed `(Ω,q,T)` and aligned classes:

1. **Controlled viability:** there exists an admissible causal policy and trajectory remaining in `𝕂`.
2. **Robust viability:** there exists one causal policy keeping every declared disturbance trajectory in `𝕂`.
3. **Fixed-policy safety:** one specified policy is safe against every declared disturbance.
4. **Epistemic viability:** robust viability on information/history state under observation-based policies.
5. **Institutional viability:** epistemic/robust viability after the implementation map restricts realized actions.
6. **Chance viability:** the pathwise safety event has declared probability under an explicit law and filtration.
7. **Recoverability:** a capture/reach-avoid-maintain judgment with target, envelope, horizon, policy, and disturbance classes.
8. **Transformability:** robust reach-avoid-maintain between architectures with typed translation of state, identity, obligation, and harm.

The official assessment tuple is

\[
J_\Omega=(P,F,N,R,E;\,\text{status},\text{scope}),
\]

where physical, functional, normative, relational, and epistemic components remain noncompensatory unless `Ω` explicitly defines a permitted aggregation.

## 5. Operator I, Operator II, and composition

### Operator I — within-architecture viability/recovery

`Op_I(Ω,𝔄_q)` returns the appropriately typed kernel, capture basin, safety certificate, or obstruction under declared quantifiers and horizon.

### Operator II — architecture transformation

`Op_II(Ω,𝔄_q,𝔄_{q'})` is a hybrid reach-avoid-maintain problem with transition-safe sets, review/event semantics, reset/translation maps, and cumulative identity/liability/harm constraints. Version 1.0 admits the proved finite-architecture, fixed-review, exact-tube predecessor construction; broader variable-event/stochastic/strategic forms remain open.

### Composition

For modules connected by interface contract `C_{ij}`, composition is admitted only after:

- compatible types and units;
- bounded interface signals on the proposed joint set;
- joint shared-control feasibility in the true control/implementation set;
- a measurable or regular selector/velocity envelope with a declared solution concept;
- explicit growth or forward-completeness control;
- nonblocking and non-Zeno event semantics when hybrid events are present;
- an applicable invariance/small-gain theorem.

The first controlling theorem is `A001_restricted_composition_theorem_corrected.md`. Its abstract proof uses proximal-normal inequalities and a regular compact-convex velocity envelope; it does not assume arbitrary contingent cones factor over products. Intersecting separately computed kernels or separately nonempty local control sets is not a joint-kernel proof.

## 6. Theorem record schema

Every integrated theorem/finding has the record

\[
\Theta=(\mathrm{id},\mathrm{class},\mathrm{premises},\mathrm{quantifiers},
\mathrm{state},\mathrm{horizon},\mathrm{claim},\mathrm{proof/evidence},
\mathrm{interfaces},\mathrm{limits},\mathrm{artifacts},\mathrm{status},\mathrm{version}).
\]

Required statuses are: `proved`, `conditional`, `numerically_verified_source_status`, `empirically_verified_source_status`, `conjecture`, `prospective_design`, `counterexample`, `rejected`, and `documentation_pending`. Computational or empirical truth status and publication-artifact completeness are separate fields.

## 7. Admitted source-to-canonical mappings

Each concordance row uses exactly one primary mapping type:

1. `EXACT_SPECIALIZATION` — instantiate canonical types/operators with no loss.
2. `EMBEDDING` — inject the source state/model into a larger canonical realization.
3. `PROJECTABLE_REDUCTION` — projection is dynamically closed; fibre criterion is proved.
4. `TRANSFORMATION` — architecture changes through an Operator II contract.
5. `APPROXIMATION` — error, domain, horizon, and safety erosion are explicit.
6. `COUNTEREXAMPLE_OR_LIMIT` — establishes a boundary or impossibility.
7. `ANALOGY_ONLY` — explanatory relation; cannot support theorem transfer.
8. `REJECTED_MAPPING` — attempted bridge is invalid.

A missing or merely verbal bridge is `UNRESOLVED`, not an exact specialization.

## 8. Interface contract

A bridge between modules `i→j` is publication- and theorem-eligible only if it records:

`(producer object, consumer object, type/unit map, state/version map, assumptions, mapping type, error/status, proof/evidence, artifact, failure condition)`.

For the A018 ledger-to-dynamics seam specifically, the producer must export a named state/flux vector, admissible set, conservation/positivity conditions, parameter version, and diagnostic readout; the consumer must import exactly that object or prove a labelled reduction.

## 9. Universal axioms and scoped principles

### Structural axioms

1. **Typed consistency:** equalities and compositions respect declared types and units.
2. **Physical closure honesty:** conservation claims name the system boundary, moiety, and unmodelled discrepancy.
3. **Causal admissibility:** policies use only declared information and implementation channels.
4. **Noncompensatory admissibility:** failure of a binding component is not erased by unrelated surplus unless `Ω` explicitly authorizes substitution and a pathway exists.
5. **Status monotonicity:** integration cannot strengthen proof/evidence status.
6. **Interface explicitness:** cross-module theorem transfer requires an admitted mapping and contract.
7. **Version identity:** coefficients, equations, artifacts, and results share a declared model/version identifier.

### Model-class-dependent principles

Delay-induced oscillation, fold persistence, spatial/stage effects, substitution elasticity, institutional latency, and empirical causal interpretation are not universal laws. They remain conditional on their local model and evidence classes.

## 10. Versioning and change control

`TCS-1.0` is frozen. A change to a type signature, canonical judgment, mapping class, or required theorem field creates `TCS-1.1` or `TCS-2.0` and requires migration entries in the concordance. Local notation may differ only through the notation/variant registry.

## Operator I strong-invariance and erosion correction

The controlling record is `A001_operatorI_strong_invariance_erosion_corrected.md`. Robust viability uses a matched all-solutions strong-invariance theorem, not weak viability. The general metric-erosion claim is rejected; only the conditional tubular lemma with `L_G r + Delta_epsilon <= alpha` is retained.
