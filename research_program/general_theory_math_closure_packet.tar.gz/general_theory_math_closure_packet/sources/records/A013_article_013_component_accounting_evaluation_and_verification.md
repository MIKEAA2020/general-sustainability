# Article 013 Evaluation and Verification

## Bibliographic identity

**Source file:** `uploads/paper1_accounting.txt`  
**Title:** *Componentwise Sustainability Accounting: Typed Stock–Flow Ledgers and Depletion Diagnostics*  
**Format:** LaTeX analytical/accounting article  
**Length:** approximately 4,909 words, 465 lines  
**Formal content:** typed balance and service framework, domain-qualified noncompensation argument, six-compartment material ledger, mass-conservation theorem, forward-invariance theorem, depletion-diagnostic taxonomy, three illustrative applications  
**Evaluation status:** analytical accounting core and reported application values accepted as verified on the user’s instruction; submission-stage source and reproducibility materials remain pending

## Executive assessment

The analytical core is correct and carefully scoped. The six-compartment incidence matrix conserves the represented material; the donor-boundary conditions establish nonnegative-cone invariance; the scalar noncompensation argument is correct; and the distinction among gross turnover, local net-depletion ratio, and scenario-conditioned hitting time is logically and dimensionally sound.

The paper’s main limitation is not mathematical correctness but overlap. Article 002 contains a more general typed flux architecture, hybrid conservation, nonnegative invariance, domain-qualified noncompensation, substitution feasibility, and diagnostic types. Article 013 provides a clearer bounded accounting exposition, a useful six-compartment worked ledger, and concrete diagnostic examples. Under the minimum-paper rule, it may be better integrated as the accounting/diagnostic foundation or technical supplement of the flagship rather than maintained as a separate paper, unless its applications and accounting methodology are developed into an independently substantial contribution.

The groundwater anomaly values and phosphate source quantities are accepted as verified on the user’s instruction. Their processing files, source extracts, and shared references are not currently in this workspace and remain submission-stage reproducibility materials. The phosphate reserve-life arithmetic is internally correct. The fisheries removals-only time scale is mathematically correct and appropriately labeled as an incomplete comparison process.

---

## 1. Typed physical and service layers

The paper correctly separates:

- physical stocks \(x\);
- service readouts \(s=\mathcal O(x,u,\theta)\);
- contemporaneous service balances \(b=s-d\);
- state-dependent attainable balance domains;
- regenerative/pathway-restricted service feasibility;
- trajectory-level viability.

The statement

\[
b_i(t)\ge0
\]

means current measured supply meets current measured demand. It does not imply stock preservation, future feasibility, or viability. This distinction is sound and valuable.

### Notation consideration

Using \(\mathcal O\) for a service readout can conflict with the master observation operator. A canonical notation should use a service map such as \(\Gamma_s\), \(Qv\), or \(\mathcal S\), reserving \(\mathcal O\) for measurement.

---

## 2. Directional support gap

The definition

\[
\alpha_{reg}(\bar s;x,t)
=
\sup\{\alpha\in[0,1]:\alpha\bar s\in\Gamma_{reg}(x,t)\}
\]

is valid as a ray-based service-support measure when \(0\in\Gamma_{reg}\).

### Qualification

If \(\Gamma_{reg}\) is not closed, the supremum may not be attained. The vector

\[
(1-\alpha_{reg})\bar s
\]

then describes a directional gap relative to a supremal fraction, not necessarily an achievable boundary service. State closedness/compactness or retain this qualification.

The article correctly does not interpret the service gap as physical stock depletion.

---

## 3. Noncompensation argument

For \(n\ge2\) and \(w>0\), the constructed vector with one arbitrary negative component and one compensating positive component satisfies

\[
w^\top b>0
\]

while violating componentwise nonnegativity. The argument is correct.

The domain qualification is essential: on a restricted feasible set \(\mathcal B(x,t)\), scalar certification can hold only if

\[
\mathcal B(x,t)
\cap
\{b:w^\top b\ge0\}
\subseteq
\mathbb R_+^n.
\]

The paper correctly says this must be proved from application-specific restrictions.

The proposed noncompensatory summaries—minimum margin, deficit norm, and maximum normalized deficit—are valid when reference scales and zero conventions are declared.

---

## 4. Six-compartment incidence ledger

Direct column-sum verification confirms

\[
\mathbf1^\top S(\alpha,\rho)=0.
\]

Every primitive process routes the same represented material among compartments:

- assimilation \(A\to X\);
- mortality \(X\to U\);
- harvest \(X\to U/P\);
- decomposition \(U\to A\);
- geological exchange \(G\leftrightarrow A\);
- mining \(G\to P\);
- retirement \(P\to U/W\).

The routing fractions \(\alpha,\rho\in[0,1]\) are constitutive choices, not universal constants. The article is explicit about this.

The service readout

\[
s_{harv}=(1-\alpha)h,
\qquad
s_{mine}=c_G
\]

is a valid illustrative delivery map and does not confuse internal assimilation with social service.

---

## 5. Mass conservation theorem

Term-by-term summation verifies

\[
\dot M=0,
\qquad
M=X+U+A+G+P+W.
\]

The proof is correct.

For an open version, explicit boundary fluxes yield

\[
\dot M=I_\partial-O_\partial.
\]

The paper correctly refuses to preserve nominal closure by allowing a finite donor to become negative.

---

## 6. Forward-invariance theorem

The donor conditions correctly make every outflow vanish on an empty donor face. Boundary checks verify:

- \(X=0\Rightarrow\dot X=0\);
- \(U=0\Rightarrow\dot U\ge0\);
- \(A=0\Rightarrow\dot A\ge0\);
- \(G=0\Rightarrow\dot G\ge0\);
- \(P=0\Rightarrow\dot P\ge0\);
- \(W=0\Rightarrow\dot W\ge0\).

Under local Lipschitz assumptions, \(\mathbb R_+^6\) is forward invariant. The theorem and proof are correct.

### Additional consequence

Conservation plus nonnegativity yields

\[
0\le z_i(t)\le M(0)
\]

for every compartment. With prescribed effort histories locally bounded on finite intervals and local Lipschitz rates, this also supports global continuation under standard ODE assumptions. The paper need not add this theorem, but the consequence is available.

---

## 7. Depletion diagnostics

### 7.1 Gross turnover

\[
J_A^{gross}=g/A
\]

has units time\(^{-1}\), and

\[
H_A^{gross}=(A-A_{min})/g
\]

has units time. Neither is a net depletion time. Correct.

### 7.2 Local net-depletion ratio

\[
H_A^{loc}
=
\frac{A-A_{min}}{[-\dot A]_+}
\]

with \(+\infty\) for nondeclining stock is a valid local constant-rate diagnostic, not a forecast.

### 7.3 Scenario-conditioned hitting time

\[
T_A(x_0;\pi,d)
=
\inf\{t:A^{\pi,d}(t;x_0)\le A_{min}\}
\]

is a valid trajectory-dependent threshold time. Under uncertainty, distributions or robust intervals are appropriate.

The three-way taxonomy is one of the paper’s strongest contributions.

---

## 8. Groundwater anomaly application

The index

\[
L_{hist}^{anom}
=
\frac{a_{latest}-a_{hist,min}}
{[-\widehat{\dot a}]_+}
\]

is dimensionally a time and is correctly labeled a historical anomaly-persistence index rather than an exhaustion forecast.

The reported basin trends and index values are accepted as verified within the research programme. Publication-level reproduction should provide:

- exact G3P release files;
- basin masks;
- reference-period and unit handling;
- temporal aggregation;
- trend estimator;
- endpoint/latest definition;
- historical-minimum calculation;
- processing code and output table.

The reported trend magnitudes, especially tens of centimetres per year, should be checked carefully against product units and whether values are storage-equivalent depth, cumulative anomaly, or another convention.

---

## 9. Phosphate reserve-life application

The arithmetic is correct:

\[
74{,}000\ \mathrm{Mt}
\div
240\ \mathrm{Mt/yr}
\approx308.3\ \mathrm{yr}.
\]

Rounded to approximately 309 years, this is a reserve-life ratio under constant production. It is not an exhaustion forecast because reserves are economic classifications that change with prices, technology, exploration, and regulation.

The precise USGS vintage and table will be supplied at submission. Resource and reserve thresholds must not be mixed.

---

## 10. Fisheries pressure time scale

For the comparison process

\[
\dot B=-F_{now}B,
\]

the threshold time is exactly

\[
\Theta_F
=
\frac{\log(B_{now}/B_{lim})}{F_{now}}.
\]

The formula is correct. The paper appropriately labels it a removals-only pressure time scale, not net depletion or demographic hitting time.

The net local ratio

\[
H_B^{loc}
=
\frac{B-B_{lim}}{[-\dot B]_+}
\]

requires an estimate of the complete biological balance. RAM SSB and fishing mortality alone do not supply a demographic model.

---

## 11. Ledger-to-viability bridge

The paper correctly states that accounting, current service adequacy, and trajectory viability are different certification questions.

A viability problem requires:

- physical safe set;
- demand-constrained admissible actions;
- information pattern;
- policy class;
- disturbance class;
- dynamics.

The paper does not claim to compute a kernel and correctly delegates this to the wider theory.

---

## 12. Overlap and canonical-source assessment

Article 002 contains more general versions of:

- typed physical fluxes;
- hybrid conservation;
- nonnegative invariance;
- domain-qualified noncompensation;
- support-provenance and substitution feasibility;
- diagnostic types;
- observation and viability architecture.

Article 013 remains valuable for:

- a clear bounded accounting exposition;
- the explicit six-compartment ledger;
- the service-readout example;
- the three depletion-time distinctions;
- grounded groundwater, phosphate, and fisheries illustrations.

Under the minimum-paper rule, Article 013 may not merit a separate paper if these components can be integrated into the flagship or a technical accounting supplement without loss. A separate accounting paper becomes merited only if the applications, comparative accounting method, or empirical validation become independently substantial.

---

## 13. Verification verdict

### Verified analytically

- componentwise/current-service distinction;
- feasible-domain qualification;
- directional support-gap definition, with attainment caveat;
- unrestricted noncompensation argument;
- incidence matrix and material conservation;
- nonnegative-cone invariance;
- gross/local/scenario depletion taxonomy;
- phosphate reserve-life arithmetic;
- removals-only fisheries threshold formula;
- ledger-to-viability distinction.

### Requires minor correction or documentation

- service-readout notation conflict;
- closedness/attainment of regenerative service fraction;
- optional global-continuation consequence;
- groundwater data processing and units;
- USGS source vintage;
- shared bibliography and computational supplement.

### Accepted as verified by user attestation, with submission materials pending

- groundwater trend and persistence-index values;
- basin-mask and product processing;
- phosphate reserve and production source quantities.

### Not established by this article

- empirical applicability of the six-compartment model as a joint system;
- any viability or policy result.

### Required status

**Analytical accounting core and reported application calculations accepted as verified; submission-stage reproducibility documentation remains; likely flagship/supplement integration rather than separate paper.**
