# A025 Evaluation — Interval Hopf Enclosures and Numerical Turning-Point Evidence

## Source identity

- Primary article source: `uploads/paper_VIII_interval_folds.txt`
- SHA-256: `7d6bffe7ade66f356852cdac6ef3f0c58da3d6d8592aee8ca9c9a9b4f9883457`
- Supporting status: `uploads/PAPER_VIII_VALIDATION_STATUS.md`
- Supporting protocol: `uploads/PAPER_VIII_CERTIFICATION_PROTOCOL.md`
- Threshold/model/notation/derivative registries also supplied.

## Verdict

A carefully scoped validation note and valuable technical supplement. It is now article-length, but it does not merit an independent publication identity under the minimum-leaning rule because it certifies or attempts to certify one numerical object of the unified applied model.

## Verified structure

- Collocation dimensions are corrected: 192 orbit coordinates plus period, 193 equations with phase condition.
- Moore–Spence count is 387 unknowns/equations after adding a 193-vector nullvector and delay.
- Fixed-parameter solver failure is correctly not treated as nonexistence.
- Discrete collocation proof and continuous-RFDE proof are correctly separated.
- Krawczyk inclusion and bordered infinite-dimensional lift requirements are appropriately stated.

## Current scientific status

- Hopf enclosures are accepted as externally verified interval certificates at their exact source-stated scope by explicit user attestation. The outward-rounded coefficient/equilibrium/phase pipeline remains a publication-archive obligation, not a truth gate.
- Small-branch continuation to approximately `tau=5.58667` is high-accuracy finite-dimensional numerical evidence.
- No converged Moore–Spence zero is available.
- No interval Krawczyk inclusion or interval nondegeneracy is available.
- No continuous-DDE bordered radii-polynomial proof is available.
- Therefore no periodic-fold certificate exists.

## Required corrections and completion

1. State the exact first-sine phase value and verify transversality to time translation.
2. Supply interval library, precision, rounding mode, parameter/equilibrium/coefficient enclosures, and branch-safe argument implementation.
3. Obtain a converged scaled Moore–Spence candidate.
4. Verify left/right nullvectors, transversality, and curvature.
5. Complete discrete Krawczyk inclusion.
6. Complete the bordered infinite-dimensional continuous-DDE lift before claiming a continuous fold.

## Publication decision

Technical/computational supplement to the unified applied ledger/dynamics article; no separate paper.