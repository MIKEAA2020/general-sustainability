# Article 012 Evaluation and Verification

## Bibliographic identity

**Source file:** `uploads/paper2_dynamics.txt`  
**Title:** *Delay-Amplified Extractive Mobilisation Under Stock Decline: A Registered Family of Renewable-Resource Models*  
**Format:** LaTeX analytical/numerical nonlinear-dynamics article  
**Length:** approximately 7,482 words, 581 lines  
**Formal content:** forward-invariance theorem, global-continuation corollary, characteristic-equation proposition, cubic Hopf-frequency theorem, model registry, algebraic reductions, extensive numerical bifurcation and sensitivity claims  
**Evaluation status:** analytical core verified; numerical propositions accepted as verified on the user’s instruction, with publication-level reproducibility documentation still pending; targeted model corrections remain

## Executive assessment

This is one of the strongest independently motivated paper candidates in the programme. It asks a bounded nonlinear-dynamics question, provides a fully displayed primary DDE, proves an invariant domain and global continuation, derives the equilibrium and characteristic quasi-polynomial, and gives a complete cubic enumeration of local Hopf-frequency families for the registered three-state linearization.

The analytical core is largely correct. The characteristic factorization and cubic modulus/phase construction verify. The parameter-scaling identifiability transformation is also correct. The manuscript is careful not to claim a universal delay threshold or a derivation from the general sustainability architecture.

The computational supplement, code, parameter/history files, continuation data, Floquet outputs, and shared bibliography were not attached in this workspace. The user has instructed that the numerical claims be treated as verified. Accordingly, this record accepts them at the precise status asserted in the source—numerical result, inferred numerical classification, or conjecture—while separately retaining publication-level reproducibility and provenance requirements. Several model-specific issues also require correction: the extinction face has an additional \(E=E_{max}\) boundary equilibrium; a fixed-demand stock-culling experiment is not donor-limited at zero; the active-pool turnover symbol changes from \(\omega_A\) to \(\kappa_A\); the MPF residual active-material boundary needs verification; and periodic-fold classifications require complete branch and multiplier evidence.

Under the minimum-paper rule, this article may genuinely merit a separate applied nonlinear-dynamics paper if its numerical supplement is complete and independently reproducible. Its analytical results and model-specific numerical programme are too specialized to place in full in the flagship. General-theory integration should be limited to the registered mechanism, theorem statements or examples, and lessons about model non-equivalence.

---

## 1. Primary three-state model: dimensional and constitutive checks

The model is

\[
\dot N=S(N)-qEN,
\]

\[
\dot Z=[\Phi_k(qEN-S(N))-Z]/\tau_m,
\]

\[
\dot E
=\left(1-\frac E{E_{max}}\right)
\left[
\eta E\left(\frac{Z(t-\tau)}{\Delta_{ref}}-rac E{E_{max}}\right)
+\delta_0\frac{Z(t-\tau)}{Z_{ref}+Z(t-\tau)}
\right].
\]

The stated units make the equations dimensionally homogeneous:

- \(N,K\): stock;
- \(E,E_{max}\): effort;
- \(q\): effort\(^{-1}\) time\(^{-1}\);
- \(Z,\Delta_{ref},Z_{ref},\delta\): stock/time;
- \(k\): time/stock;
- \(\eta\): time\(^{-1}\);
- \(\delta_0\): effort/time;
- \(\tau,\tau_m\): time.

The identity

\[
\max\{0,qEN-S(N)\}=\max\{0,-\dot N\}
\]

is exact. The signal is decline-rate based, not a stock-level scarcity measure.

### Constitutive caution

The outer effort gate makes \(E=E_{max}\) a tangent/frozen boundary: \(\dot E=0\) there regardless of signal. This is mathematically effective but substantively load-bearing. It should be interpreted as a hard saturation architecture, not a generic effort law.

---

## 2. Forward invariance

### Verification

For histories in

\[
0\le N\le K,
\qquad Z\ge0,
\qquad 0\le E\le E_{max},
\]

the boundary directions are correct:

- at \(N=0\), \(\dot N=0\);
- at \(N=K\), \(\dot N=-qEK\le0\);
- at \(Z=0\), \(\dot Z=\Phi_k(\cdot)/\tau_m\ge0\);
- at \(E=0\), \(\dot E=\delta_0Z_\tau/(Z_{ref}+Z_\tau)\ge0\);
- at \(E=E_{max}\), \(\dot E=0\).

With locally Lipschitz RFDE dynamics and nonnegative delayed history, the method-of-steps/tangent argument is valid. The theorem is correct.

### Clarification

The admissible-history set should explicitly mean that every history value lies in the box, not only the endpoint.

---

## 3. Boundedness and global continuation

The bound

\[
qEN-S(N)\le qE_{max}K
\]

holds on the invariant box because \(S(N)\ge0\) for \(0\le N\le K\). Monotonicity of \(\Phi_k\) yields a bounded input to the leaky \(Z\) equation, and variation of constants gives the displayed upper bound.

All state variables remain in a bounded set on which the RFDE right-hand side is locally Lipschitz. Standard continuation therefore gives a global classical solution. The corollary is correct.

---

## 4. Equilibria

At a positive equilibrium,

\[
qE^*N^*=S(N^*),
\qquad
Z^*=\Phi_k(0)=\delta,
\]

and the effort bracket gives the displayed quadratic. It has exactly one positive root. The condition

\[
0<E^*<\min\{E_{max},r/q\}
\]

correctly ensures an admissible positive stock

\[
N^*=K(1-qE^*/r).
\]

The equilibrium and local derivative \(\Phi'_k(0)=1/2\) are independent of \(k\), while global excursions may depend on \(k\).

### Extinction-face clarification

At \(N=0\), \(Z=\delta\), the bracket root gives the same interior-effort equilibrium, but the hard gate also makes \(E=E_{max}\) a boundary equilibrium. The text should say “an admissible positive bracket root” rather than implying uniqueness of all extinction-face effort equilibria.

The stock-direction eigenvalue at the bracket-root extinction equilibrium is \(r-qE^*\). Positive-stock existence changes at the same condition. A full transcritical classification would require the usual nondegeneracy checks.

---

## 5. Characteristic quasi-polynomial

Direct determinant calculation confirms

\[
P(\lambda)-C_ZL(\lambda)e^{-\lambda\tau}=0,
\]

with

\[
P(\lambda)
=(\lambda-A_N)(\lambda+d_m)(\lambda-C_E),
\]

\[
L(\lambda)
=B_E(\lambda-A_N)+A_EB_N.
\]

The linear coefficients follow correctly from the equilibrium, the inactive floor, and \(\Phi'_k(0)=1/2\). The gate derivative contributes no additional term because the inner effort bracket vanishes at the interior equilibrium.

The proposition and proof are correct.

---

## 6. Cubic Hopf-frequency theorem

For \(\lambda=i\omega\), squared modulus gives

\[
(x+A_N^2)(x+d_m^2)(x+C_E^2)
-
C_Z^2
\left[
B_E^2x+(A_EB_N-A_NB_E)^2
\right]
=0,
\]

where \(x=\omega^2\). This is a cubic in \(x\).

Conversely, every positive root gives unit-modulus ratio

\[
R=\frac{P(i\omega)}{C_ZL(i\omega)},
\]

and phase branches

\[
\tau_k
=
\frac{-\arg R+2\pi k}{\omega}.
\]

The proof is correct. Candidate points still require simplicity and transversality before being called Hopf crossings. The cubic bounds distinct positive frequency families by three but does not determine branch criticality or global folds.

This is a legitimate model-specific analytical contribution.

---

## 7. Model registry and reduction discipline

The registry correctly treats M3-U, M3-B, M3-LC, M4-A, and MPF as non-equivalent models rather than a derivation chain.

The projectability condition

\[
D\pi(y)f(y)=F(\pi(y))
\]

is a correct necessary condition for exact autonomous reduction and sufficient under uniqueness when the equality defines the reduced vector field along all fibres. Article 002 contains the canonical theorem.

The parameter identity \(\delta=\log2/k\) indeed yields

\[
\Phi_k(s)=\operatorname{softplus}_k(s)>0
\]

for finite \(s\), so the outer floor is inactive for the reported parameter vectors. This justifies smooth local and periodic-orbit calculations for those models.

---

## 8. Numerical-method and verification status

The described methods—root enumeration, characteristic-root tracking, fixed-step DDE integration, adaptive method-of-steps checks, collocation, shooting, Floquet analysis, and refinement—are appropriate in principle.

The numerical values are accepted as verified within the research programme. The following artifacts remain required for publication-level reproducibility and external audit:

- source code and model hashes;
- exact parameter/history files;
- characteristic-root and argument-principle implementation;
- continuation and collocation settings;
- shooting/Floquet routines;
- residuals and complete multiplier spectra;
- parameter grids and bisection logs;
- machine-readable branches and trajectories;
- independent rerun.

Multi-million-year integration can reveal slow transients but does not by itself justify threshold digits, as the article correctly states.

---

## 9. M3-U and M3-B numerical claims

The local thresholds, persistence boundaries, bistability windows, branch stability, inferred criticality, and sensitivity sweeps remain numerical propositions pending reproduction.

### Fold classification

A nontrivial Floquet multiplier crossing one is necessary evidence for a periodic-orbit fold but should be accompanied by branch turning, collision/continuation evidence, simplicity, and nondegeneracy. The claim of two distinct lower fold events is plausible but unverified without branch files.

### Criticality

Amplitude exponent near one-half and branch direction can support an inferred subcritical classification but do not replace a first Lyapunov coefficient. The article labels this appropriately.

### Basin statements

Multiple tested histories can demonstrate coexistence and distinct basins at tested points but cannot establish global monostability over all histories.

---

## 10. M3-LC two-channel extension

The local equality with M3-U when the recruitment floor is inactive is correct. Standing-stock culling and recruitment suppression can diverge during large excursions.

### Fixed-demand boundary problem

In the separate fixed-demand experiment with pure stock culling,

\[
C_{stock}=D>0
\]

remains positive at \(N=0\). The vector field therefore points through the nonnegative boundary unless the simulation stops at the hitting time or the culling flow is donor-limited.

The reported “time to zero” can be retained as a first-hitting-time result, but the post-hit model is not physically admissible as written. The experiment must state its stopping rule or use a donor-limited pressure.

The inter-locator discrepancy is correctly treated as localization uncertainty rather than ignored.

---

## 11. M4-A active-pool extension

The open relaxation term means the model is not a closed material ledger unless its external reservoir is represented. This is correctly stated.

### Notation inconsistency

The model equation uses turnover/relaxation symbol \(\omega_A\), while the numerical stability boundary is reported as \(\kappa_A\approx0.001316298\). Confirm whether these denote the same parameter. The notation must be harmonized before the threshold is cited.

All equilibrium, crossing, persistence, and turnover-threshold numbers require the supplement.

---

## 12. MPF primitive-flux core

The support-saturated stock identity

\[
\dot X
=(\mu-d)X-cX^2-qEX
=
rX(1-X/K)-qEX
\]

with

\[
r=\mu-d,
\qquad
K=(\mu-d)/c
\]

is correct for fixed interior \(A>0\) as \(K_A\to0\). It is not uniform at \(A=0\), and it does not reduce the full MPF system to M3-B.

### Active-material admissibility

Because

\[
A=\mathcal M-X-U,
\]

the model must verify

\[
X+U\le\mathcal M
\]

is invariant. The displayed \(X,U\) equations do not make this immediately evident. This boundary must be checked before calling MPF a physically admissible primitive-flux model.

The numerical Hopf, transient, basin, and parameter-sweep claims require reproduction.

---

## 13. Shared feedback architecture and identifiability

The local loop decomposition correctly separates ecological gain/phase, memory filtering, and delay phase. Sharing this algebra does not establish nonlinear reduction among models.

The effort-scale transformation

\[
E'=aE,
\quad
E'_{max}=aE_{max},
\quad
q'=q/a,
\quad
\delta_0'=a\delta_0
\]

leaves the \((N,Z)\) trajectory unchanged when effort histories are scaled accordingly. This proves structural non-identifiability of the separate effort scale, \(q\), \(E_{max}\), and \(\delta_0\) from \((N,Z)\) alone. The argument is correct.

---

## 14. Empirical and interpretive boundaries

The article appropriately states that:

- calendar-year thresholds are not portable theory constants;
- a complete nondimensionalization remains open;
- the effort law is phenomenological;
- ecological/governance lag literature is contextual rather than calibration;
- fishery application requires demographic and stage evidence;
- protective governance has a different sign and requires separate analysis;
- sampled review is not a continuous action delay.

These qualifications should remain.

---

## 15. Publication assessment

Article 012 can plausibly merit a separate applied nonlinear-dynamics paper if the computational supplement validates its model-specific numerical results. It has:

- an independent research question;
- a proved invariant domain and global continuation;
- exact equilibrium and characteristic algebra;
- a complete local frequency-family theorem;
- a registered non-equivalent model family;
- extensive numerical bifurcation and sensitivity claims.

This material is too specialized to place in full in the flagship. The flagship should use it as one registered institutional-feedback instantiation and as evidence that thresholds are architecture-specific.

The numerical results are accepted as verified for integration planning. Publication should still provide or archive the supporting computational record so readers can reproduce the results and distinguish numerical propositions from inferred classifications and conjectures.

---

## 16. Verification verdict

### Verified analytically

- dimensional assignments;
- decline-rate identity;
- forward invariance;
- boundedness/global continuation;
- interior equilibrium algebra;
- characteristic quasi-polynomial;
- cubic Hopf-frequency enumeration and phase branches;
- parameter-specific softplus identity;
- local equivalence of M3-LC with inactive floor;
- support-saturated logistic stock identity;
- effort-scale non-identifiability transformation;
- algebraic diagnostics of model non-equivalence.

### Corrections required

- extinction-face boundary equilibrium wording;
- fixed-demand culling stopping/donor rule;
- \(\omega_A/\kappa_A\) notation;
- MPF active-material boundary invariance;
- fold nondegeneracy evidence;
- complete computational and reference supplement.

### Unverified numerical propositions

All reported local thresholds, persistence boundaries, periodic branches/folds, Floquet multipliers, bistability windows, turnover boundaries, transient classifications, parameter sweeps, and negative screens are accepted as verified numerical work on the user’s instruction, subject to the source’s own qualifications. Their reproducibility archive remains a publication obligation, not a condition for internal acceptance.

### Required status

**Analytical and stated numerical core accepted as verified; targeted model corrections and publication-level reproducibility documentation remain; strong separate applied-dynamics paper candidate.**
