# Mathematical Issue Register — Current Status

## Purpose

This register distinguishes four categories that must not be conflated:

1. **Corrected:** the issue existed in an earlier draft but is fixed in the current canonical manuscript or later source.
2. **Superseded/rejected:** the issue remains in a preserved historical source, but that source or claim will not be integrated unless deliberately revived.
3. **Live correction required:** the issue remains in material currently considered for integration or publication.
4. **Diagnosed model flaw:** an article intentionally exposes the flaw as a negative result; it is not an error in that article.

Publication documentation and missing empirical development are recorded separately from mathematical correctness.

---

# A. Corrected issues — no further mathematical repair required

## A.1 Current master manuscript

| Historical issue | Correction now present |
|---|---|
| Policy \(\pi\) treated as an element of action set \(U\) | Separate action correspondence \(U^{impl}(z)\) and causal policy class \(\mathbb P^{impl}\) |
| Physical, functional, normative, and relational failures flattened | Typed registry and verdict \((P,F,N,R,E)\) |
| Transformation confined to one state space | Architecture registry and Operator II |
| Kernel nonemptiness treated as current viability | Actual-state membership required |
| Finite/infinite horizons mixed | \(\operatorname{Sust}_T\) and \(\operatorname{Sust}_\infty\) separated |
| Slack formula incomplete; disturbance family undefined | Upper/lower margins and nested disturbance family added |
| Temporary transition relaxation untyped | Transition-status tags, relaxation limits, and transition debt added |
| Viability, recovery, and transformation lacked one status map | Official system-level assessment map added |
| Epistemic status treated like an ordinary constraint | Evidence provenance, information state, policy restriction, and \(E\) verdict separated |

**Status:** corrected in `revised_sustainability_manuscript.md`.

## A.2 Article 011 version mismatch

The intended prospective-identification and uncertainty additions are present in canonical V2, `uploads/paper3_empirical.txt`. Earlier duplicate-upload confusion is resolved.

## A.3 Article 012 numerical truth status

Article 012’s source-stated numerical results are accepted as verified by explicit user instruction. Missing code/output files are submission-level reproducibility tasks, not an unresolved truth-verification issue.

## A.4 Article 013 application values

Groundwater and phosphate application values are accepted as verified by explicit user instruction. Source extracts and processing materials are submission documentation.

---

# B. Live mathematical corrections required

## B.1 Article 001 — broad viability/mathematical foundations

### A001-L1 — Robust tangency may establish weak rather than strong invariance

The proof must use a strong-invariance result appropriate to the disturbance inclusion. Require all closed-loop disturbance velocities to lie in the tangent cone and state regularity/solution assumptions.

**Action:** `V-A001-02`.

### A001-L2 — Order-minimal proof wording

Minimum harvest is the order-best trajectory. Its viability proves existence of a viable control; it does not imply every higher-harvest path is viable.

**Repair:** change the proof sentence; retain the existential kernel equivalence.

**Action:** `V-A001-03`.

### A001-L3 — Pollution-feedback comparison sign

For \(g_K\le0\) and \(K\le K_{max}\),

\[
g(S,K)\ge g(S,K_{max}),
\]

not the reverse.

**Action:** `V-A001-04`.

### A001-L4 — Capital lemma overstates higher-consumption safety

The kernel is viable because the controller may choose \(c=c_{min}\). Larger consumption need not preserve the capital floor.

**Action:** `V-A001-05`.

### A001-L5 — Generic non-polyhedrality proof incomplete

The algebraic-hypersurface argument does not fully justify the open-dense claim after existential slope/intercept elimination.

**Repair:** supply transversality/elimination or curvature proof, or demote to conjecture.

**Action:** `V-A001-06`.

### A001-L6 — Rosen uniqueness condition not proved for heterogeneous damages

The proof replaces heterogeneous \(d_i''\) by one common curvature.

**Repair:** impose common damage, prove a weighted Rosen matrix condition, or assume DSC directly.

**Action:** `V-A001-07`.

### A001-L7 — Commons obstruction lacks a precise safe-harvest/drift condition

Define \(H_{safe}(S)\) or state uniform negative drift on a boundary strip.

**Action:** `V-A001-08`.

### A001-L8 — Quota rescue conflicts with harvest floor

\[
\sum_i h_i^{quota}\le H_{min}
\]

is incompatible with required \(H\ge H_{min}\) unless equality holds.

**Repair:** equality or a declared safe interval.

**Action:** `V-A001-09`.

### A001-L9 — Sanction theorem proves no upward deviation, not unique quota choice

Add below-quota marginal conditions or weaken the conclusion.

**Action:** `V-A001-10`.

### A001-L10 — Ostrom sufficiency/necessity claims need separation

Constructed cases show each mechanism can be necessary somewhere, not universal necessity. The sufficiency proof must explicitly exhibit an enforceable viable policy.

**Action:** `V-A001-11`.

### A001-L11 — Implementation lattice is not downward closed

Correct monotonicity is

\[
U_1\subseteq U_2
\Rightarrow
\operatorname{Viab}(K;U_1)
\subseteq
\operatorname{Viab}(K;U_2).
\]

**Action:** `V-A001-12`.

## B.2 Article 002 — canonical typed architecture

### A002-L1 — Boundary-flux symbol typo

Use the declared \(\varphi\) symbol consistently in the conservation proof.

**Action:** `V-A002-02`.

### A002-L2 — Canonical notation collisions

Constitutive class, safe set, sink stock, architecture, assessment, and boundary symbols collide across sources.

**Repair:** complete the canonical notation bridge before merger.

**Actions:** `V-A002-03`, `V-A002-06`, `X-A001-A002-11`.

### A002-L3 — Selector status must remain explicit

The sampled/knowledge kernel results allow arbitrary pointwise selectors. Do not infer measurable, continuous, computable, or institutionally implementable selectors without additional hypotheses.

**Action:** `V-A002-07`.

**Already correctly qualified in source:** finite-clopen injective restriction, RFDE memory-reset interpretation, Hausdorff-continuity assumption, exact-filter assumption, and delay-dependent decay rate. These are not current errors.

## B.3 Article 003 — institutional-feedback stress-test note

### A003-L1 — Positivity, effort bounds, and RFDE well-posedness absent

Add phase space, histories, regularity, continuation, and boundary conditions.

**Actions:** `V-A003-02`, `V-A003-03`.

### A003-L2 — Sampled review lacks a bridge to continuous delay

Use Article 002’s comparison theorem or keep the models separate.

**Action:** `V-A003-06`.

### A003-L3 — Safety distance and basin wording

Distance zero need not mean unsafe intersection. Test signed/intersection margins and reachable tubes from declared safe initial sets.

**Actions:** `V-A003-07`, `V-A003-08`.

### A003-L4 — Persistence conjecture mixes dynamical classes

Restrict difference-operator contractivity and fold conditions to the relevant ODE/RFDE/neutral/hybrid class.

**Actions:** `V-A003-09`, `V-A003-10`.

## B.4 Article 004 — phosphorus module

These are live model-definition gaps, not failed theorems.

- Separate physical boundary flows from reporting error and structural discrepancy (`V-A004-02`).
- Add hybrid jump balance (`V-A004-03`).
- Verify donor/reset positivity (`V-A004-04`).
- Define \(\chi\) and functional dynamics (`V-A004-05`).
- Add upper soil-P bound where runoff risk requires it (`V-A004-06`).
- Separate action correspondence from policy class and replace overloaded notation (`V-A004-07`).
- Specify trade routing, delay, conservation, loss, authority, and uncertainty (`V-A004-08`).
- Define compatible-state topology and update (`V-A004-09`).

## B.5 Article 005 — groundwater module

- Route or remove unused \(q_{rel}\) (`V-A005-04`).
- Define leakage limiter dimensions/range/meaning (`V-A005-05`).
- Add total storage and jump identities (`V-A005-06`).
- Verify donor/recipient capacity and positivity (`V-A005-07`).
- Split solute mass by formation when concentrations/exchange matter (`V-A005-08`).
- Type reaction products and discrepancy (`V-A005-09`, `V-A005-14`).
- Rename overloaded action relation and define \(\chi\) (`V-A005-02`, `V-A005-10`).
- Define compatible-state topology/update (`V-A005-11`).

## B.6 Article 006 — epistemic-institutional viability

### A006-L1 — Critical predecessor/fixed-point mismatch

The recursion uses

\[
K_{n+1}=K_n\cap Pre(K_n),
\]

while Tarski is applied to

\[
T(Q)=S\cap Pre(Q).
\]

Use one operator consistently. Countable descent additionally requires continuity-from-above/compactness or else transfinite iteration.

**Actions:** `V-A006-06`, `V-A006-07`.

### A006-L2 — Successor update omits adverse branches

Make \(\Psi\) explicitly set-valued over implementation, disturbance, parameter, and observation outcomes.

**Action:** `V-A006-05`.

### A006-L3 — Information refinement needs a common comparison space

Compare physical projections or define a belief-space map.

**Action:** `V-A006-08`.

### A006-L4 — Common-action obstruction should use common safe prescriptions

A single prescription may induce state-dependent implementations. Define prescriptions whose entire implementation set is safe across the belief.

**Action:** `V-A006-09`.

### A006-L5 — Observer bound notation/scope

Use the missing dot product and add action admissibility, disturbance, active-boundary, and region-of-validity assumptions.

**Action:** `V-A006-10`.

## B.7 Article 007 — hybrid architecture

### A007-L1 — Discrete mode inside continuous history

Separate continuous physical/functional history from discrete institutional mode, or construct a proper hybrid history phase space.

**Action:** `V-A007-01`.

### A007-L2 — Institutional state duplicated

Do not include \(h\) both inside belief histories and as a separate coordinate.

**Action:** `V-A007-02`.

### A007-L3 — Full delayed reset semantics absent

Define post-reset phase history, event priority, local finiteness/non-Zeno, and continuation.

**Actions:** `V-A007-03`, `V-A007-04`.

### A007-L4 — Measurement/reclassification cannot create material

Internal reclassification preserves moiety total; nonzero correction is boundary transfer or epistemic discrepancy.

**Action:** `V-A007-05`.

## B.8 Article 011 — sampled governance/empirical paper

### A011-L1 — Hold/interpolation mismatch

Process equations use held \(E_n\), while the invariance proof permits convex interpolation. Specialize or generalize consistently.

**Action:** `V-A011-01`.

### A011-L2 — Missing \(\tau_m>0\) and parameter domains

**Action:** `V-A011-02`.

### A011-L3 — Softplus “boundary exactness” depends on \(\delta\)

At zero input, \(\Phi_k(0)=\max(0,\delta)\). State the positive baseline or set \(\delta=0\) for zero-boundary exactness.

**Action:** `V-A011-03`.

Retrospective simulations and empirical outputs remain at their recorded reproducibility status. V2 prospective additions are present and verified as text.

## B.9 Article 012 — registered delay dynamics

The analytical and source-stated numerical core is accepted as verified. Remaining live corrections are:

1. state the additional \(E=E_{max}\) extinction-face equilibrium (`V-A012-02`);
2. stop or donor-limit fixed-demand stock culling at zero (`V-A012-07`);
3. resolve \(\omega_A/\kappa_A\) (`V-A012-08`);
4. verify MPF active-material boundary \(X+U\le\mathcal M\) (`V-A012-09`);
5. retain fold/SNPO classifications exactly at source-stated status; publication archive pending.

## B.10 Article 013 — component accounting

The analytical and application values are accepted as verified. Remaining mathematical/editorial corrections:

- rename service readout to avoid observation-operator conflict (`V-A013-01`);
- add closedness/attainment qualification for \(\alpha_{reg}\) (`V-A013-02`).

---

## B.11 Article 014 — Northern cod model discrimination

The DFO Table A2 values and appendix toy integrations are partly verified, but the central result requires correction:

- the displayed `C(t)` model is nonautonomous unless catch is fixed;
- the sound exact result is a scalar-autonomous phase-line obstruction, not the submitted finite-time threshold trichotomy;
- the extra-loss threshold shift requires existence and production-maximum conditions;
- NCAM M is a model-conditional unobserved-death allocation, not an identified biological cause;
- annual SSB and a moratorium date do not identify a one-year governance lead or causal adequacy;
- constrained-M, institutional-margin, and ecosystem-discriminant calculations remain unreproduced.

**Actions:** `V-A014-01`–`V-A014-06`.

## B.12 Article 015 — rejected multi-domain branch

The rejection direction is preserved, but its claims that Northern cod collapse was biologically settled and governance was adequate are false/unsupported. Retain only as negative provenance unless an exact conjunction and counterexample are supplied.

**Actions:** `V-A015-01`–`V-A015-03`.

## B.13 Article 016 — adaptive-capacity/distributive module

The normative split and componentwise conjunction are useful. Live corrections are:

- update the current World Bank line to $3.00/day in 2021 PPP, or explicitly freeze a historical $2.15/day 2017-PPP analysis;
- align the declared licence-holder population with CSD-level data;
- construct a CSD-to-2J3KL crosswalk;
- archive queries, filters, code, and missing-value rules;
- define floors, baselines, authority, uncertainty, and diversification semantics;
- treat finite LogSumExp as a conservative certificate, not exact conjunction;
- distinguish descriptive coincidence from causal effects.

**Actions:** `V-A016-01`–`V-A016-08`.

## B.14 Article 017 — institutional-index negative result

A008's negative result is retained. Live corrections are:

- remove biological-cause and timing-adequacy claims about cod;
- archive the seven-row recalculation;
- restrict “margin failure” to the tested case and proposed sign, rather than rejecting all typed institutional margins.

**Actions:** `V-A017-01`–`V-A017-03`.

---

## B.15 Article 018 — applied ledger and delayed cores

**Corrected working source:** `revised_articles/A018_capital_liquidation_corrected.tex`.

Implemented: donor monotonicity, CES parameterization, Euclidean cone distance, demotion of the unsupported delayed reduction/Hopf transfer, source-wide global-event status control, and A019/A020/A024/A025 bridge sections. Computational claims remain accepted as externally verified at exact source-stated status. Remaining obligations are citation and publication-artifact documentation plus any future proof of the demoted reduction conjectures.

**Completed actions:** `V-A018-01`–`V-A018-06`. **Open:** `V-A018-07`, `P-A018-01`.

## B.16 Article 019 — finite-donor correction

**Corrected working source:** `revised_articles/A019_closed_ledger_corrected.tex`.

The mass/no-rest/integrability core is sound. Little-o notation, autonomous-system wording, and unsupported slow-detuning language were corrected. No live mathematical defect remains in the corrected note; publication documentation is inherited from the unified package.

## B.17 Article 020 — protective channel

**Corrected working source:** `revised_articles/A020_two_channels_corrected.tex`.

The no-positive-Hopf-frequency and weighted small-gain results are retained. The all-delay stability argument now states zero-root and characteristic-continuity requirements; interpolation conditions and numerical status were corrected. Computational results are externally verified at source-stated status; archive action `P-A020-01` remains.

## B.18 Article 021 — yield-gap invariant graph

**Corrected working source:** `revised_articles/A021_liebig_graph_corrected.tex`.  
**Joint proof authorities:** `research_program/external_reviews/joint_audit_A021_internal_ER006_ER010.md` and `research_program/external_reviews/joint_audit_A021_crosswalk_numerics_ER020_ER029.md`.

The expanded joint audit of the internal proof and ER006–ER012 confirms that finite-time tracking is the only unconditional perturbation theorem currently available from the original A021 coupling assumptions. Under additional explicit assumptions, it also accepts a slack tube, compact closed equi-Lipschitz history sets, equilibrium persistence (with the corrected sign relation between the equilibrium Jacobian and `Delta(0)`), and direct characteristic-crossing persistence. Periodic-orbit persistence remains conditional on a valid RFDE Poincaré return-map construction or an exact matched theorem. None of those proves a graph over a history region. The concrete invariant graph remains conjectural. A valid conditional NHIM template must use a compact finite-dimensional invariant binding manifold, the complete normal bundle, inverse-tangent/conorm bunching, localized Banach-semiflow hypotheses, stronger regularity for quantitative `C1 O(epsilon)` estimates, and a global projected-embedding argument. A nonlinear Hopf branch additionally requires the smoothness and nonlinear nondegeneracy assumptions of the exact RFDE Hopf theorem. ER013’s claimed full proofs do not close these obligations: its Lyapunov–Perron construction uses an invalid smooth phase-space/cutoff/cocycle reduction and incorrect contraction argument. ER014’s improved time-`T` graph transform is retained as a promising route but does not prove that the sampled invariant graph is invariant under every intermediate semiflow time, and its global bundle/embedding, derivative, attraction, and higher-jet arguments remain incomplete. Both ER013 and ER014 permit unstable complementary Hopf spectrum while making overly broad stability claims. ER015’s BLZ time-map report does not supply an exact theorem match. ER016 repairs major geometric and derivative steps; ER017, the final audit, correctly retains those lemmas as future proof material while leaving the exact Banach-semiflow theorem as controlling. The final hierarchy is: finite-time tracking, confined slack tube, equilibrium continuation, and characteristic crossing are proved under stated assumptions; compact-NAIM persistence and nonlinear Hopf remain exact-theorem conditional; the concrete A021 graph, Lyapunov coefficient, and orbital stability remain unverified. The corrected source uses the verified 1998 Memoirs AMS bibliography, keeps varying-delay parameterization as an explicit obligation, and implements the final hierarchy without promoting the concrete graph or nonlinear Hopf claims. Post-implementation ER018 correctly confirms that A021 does not instantiate a concrete binding block, but its claim of total data absence is too broad: corrected A018 contains candidate three-, four-, and five-state equations, parameter tables, delay structure, characteristic data, and selected Floquet evidence. Concrete verification remains blocked by the missing A021 selection/crosswalk and incomplete NAIM package. ER019’s invented two-state oscillator is rejected as non-A021 and internally incorrect because its claimed radius-$r_0$ cycle is not invariant for $d>0$. The subsequent ER020–ER029 joint audit implements only the surviving C4/C5 architectural crosswalk and caveated numerical status: a reproduced gated C4 cycle at $\tau=4.5$, three-level finite-history Floquet convergence, an empirical leading-multiplier envelope, a provisional identical-C4 slack equilibrium at $\tau=10$, and a prefactor-dependent bunching target. These are numerical verification records, not a continuum Floquet enclosure or a concrete persistence theorem. A phase-corrected 1025-mode Fourier seed and five-module validated-numerics specification are now documented, with numerical period, residual, and floor margin; outward-rounded radii-polynomial/Floquet/slack/bunching execution remains pending. The graph, source-derived $G,f,g$, rigorous projections/prefactors, exact BLZ match, nonlinear Hopf, and orbital stability remain conditional or open.

## B.19 Article 022 — stage harvest

**Corrected working source:** `revised_articles/A022_stage_harvest_corrected.tex`.

The two-stage balance now retains birth `B` and explains cancellation only in a donor-complete enlarged ledger. The no-two-crossing statement is a searched-set numerical result, not a structural proposition. Computational claims are externally verified. The cross-version stage-value conflict `V-A022-04` and publication archive `P-A022-01` remain open.

## B.20 Article 023 — spatial analysis

**Corrected working source:** `revised_articles/A023_spatial_corrected.tex`.

The stage Ricker factor, determinant proof, control-character corruption, and uniform modal hypothesis were corrected. Local delayed spatial Hopf remains open at the source-stated status. Stale coefficient transfer `V-A023-05` and publication archive `P-A023-01` remain open.

## B.21 Article 024 — first-passage proxies

**Corrected working source:** `revised_articles/A024_first_passage_corrected.tex`.

The surrogate mathematics and computational claims are verified at their declared scope. Only publication data/code documentation `P-A024-01` remains.

## B.22 Article 025 — interval-fold validation note

**Corrected working source:** `revised_articles/A025_interval_folds_corrected.tex`.

The Hopf interval certificates and all other computational claims are accepted at exact source-stated status by user attestation. The corrected source makes the hierarchy explicit: the periodic turning point is verified continuation evidence, not a fold certificate. Open research/certification tasks remain the Moore–Spence zero, fold nondegeneracy, Krawczyk inclusion, continuous-DDE lift, and exact phase-condition/transversality record (`V-A025-01`–`V-A025-04`). The interval/code archive remains `P-A025-01`.

The rest packet also records unresolved stage-equilibrium value discrepancies and stale `C_E` coefficients across variants; no value transfers until regenerated from one hashed model/parameter version.

**Actions:** `V-A025-01`–`V-A025-05`, `V-A022-04`, `V-A023-05`.

---

# C. Superseded or rejected branches — do not repair unless deliberately revived

## C.1 Article 008 institutional solvency index

The current index/table is rejected with reason:

- USD mislabeled as exergy;
- \(\alpha\) mislabeled dimensionless;
- table arithmetic errors;
- no causal link to decision speed;
- unsupported threshold;
- necessity/sufficiency confusion;
- invalid falsifier;
- invalid RCI;
- unsupported Tainter duality.

**Status:** preserve research question; redesign from scratch if revived. Do not integrate current results.

## C.2 Article 009 distributive KS barrier

The current theorem/empirics are rejected with reason:

- heterogeneous dimensional quantities inside LogSumExp;
- false finite-\(\rho\) equivalence;
- static smooth minimum mislabeled CBF;
- incorrect global-decile pooling;
- malformed cohort transition;
- unsupported Simpson label and regional four-axis results;
- incoherent falsification logic.

**Status:** preserve distributive objective; redesign from normalized exact margins, valid data, and dynamics if revived.

## C.3 Duplicated theorem/architecture drafts

A006/A007/A010 material duplicated by stronger A001/A002/master sources should be marked superseded-but-preserved after unique content is extracted. There is no need to repair every duplicate proof for publication.

---

# D. Diagnosed model flaws — not errors in the diagnosing article

## D.1 Article 010 ten-state scaffold

Article 010 correctly diagnoses that the displayed scaffold is not physically or mathematically complete:

- \(G\) boundary can become negative;
- variance can become negative and covariance is unclosed;
- output \(Q\) is undefined;
- the system does not define a unique autonomous DDE;
- historical spectral targets are not propositions of that unclosed scaffold.

These are **negative findings of Article 010**, not mistakes in Article 010. Repair is needed only if the ten-state model is revived. Its audit should be preserved in a supplement.

## D.2 Article 003/A010 warnings about nonlinear safety

Their warnings that bifurcation existence, persistence, and safety relevance are distinct are correct. A012 later supplies verified model-specific bifurcation evidence but does not invalidate the warnings.

---

# E. Publication-documentation tasks — not mathematical errors

The following are accepted as verified by user instruction but still require submission/reproducibility packages:

- A012 numerical bifurcation, continuation, Floquet, basin, and sensitivity results;
- A013 groundwater and phosphate application values.

A011 retrospective numerical and empirical results have not received the same blanket verification instruction and remain under their registered reproducibility gate.

---

# F. Current highest-priority live repairs

1. Canonicalize A001/A002 notation, policy classes, and theorem sources.
2. Repair/replace A001 strong-invariance, Rosen, quota/sanction, and implementation-lattice claims.
3. Resolve A006’s fixed-point operator or supersede it explicitly with A001/A002.
4. Resolve A007’s hybrid phase-state error before extracting its unique taxonomy/admission standard.
5. Apply the small A011/A012/A013 corrections before publication integration.
6. Do not spend effort repairing A008/A009 unless their modules are deliberately redesigned.
7. Preserve A010 as a negative model-audit result rather than treating its diagnosed scaffold flaws as article errors.

This status-controlled register is the authoritative mathematical repair list for future integration work.
