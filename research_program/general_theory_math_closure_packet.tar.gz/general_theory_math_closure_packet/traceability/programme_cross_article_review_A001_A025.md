# Cross-Article Review: Articles 001–025

## Purpose

This review reassesses every submitted article in light of later sources, including the four final-labelled submissions A014–A017. Final-labelled files are still independently verified before integration. It distinguishes:

- results that are now supported by stronger later mathematics;
- early gaps partially or fully closed by later numerical or empirical work;
- material that remains only a template or conjecture;
- flawed branches that should remain rejected;
- canonical source selection and publication implications.

No source is deleted. Earlier formulations that are superseded remain preserved with provenance.

---

## 1. Emerging source hierarchy

### Tier 1 — General architecture and formal foundations

- **A002** — strongest current typed flux–observation–governance architecture and restricted constructive theorems.
- **A001** — broadest mathematical viability, recovery, resource/economic, coupling, commons, institution, intergenerational, and stochastic result family.
- **Current master manuscript** — highest-level specification, typed judgments, transformation operator, commons, and publication-wide synthesis.

### Tier 2 — Registered analytical/numerical mechanism papers

- **A012** — strongest registered delayed extractive-mobilisation analytical and numerical model family; numerical work accepted as verified at source-stated status.
- **A011 V2** — sampled-review model, empirical/spectral/case-search evidence, prospective identification, and MSE programme; retrospective results still await workspace reproducibility materials.

### Tier 3 — Accounting and domain modules

- **A013** — verified componentwise accounting core and verified application values by user attestation.
- **A004** — phosphorus/agriculture/catchment module template.
- **A005** — groundwater governability module template.

### Tier 4 — Unique fragments from superseded drafts

- **A006** — useful \((B,h)\), authority, implementation, and lower-game formulation; central fixed-point theorem flawed and duplicated.
- **A007** — useful failure taxonomy and domain-module admission standard; phase-space architecture flawed and otherwise superseded.
- **A010** — useful ten-state admissibility audit and reproduction targets; architecture/theorems largely superseded by A002.
- **A003** — concise institutional-feedback and nonlinear-safety framing; later developed by A011–A012.

### Tier 5 — Rejected branches requiring redesign

- **A008** — institutional “exergy solvency” index invalid in current form.
- **A009** — distributive KS/CBF and empirical construction invalid in current form.

---

## 2. Gap-closure review

### 2.1 Groundwater: template versus empirical content

**Initial gap:** A005 supplied a typed groundwater architecture but no calibrated basin, observation filter, kernel, or empirical result.

**Later support:**

- A013 supplies verified G3P basin-anomaly trend and persistence-index applications.
- A011 reports structured groundwater case work for Sheridan-6, Bangkok, and La Mancha, including exploratory calculations and confounding analysis.
- A002 supplies the observation/information and sampled-control theorem architecture needed for a future basin kernel.

**Closure status:** **Partially closed.**

What is now supported:

- real groundwater data can populate diagnostic and model-comparison layers;
- basin-level observation, climate confounding, implementation lag, and spatial heterogeneity are concrete rather than purely hypothetical;
- a groundwater module has plausible empirical entry points.

What remains open:

- full A005 fast/slow two-pool calibration;
- formation-specific solute model;
- compatible-state update;
- institutional action/policy model;
- kernel or capture-basin computation;
- held-out H0/H1/H2 comparison.

**Integration decision:** A013 and A011 should be cited as partial empirical grounding for A005, not as validation of the entire groundwater architecture.

---

### 2.2 Phosphorus: template versus empirical content

**Initial gap:** A004 supplied a multi-scale phosphorus/agriculture/catchment architecture but no calibrated trade, soil, crop, recovery, or receiving-water model.

**Later support:**

- A013 supplies a verified phosphate reserve-life accounting example and rigorous material/service/depletion distinctions.
- A002 supplies typed moiety conservation, substitution feasibility, observation, and multiscale research architecture.
- A001 includes four-stock material balance and resource/sink viability structures relevant to nutrient modules.

**Closure status:** **Partially closed, narrowly.**

The reserve accounting and general typed ledger are grounded. The agricultural, trade, recovery, erosion, soil-function, and catchment-water components are not empirically closed.

**Integration decision:** Use A013 to ground the extraction/reserve-accounting part of A004. Do not represent the full phosphorus–agriculture–catchment module as validated.

---

### 2.3 Nonlinear transitions, periodic folds, and SNPO evidence

**Initial gap:** A003 described nonlinear-transition and structured-persistence requirements but contained no demonstrated Hopf crossing, periodic branch, Floquet evidence, or fold.

**Intermediate audit:** A010 preserved historical crossing/fold targets but correctly withheld numerical-proposition status from an unclosed ten-state template.

**Later support:** A012 provides:

- verified model-specific characteristic and cubic frequency theory;
- source-stated verified numerical Hopf crossings;
- continued periodic branches;
- Floquet multipliers;
- two distinct lower periodic-orbit fold events in M3-B;
- upper persistence boundary with classification still open;
- basin-dependent coexistence and global sensitivity results.

**Closure status:** **Substantially closed for the registered M3-U/M3-B family, not generally.**

Important qualification:

- the later evidence does not prove persistence under arbitrary vector/RFDE/hybrid coupling;
- the lower boundary is not one simple collision of a stable and unstable branch; distinct folds are reported;
- the upper fold type remains open where the source says it is open;
- general safety relevance still requires a declared safe set and reachable-tube analysis.

**Integration decision:** Merge A003’s conceptual safety criteria with A012’s registered model results. Preserve A010’s negative audit of the unclosed ten-state scaffold as a warning against transferring A012 thresholds to other models.

---

### 2.4 Sampled governance and empirical identification

**Initial gap:** A003 framed sampled governance but had no complete sampled model or empirical design.

**Later support:** A011 V2 supplies:

- a displayed sample-and-hold model and positivity result;
- governance-time ontology;
- sampled-review response summaries;
- RAM spectral screen;
- power analysis;
- structured case search;
- governance-event panels;
- quasi-experimental timing designs;
- held-out mechanism comparison;
- human-in-the-loop experiment design;
- closed-loop MSE with separated uncertainty classes.

A002 supplies the canonical finite-horizon sample-and-hold consistency theorem and restricted sampled/information kernels.

**Closure status:** **Formally strong and prospectively well developed; retrospective evidence only partially closed.**

The retrospective numerical and empirical outputs remain accepted only at their current recorded status; workspace-level source/code reproduction is still pending except where separately attested. The prospective designs are not completed experiments.

---

### 2.5 Epistemic and institutional viability

**Initial gap:** Early architecture drafts identified partial observation and authority but lacked a clean theorem hierarchy.

**Later support:**

- A001 provides robust, epistemic, institutional, observer, common-action, information-value, and recovery results.
- A002 provides exact observation-fibre results and restricted sampled, finite-clopen, RFDE, hybrid, and compact-information kernels.
- A006 provides a concise \((B,h)\), authority, and implementation formulation but has a fixed-point operator error.
- A007 supplies a useful failure taxonomy and admission standard but has a phase-space duplication error.

**Closure status:** **Closed for a rich hierarchy of restricted classes; open for the most general variable-event delayed-hybrid case.**

**Canonical decision:** Use A001–A002 as theorem sources. Integrate A006’s institutional formulation and A007’s taxonomy/admission standard after correction. Do not publish duplicate theorem families.

---

### 2.6 Accounting, noncompensation, and depletion diagnostics

**Initial gap:** General architecture needed a concrete accounting layer and clear diagnostic semantics.

**Later support:**

- A013 provides a verified six-compartment ledger, conservation and positivity proofs, service readout, noncompensation, support gap, and gross/local/scenario depletion distinctions.
- A002 provides the more general hybrid conservation, positivity, noncompensation, and Farkas substitution results.
- A001 provides resource/sink and intergenerational mathematical consequences.

**Closure status:** **Strongly closed at the analytical accounting level.**

Application-level support:

- A013 groundwater and phosphate values are accepted as verified by user attestation;
- fisheries pressure time is analytically verified and appropriately limited.

**Canonical decision:** Use A002 for general theorem statements and A013 for the worked ledger and diagnostic exposition.

---

### 2.7 Substitution

**Later synthesis:**

- A001: dimensionally correct CES thresholds and essentiality/unbounded-substitution distinctions.
- A002: explicit pathway feasibility, directional support gap, and Farkas infeasibility certificate.
- A013: service-support gap and accounting interpretation.
- A004: phosphorus recovery/substitution pathway requirements.

**Closure status:** **Strong formal foundation, empirical pathway validation open by domain.**

These results are complementary rather than substitutes for one another.

---

### 2.8 Composition, coupling, networks, and commons

**Later synthesis:**

- A001 supplies a restricted composition theorem, patch coupling destruction/rescue, cascade-network results, commons games, and institutional rescue.
- A002 supplies typed interfaces, exact-model maps, and restricted hybrid/information structures.
- A004–A005 provide concrete trade, catchment, groundwater, and jurisdictional interfaces.

**Closure status:** **Restricted theorems and counterexamples exist; a general compositional theory remains open.**

The project now has enough content to state a nontrivial bounded composition theorem plus explicit limitations.

---

### 2.9 Intergenerational structure

- A001 supplies generation-indexed sets, nested-set impossibility under compactness, and discounting counterexample.
- A002 supplies recursive continuation-set semantics.
- A009’s cohort tensor is malformed and should not be used.

**Closure status:** **Formal structure partially closed; empirical cohort implementation and distributive indicators remain open.**

---

### 2.10 Institutional operationalization

**Invalid branch:** A008’s exergy/fiscal solvency index, threshold, table, and falsifiers remain rejected.

**Valid replacement path:**

- A001/A006/A007: information, authority, implementation, enforcement, and failure taxonomy.
- A002: observation–assessment–command–deployment chain.
- A011 V2: event-panel, quasi-experimental, human-in-the-loop, and MSE designs.
- A012: model-specific delay/gain/phase mechanisms.

**Closure status:** **Conceptually and methodologically strong; scalar empirical metric still open.**

A vector/viability-based institutional capacity measure is now better supported than A008’s scalar ratio.

---

### 2.11 Distributive operationalization

**Invalid branch:** A009’s heterogeneous-unit KS formula, finite-\(\rho\) iff theorem, pooled-decile construction, cohort inequality, and four-axis empirical claims remain rejected.

**Valid foundation:**

- master typed normative/relational registry;
- A001 distributional-floor theorem;
- A002 noncompensation and safe-and-just architecture;
- A013 noncompensatory component accounting;
- A007 failure taxonomy and admission standard.

**Closure status:** **Normative and formal foundation exists; valid multidimensional empirical operationalization remains open.**

---

## 3. Cross-source contradictions and resolutions

| Issue | Earlier source | Later source/resolution |
|---|---|---|
| General fixed-point theorem | A006 | Use corrected A001/A002 formulations; repair operator mismatch |
| Continuous history containing discrete mode | A007 | Use A002 hybrid phase-state constructions and separate \((x_t,h)\) |
| Unclosed ten-state spectral thresholds | A010 | Do not use; A012 supplies closed registered three-/four-state results |
| No SNPO/fold evidence | A003/A010 | A012 supplies verified numerical fold/Floquet evidence for registered models |
| Groundwater lacked data | A005 | A013 and A011 provide partial empirical grounding, not full module validation |
| Phosphorus lacked data | A004 | A013 provides reserve accounting only; catchment/agriculture gap remains |
| Institutional scalar ratio | A008 | Rejected; use vector/viability and prospective identification from A011 |
| Distributive KS theorem | A009 | Rejected; use typed exact margins and future validated indicator work |
| Long rapid-review proof condensed | A011 | Legitimate because A002 retains canonical theorem/proof |
| Numerical A012 evidence absent locally | A012 | Accepted as verified by explicit user instruction; publication archive pending |
| A013 application files absent locally | A013 | Values accepted as verified by explicit user instruction; submission archive pending |

---

## 4. Revised publication-role assessment

### Strong flagship core

- current master architecture;
- A002 canonical typed architecture and restricted theorem suite;
- selected A001 general viability/coupling/economic/institutional results;
- A013 accounting exposition and worked ledger;
- A004/A005 as bounded domain-module examples, clearly marked partial.

### Strong separate-paper candidate

- **A012** applied nonlinear dynamics, assuming publication archive and targeted corrections.

### Promising separate empirical/computational candidate

- **A011 V2**, if retrospective results become fully reproducible and prospective designs are executed or developed sufficiently.

### Supplement/model-audit destinations

- A010 ten-state admissibility audit and reproduction targets;
- A003 conceptual institutional-feedback framing;
- unique A006/A007 institutional-state and failure-taxonomy material.

### No separate paper in current form

- A004, A005, A006, A007, A008, A009, A010, A013.

A001’s final role remains a major publication-architecture decision: it may be a technical companion or a substantial formal supplement to the flagship.

---

## 5. Updated top priorities after cross-review

1. Canonicalize A001/A002/master notation and theorem sources.
2. Integrate the now-strong accounting layer from A002+A013.
3. Build the canonical epistemic/institutional hierarchy from A001+A002 plus unique A006/A007 pieces.
4. Formalize Operator II transformation.
5. State a restricted composition theorem using A001 and typed contracts.
6. Choose one empirical domain case:
   - groundwater now has more empirical support but not a full kernel;
   - phosphorus has verified reserve accounting but weaker catchment/agriculture data.
7. Prepare A012 as the leading independent applied-dynamics candidate.
8. Advance A011 V2’s reproducibility and prospective identification programme.
9. Redesign—not patch—A008 and A009 only after the core and one domain case.


## 5. Update for Articles 014–017

### 5.1 A014 — Northern cod strong-depensation test

A014 introduces the first tightly named fisheries case and verifies several DFO Table A2 values. Its useful formal contribution is an exact-trajectory obstruction for a fixed autonomous scalar ODE: a nonconstant one-dimensional autonomous solution cannot reproduce repeated rising-and-falling motion across the same state interval. The submitted threshold trichotomy is broader than the proof supports because the displayed model includes time-varying catch, finite-time recovery is not bounded, and observation/process error is ignored.

A014 does not identify an Allee mechanism or biological cause. NCAM M is estimated within a model and DFO proceedings caution that unreported deaths may enter de-facto M. The crash/non-recovery split is retained; constrained-M, institutional-margin, and ecosystem discriminant calculations remain unreproduced.

**Cross-source effect:** A014 strengthens A011's empirical case layer and supplies a fisheries counterexample for the flagship. It does not replace the groundwater-first end-to-end architecture test and does not alter A012's separate dynamics role.

### 5.2 A015 — rejected multi-domain collapse synthesis

A015 is an abandoned-branch audit, not a paper candidate. It reinforces the antitheorem that fast control cannot reverse every physical obstruction and that a generic conjunction is not a cross-domain collapse law. Its claims that cod collapse was biologically settled and governance adequate are rejected.

**Cross-source effect:** preserve as provenance and use only its self-contained negative logic. It creates no publication identity.

### 5.3 A016 — adaptive capacity and Boundary 6

A016 provides a useful typed normative split, componentwise noncompensatory margins, and an anti-domination residue. It partially advances the distributive redesign beyond A009 by naming a population and real instruments. It does not operationalize B6: the declared licence-holder population differs from the CSD data, the 2J3KL geography is not crosswalked, and the extraction is not archived.

The World Bank's current primary international poverty line is $3.00/day in 2021 PPP; $2.15/day in 2017 PPP may be retained only for an explicitly historical vintage-consistent analysis.

**Cross-source effect:** integrate definitions and cautions into the flagship distributive module. Link the proposed social series to A014/A011 only after a reproducible data and geography pipeline exists. No separate paper now.

### 5.4 A017 — institutional index negative result

A017 concisely confirms the registered rejection of A008: dimensional contradiction, dollar/exergy confusion, arithmetic failure, unsupported threshold, and perverse construct ordering. It correctly resists another master scalar. It overreaches when it treats NCAM M as an identified biological cause or uses one case to invalidate every typed institutional margin.

**Cross-source effect:** A017 strengthens the A008 rejection record and the accepted profile-plus-latency-plus-kernel redesign. It does not revive A008 or merit a separate paper.

## 6. Revised source hierarchy and publication implications

The prior hierarchy remains stable. A014–A017 do not displace the master/A002/A001 formal spine, A012's separate dynamics paper, or A011's conditional empirical role.

- A014 is a conditional empirical case contribution to A011 or the flagship.
- A015 is an archived negative branch.
- A016 is a conditional distributive/normative module contribution.
- A017 is the concise negative record for A008.

The assured publication identities remain the flagship/formal synthesis and A012. A011 remains conditional. None of A014–A017 presently merits an additional separate identity under the minimum-paper rule.

## 7. Updated priorities after A014–A017

1. Correct A014's autonomy theorem and reproduce its constrained-M and margin calculations.
2. Build the CSD-to-2J3KL and CSD-to-licence-holder distinction before using A016 empirically.
3. Update A016's poverty-line vintage and lock all queries.
4. Preserve A015/A017 as negative records; do not spend core effort polishing them into papers.
5. Cross-link the corrected A014/A016 evidence to A011 without upgrading causal status.
6. Continue the canonical Operator I/II, composition, groundwater, A012, and A011 priorities unchanged.


## 8. Update for the coordinated A018–A025 packet

### 8.1 Relationship to the established hierarchy

A018 is not a new general-theory spine. It is an applied ledger/dynamics candidate that overlaps and extends A012, draws accounting distinctions from A013, sampled-governance material from A011, and nonlinear-transition framing from A003/A010. A019–A025 are companion modules around that same applied object.

The packet therefore does not displace the master/A002/A001 formal hierarchy and does not add eight publication identities.

### 8.2 Strong additions

- A019 supplies the decisive finite-donor correction: the working four-state equilibrium is not an interior rest of the closed primitive system, and sustained extraction is bounded by finite mass.
- A020 supplies the needed opposite-sign protective channel and a restricted two-delay small-gain theorem.
- A024 gives a mathematically clean interpretation of the empirical proxies without confusing them with model-generated depletion times.
- A023 supplies useful mean-field spatial results and a careful open status for local delayed spatial Hopf.
- A025 prevents continuation evidence from being misreported as an interval-certified fold.

### 8.3 Critical corrections

- A018 has a donor-fraction sign error, inconsistent CES parameterization, overstatused delayed Tikhonov theorem, and fold language exceeding A025.
- A021's invariant graph lacks normal/tangent domination, compactness, and a matched RFDE persistence theorem.
- A022's mass theorem drops the birth inflow.
- A023's stage derivative misses a factor and its source contains a control-character corruption.
- By explicit user attestation, all computational claims are accepted as verified at exact source-stated status. Their cited code, parameter, interval, branch, and machine-output artifacts remain publication-documentation obligations; empirical source provenance remains separately auditable.

### 8.4 Publication architecture after full-program reassessment

The earlier two-identity conclusion was a packet-level provisional compression and is superseded. It conflated source consolidation with publication consolidation and treated the supplement as an unlimited repository. Under the joint minimum-paper and non-loss rules, the current assured minimum is five coherent papers:

1. general theory and research architecture;
2. formal mathematical foundations and theorem atlas;
3. conserved material ledgers and componentwise depletion diagnostics;
4. delay-driven capital liquidation and nonlinear institutional dynamics;
5. sampled governance, empirical identification, and falsification design.

The ER039–ER043 joint audit retains this partition but adds binding tests: Paper 1 must have an independently citable result and Paper 2 must be internally motivated and theorem-complete. The Paper 3/Paper 4 seam is now closed by `A018_ledger_to_dynamics_interface_contract.md`: the exact interface is the single-resource diagnostic identity, while exact dynamic reduction from the closed primitive ledger to the working C4 field is explicitly rejected. The sequence is five now; Paper 6 only after internally schedulable A021 proof closure; Paper 7+ only after independent later gates. “Five now” does not mean submission-ready. Full rationale, dependency rules, and readiness waves are in `research_program/revised_optimal_publication_architecture_A001_A025.md` and `research_program/external_reviews/joint_audit_publication_strategy_ER039_ER043.md`.

### 8.5 Integration gate

No A018–A025 claim enters the manuscript until the critical algebra/status corrections are implemented. A024's general first-passage formulas and A019's direct mass/no-rest theorems are the most feasible early integrations after corrected source versions exist.

### 8.6 Rest-packet update

The full A025 validation note, certification protocol, threshold/model registries, and notation/derivative audits reinforce the status discipline. A025 is now a complete technical note rather than status-only metadata, but remains a supplement component. Its Hopf interval certificates and high-accuracy branch continuation are accepted as externally verified at exact source-stated scope by explicit user attestation, while it explicitly withholds both a discrete Moore–Spence/Krawczyk fold certificate and a continuous-DDE bordered validation.

The model registry is useful but requires two textual corrections before adoption: stage parameter `g` is a timescale because the equations use rate `1/g`, and the stage modal theorem remains pending correction of the missing factor. Its I-3S Hopf certificate status is accepted by user attestation; publication artifacts remain to be archived. The notation audit adds a stage numerical-version conflict, while the derivative audit prohibits stale `C_E` coefficients from crossing variants.

These records make the one-article-plus-supplement architecture still stronger: they are shared type and validation infrastructure, not independent publication identities.

### 8.7 Feasible bridge implementation

Corrected working sources now exist for A018–A025. Corrected A018 directly incorporates the A019 finite-donor theorem, A020 protective channel, A024 first-passage interpretation, and A025 validation hierarchy. Corrected A021 retains only the finite-time perturbation theorem and demotes the unproved invariant graph/Hopf persistence. Corrected A022 and A023 repair the stage balance, stage modal factor, source corruption, and searched-set/modal status; they are assigned to the shared technical supplement.

The most feasible bridges are therefore implemented. Remaining work is not a missing conceptual bridge: it consists of citation/bibliography harmonization, cross-version stage and coefficient mapping, publication artifact archiving, and the explicitly open stronger A021/A025 proofs.

## 9. Conclusion

Later sources materially change the assessment of several early gaps. Groundwater and phosphorus are no longer wholly ungrounded, though their full modules remain incomplete. Nonlinear fold/SNPO evidence now exists for registered models through A012, while general persistence remains open. Accounting is analytically mature. Epistemic viability is mature for restricted classes. Institutional and distributive scalar operationalizations remain the weakest modules and should be rebuilt from the now stronger viability, accounting, and empirical-design foundations.
