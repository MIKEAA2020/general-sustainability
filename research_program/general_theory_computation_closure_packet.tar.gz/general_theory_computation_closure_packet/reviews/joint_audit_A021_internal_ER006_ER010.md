# Final Expanded Joint Audit of the A021 Internal Proof and Parallel Responses ER006–ER019

## Status and scope

This document reopens and expands the earlier ER006–ER010 adjudication. It jointly adjudicates:

- the internal provisional proof at `research_program/internal_provisional_A021_RFDE_invariant_graph_proof.md`;
- all fourteen specialist responses ER006–ER019;
- the corrected A021 working source and the version-2 specialist prompt.

The reviews are evaluated proposition by proposition, by mathematical content rather than arrival order, confidence, verbosity, or theorem numbering. Criticism aimed at another candidate response is not misattributed to the internal proof. Later responses receive no presumption of correctness merely because they are more recent or more detailed.

This expanded document supersedes only the scope and decisions of its earlier ER006–ER010 version while preserving the valid reasoning from that adjudication. It is the controlling decision for A021. Following the user's subsequent implementation authorization, its final theorem hierarchy was implemented in `revised_articles/A021_liebig_graph_corrected.tex`; no individual reviewer text was adopted verbatim.

---

# 1. Executive adjudication

## 1.1 High-confidence consensus

Across the internal proof and fourteen audits, the following conclusions survive proposition-level comparison (with the compactness and mapping-space wording qualified below). Claimed proof upgrades and concrete-model proposals were tested against, rather than presumed to supersede, the earlier consensus:

1. The original set
   \[
   C([ -\tau,0],K_x)\times\{\widehat y_*\}
   \]
   is not established as a compact smooth normally hyperbolic invariant manifold.
2. Compactness of \(K_x\subset\mathbb R^m\) does not imply compactness of its full continuous-history family.
3. A bounded/absorbing invariant set need not be a manifold.
4. The normal bundle includes binding-history directions transverse to the proposed base, not only the slack space.
5. Slack exponential stability alone does not establish normal hyperbolicity.
6. RFDE dynamics form a semiflow; graph constructions requiring invertible base dynamics need additional hypotheses or an appropriate one-sided theorem.
7. Persistence generically gives a nearby embedding, not automatically a vertical graph over the unchanged base.
8. Finite-time \(O(\varepsilon)\) tracking is the only unconditional theorem currently justified from the A021 coupling assumptions.
9. Concrete NHIM persistence remains conditional on a genuine compact finite-dimensional invariant manifold, complete splitting, domination, smoothness, and projection hypotheses.
10. Local characteristic/Hopf persistence can be treated directly without an invariant graph.
11. Yield parity removes the exponential-smallness guarantee but does not prove that every alternative reduction fails.
12. No local result proves persistence of a global periodic fold.

## 1.2 Controlling overall decision

A021 should not claim a proved invariant graph for its concrete blocks. The publication should contain:

- a proved finite-time perturbation theorem;
- optionally, a proved local slack-neighborhood estimate under stronger \(C^{1,1}\) or \(C^2\) assumptions;
- a conditional direct characteristic-crossing theorem with delay/another physical quantity as bifurcation parameter and coupling as perturbation;
- a compact-NHIM theorem only as a clearly conditional template tied to an exact Banach-semiflow theorem;
- the concrete A021 graph as a conjecture/application obligation;
- a narrow yield-parity limitation.

The controlling architecture combines the internal proof’s explicit arguments, ER011’s minimal publication hierarchy, and ER012’s stronger Route-F slack/compact-object package, corrected by ER006/ER007’s compactness and bunching qualifications and by the cross-audit regularity, projection, citation, and Hopf objections. No response is adopted verbatim.

---

# 2. Point-by-point adjudication

## 2.1 History-space compactness

### Decision

Adopt the qualified formulation:

> Compactness of \(K_x\) does not imply compactness of \(C([ -\tau,0],K_x)\). For the intended nontrivial path-containing state domains, unrestricted continuous histories generally fail equicontinuity and are noncompact. Degenerate target spaces can be exceptions.

The internal example \(\phi_n(\theta)=\sin(n\theta)\) proves noncompactness for \(K_x=[-1,1]\). ER006/ER007 are correct that a blanket statement for every compact \(K_x\) is false: if \(K_x\) is finite, connected-domain maps into it are constant.

### Reviewer assessment

- Internal, ER008–ER010: correct mechanism, wording too universal.
- ER006/ER007: correct qualification.

## 2.2 Manifold structure

### Decision

Consensus accepted. A compact invariant set, attractor, equicontinuous history family, or absorbing set is not automatically a \(C^r\) embedded submanifold. A compact embedded Banach manifold is necessarily finite-dimensional because infinite-dimensional Banach spaces are not locally compact.

Any compact-NHIM theorem must therefore begin with an explicitly finite-dimensional compact \(C^r\) invariant history manifold \(\mathcal A_x\), not a history cube.

ER012’s stronger statement that continuous mapping spaces into every positive-codimension target manifold can never be \(C^1\) Banach manifolds is rejected as too broad. Under suitable target geometry and chart constructions, mapping spaces can possess Banach-manifold structures. That observation does not repair A021: manifold structure would still not imply compactness, finite dimensionality, invariance, or normal hyperbolicity.

## 2.3 Full normal bundle

### Decision

Consensus accepted. For

\[
\mathcal M_0=\mathcal A_x\times\{\widehat y_*\},
\]

the normal bundle contains every transverse binding-history direction plus the slack-history directions. Slack stability controls only one summand.

A correct splitting is of the form

\[
T\mathcal B|_{\mathcal M_0}
=E^s\oplus T\mathcal M_0\oplus E^u,
\]

with every transverse direction assigned and controlled.

## 2.4 Semiflow and backward uniqueness

### Decision

Use route-specific wording:

- a two-sided Lyapunov–Perron or invertible graph-transform proof needs complete/uniquely backward base trajectories;
- a persistence theorem explicitly formulated for semiflows or inflowing/overflowing manifolds may avoid global backward uniqueness;
- a time-\(T\) map proof cannot silently assume that the compact RFDE map is a diffeomorphism on an open history set.

ER006/ER007 correctly prevent the internal diagnosis from sounding universal. ER010’s history-collapse mechanism is useful evidence that a graph over all present histories is generally the wrong object.

## 2.5 Vertical graph

### Decision

Adopt the embedding-first formulation:

\[
\iota_\varepsilon(\phi)
=
(\phi+u_\varepsilon(\phi),
 \widehat y_*+v_\varepsilon(\phi)).
\]

A vertical graph exists only if

\[
q_\varepsilon
=
\pi_x\circ\iota_\varepsilon
\]

is a global embedding/diffeomorphism onto its image. Local derivative injectivity is insufficient by itself. For a compact finite-dimensional base, sufficiently small \(C^1\) perturbations of an embedding remain embeddings, but that theorem/argument must be stated.

The graph is over

\[
\mathcal A_{x,\varepsilon}
=q_\varepsilon(\mathcal A_x),
\]

not automatically over \(\mathcal A_x\).

---

# 3. Final finite-time theorem

## Theorem FT — finite-time perturbation with initial mismatch

Let

\[
\mathcal B
=C([ -\tau,0],\mathbb R^{m+n})
\]

with product supremum norm. Write the full uncoupled and coupled functionals as

\[
\mathcal H_0(z)
=(F(x),G(y)),
\qquad
\mathcal H_\varepsilon(z)
=\mathcal H_0(z)+\varepsilon R(z),
\]

where \(R=(f,g)\). Suppose two solutions \(z^\varepsilon,z^0\) exist on \([0,T]\) and remain in a common region on which

\[
\|\mathcal H_0(z_1)-\mathcal H_0(z_2)\|
\le L\|z_1-z_2\|,
\qquad
\|R(z)\|\le M.
\]

Then

\[
\sup_{0\le t\le T}
\|z_t^\varepsilon-z_t^0\|_{\mathcal B}
\le
\begin{cases}
 e^{LT}
 \|z_0^\varepsilon-z_0^0\|_{\mathcal B}
 +\dfrac{|\varepsilon|M}{L}(e^{LT}-1),&L>0,\\[1.4ex]
 \|z_0^\varepsilon-z_0^0\|_{\mathcal B}
 +|\varepsilon|MT,&L=0.
\end{cases}
\tag{FT}
\]

### Proof

Let

\[
E(t)=
\sup_{-\tau\le s\le t}
|z^\varepsilon(s)-z^0(s)|.
\]

The integral equations give

\[
E(t)
\le E(0)+L\int_0^tE(s)\,ds+|\varepsilon|Mt.
\]

Gronwall yields (FT). \(\square\)

### Adjudication

This theorem incorporates ER006/ER007’s initial-history correction and avoids unnecessary compactness. Uniform local boundedness/Lipschitz assumptions are declared directly; they are not inferred from continuity on a bounded infinite-dimensional set.

---

# 4. Optional slack-neighborhood theorem

ER010’s slack estimate is useful, and ER012 supplies the strongest complete bootstrap version. A quadratic-remainder proof requires stronger regularity than mere \(C^1\). The result is conditional on the binding orbit remaining in the stated bounded working region; it is not an autonomous proof of global confinement.

## Conditional theorem SN

Assume:

1. the slack linearization generates
   \[
   \|T_y(t)\|\le M_y e^{-\beta t};
   \]
2. \(G\) is \(C^{1,1}\) or \(C^2\) near \(\widehat y_*\), so
   \[
   \|G(\widehat y_*+\eta)-G(\widehat y_*)-DG(\widehat y_*)\eta\|
   \le C_N\|\eta\|^2;
   \]
3. the coupling is bounded by \(M_g\) in a local invariant neighborhood.

Then for any \(\beta'\in(0,\beta)\), sufficiently small initial slack error and \(|\varepsilon|\),

\[
\|y_t^\varepsilon-\widehat y_*\|
\le
C e^{-\beta't}
\|y_0^\varepsilon-\widehat y_*\|
+C|\varepsilon|
\]

while the orbit remains in that neighborhood. An order-one initial error reaches an \(O(\varepsilon)\) neighborhood after \(O(|\log\varepsilon|)\); an initially \(O(\varepsilon)\) error needs no such wait.

If only \(C^1\) regularity is available, replace the quadratic bound by a modulus of continuity and restate the bootstrap accordingly.

---

# 5. Compact history subsets and special invariant objects

## 5.1 Equi-Lipschitz history sets

ER012 correctly identifies a useful replacement for the false history-cube compactness step. A uniformly bounded, equi-Lipschitz family of histories is relatively compact by Arzelà–Ascoli, and it is compact when closed. Positive invariance requires explicit vector-field bounds and boundary/barrier conditions; it does not follow from compactness alone.

This gives a legitimate compact phase-space subset after all stated bounds are verified. It does **not** by itself give a smooth manifold, a finite-dimensional object, a complete normal splitting, or a graph domain.

## 5.2 Equilibria and periodic orbits

ER012’s equilibrium-persistence argument is a valid finite-dimensional special case when the equilibrium equation has an invertible state Jacobian. Under its characteristic convention, the equilibrium derivative blocks are `-Delta_x(0)` and `-Delta_y(0)`, not the characteristic matrices themselves; the sign does not affect invertibility. Hyperbolicity should be continued using a precise RFDE root-localization result rather than the phrase “compact characteristic spectra.”

A hyperbolic periodic orbit of an RFDE is likewise a plausible compact finite-dimensional invariant object. ER012’s proposed proof is incomplete because a fixed time map need not preserve a transverse section: one must construct the return-time function and Poincaré return map with the required RFDE smoothing/transversality, or invoke an exact periodic-orbit persistence theorem. These are useful concrete targets for a minimal implementation, but neither establishes an invariant graph over a history region.

---

# 6. Conditional compact-NHIM template

## Decision

Do not present the concrete A021 graph as proved. A conditional theorem may be stated only by reproducing the exact hypotheses of a verified Banach-semiflow result, such as the appropriate theorem in:

- Bates, Lu, and Zeng, *Existence and Persistence of Invariant Manifolds for Semiflows in Banach Space*, Memoirs AMS 135 (1998), no. 645;
- or the appropriate overflowing/foliation result in their 1999/2000 papers.

## Minimum hypothesis content

A correct template must include:

1. a compact finite-dimensional \(C^r\) invariant manifold \(\mathcal A_x\);
2. the exact flow/semiflow/inflowing/overflowing property required by the theorem;
3. a complete invariant splitting;
4. stable and unstable estimates;
5. inverse-tangent/conorm bunching. For a time-\(T\) map with invertible tangent dynamics, require, for each derivative order claimed,
   \[
   \sup_{p\in\mathcal M_0}
   \|DP_0(p)|_{E_p^s}\|
   \left\|
   (DP_0(p)|_{T_p\mathcal M_0})^{-1}
   \right\|^j
   <1,
   \qquad 1\le j\le r;
   \]
6. the theorem’s exact smoothness and perturbation topology;
7. localized uniform tubular/bounded-geometry assumptions;
8. projection embedding to obtain a vertical graph.

## Quantitative regularity

A \(C^1\) perturbation can give persistence under the selected theorem, but an explicit

\[
\|\iota_\varepsilon-
\iota_0\|_{C^1}=O(\varepsilon)
\]

estimate requires parameter-differentiability or uniform \(C^{1,1}/C^2\) control sufficient to make the variational perturbation Lipschitz in \(\varepsilon\). A merely continuous derivative gives \(o(1)\), not automatically \(O(\varepsilon)\).

## Concrete A021 status

No compact manifold, full splitting, inverse-tangent bunching, or projection embedding has been verified. The invariant graph remains a conjecture/application obligation.

---

# 7. Direct characteristic/Hopf persistence

The direct spectral route is preferred because it does not depend on the graph.

## Theorem HC — characteristic crossing curve

Let \(\mu\) be the physical bifurcation parameter (for A021, typically delay after rescaling to a fixed history interval) and \(\varepsilon\) the coupling parameter. Suppose:

1. a constant equilibrium \(z_*(\mu,\varepsilon)\) exists and is \(C^1\), with zero excluded from the characteristic spectrum at \((\mu_*,0)\);
2. the characteristic determinant/function
   \[
   D(\lambda,\mu,\varepsilon)
   \]
   is holomorphic in \(\lambda\) and \(C^1\) in \((\mu,\varepsilon)\);
3. at \((\mu_*,0)\), \(D\) has a simple pair \(\pm i\omega_*\), no other imaginary root, and every slack/normal root is separated from the imaginary axis;
4. transversality holds in the bifurcation parameter:
   \[
   \partial_\mu
   \operatorname{Re}\lambda(\mu_*,0)
   \ne0.
   \]

Then there are \(C^1\) functions

\[
\mu_*(\varepsilon)
=\mu_*+O(\varepsilon),
\qquad
\omega(\varepsilon)
=\omega_*+O(\varepsilon)
\]

such that

\[
D(i\omega(\varepsilon),
  \mu_*(\varepsilon),
  \varepsilon)=0.
\]

### Proof

Apply the real implicit function theorem to

\[
(\omega,\mu,\varepsilon)
\mapsto
\begin{pmatrix}
\operatorname{Re}D(i\omega,\mu,\varepsilon)\\
\operatorname{Im}D(i\omega,\mu,\varepsilon)
\end{pmatrix}.
\]

Simplicity and transversality make the Jacobian in \((\omega,\mu)\) invertible. \(\square\)

## Nonlinear Hopf

To claim a nondegenerate periodic branch of the full RFDE, additionally require:

- the smoothness demanded by the exact RFDE Hopf theorem, normally at least \(C^3\) for normal-form/criticality claims;
- a nonzero first Lyapunov coefficient or the theorem’s equivalent nonlinear nondegeneracy condition.

Without those assumptions, HC proves persistence of the spectral crossing, not branch criticality or uniqueness. No global-fold result follows.

---

# 8. Yield parity

At \(\Delta_y=0\),

\[
\varepsilon
=C_{gap}+\varepsilon_{phys}.
\]

The yield-gap estimate no longer makes the coupling exponentially small. This invalidates the **yield-gap smallness certificate**. It does not prove that \(\varepsilon\) is numerically large, because \(C_{gap}\) and \(\varepsilon_{phys}\) might be small for independent reasons. It does not exclude symmetry, averaging, another timescale separation, or another invariant manifold.

---

# 9. Reviewer-specific adjudication

## ER006

High-value corrections:

- compactness qualification;
- route-specific backward uniqueness;
- initial-history mismatch;
- inverse-tangent bunching;
- stronger regularity;
- separate Hopf parameter.

Its criticism of an elementary graph theorem applies to ER007’s candidate response, not to the internal proof.

## ER007

Its specialist critique is strong, but its proposed replacement repeats the invalid elementary graph transform and several assumptions it had just criticized. Do not adopt its Theorem 2 or publication LaTeX wholesale.

## ER008

Useful hierarchy and parameter separation. Its finite-time/slack proof and NHIM template need regularity and bunching corrections. Its final conservative status is useful.

## ER009

Strongest compact-NHIM hypothesis package, especially inverse tangent control. It nevertheless overstates global compactness, time-map uniqueness, projection injectivity, and nonlinear Hopf conclusions. Use its hypotheses, not its full proof.

## ER010

Best route selection and best slack-neighborhood idea. Correct its \(C^1\)-versus-quadratic remainder, citation, compactness localization, nonlinear Hopf smoothness, and parity wording.

## ER011

Best minimal publication architecture and a correct mismatch-aware finite-time theorem. Retain its conservative hierarchy and parameter separation. Reject its illustrative domination counterexample (`dot x=2x`, `dot y=-y`), which does not show the claimed failure; strong tangent contraction is the relevant inverse-tangent obstruction. Correct its universal compactness wording, localized time-map compactness, simplified `beta>r alpha`, and delay-parameter formulation before use.

## ER012

Most developed Route-F package. Retain its finite-time theorem, conditional slack tube, equi-Lipschitz compact-set lemma, equilibrium/periodic-orbit special cases, refusal of an invalid graph transform, direct spectral route, and detailed verification checklist. Do not adopt verbatim its universal history noncompactness, blanket mapping-space obstruction, broad complete-continuity wording, inconsistent stable/unstable assignment, simplified bunching, wrong Bates–Lu–Zeng citation, notation collision, or nonlinear Hopf conclusion under only `r>=1`. Its `C^1` time-map and quadratic slack estimates are supportable only because its completed assumptions include Lipschitz first derivatives.

## ER013

ER013 attempts to promote both remaining conditional results to proved theorems. Its high-level targets are legitimate, but the proofs fail as written. The graph construction treats the RFDE phase space as a smooth ODE phase space, uses an unavailable smooth radial cutoff on the supremum-norm history space, asserts a false `O(epsilon)` cutoff bound, evaluates the unperturbed stable cocycle along section-dependent perturbed base paths, derives an incorrect backward-separation estimate, omits preservation of the Lipschitz section class and essential derivative terms, infers global projection injectivity from immersion, and assumes asymptotic phase. Consequently it does not replace the exact Banach-semiflow theorem obligation.

Its Hopf section correctly adds cubic smoothness and a nonzero uncoupled Lyapunov coefficient, but it does not justify the RFDE adjoint/center formalism, coefficient formula, or stated high-order remainders. More decisively, “no other imaginary spectrum” allows unstable complementary roots, while the claimed full-space orbital stability silently assumes all complementary spectrum is stable. Delay variation is not placed on a fixed phase space. The spectral crossing remains valid; the nonlinear branch and stability remain conditional on an exact RFDE theorem and complete hypotheses. See `ER013_A021_claimed_full_proofs/point_inventory.md`.

## ER014

ER014 is materially stronger than ER013: a time-`T` graph transform is the correct route and does not invert the ambient RFDE map; it also separates spectral crossing from nonlinear Hopf and preserves the concrete A021 caveat. It is not yet a proof. Most importantly, uniqueness of a sampled-map invariant graph does not imply full-semiflow invariance unless every intermediate image is proved to remain a graph in the uniqueness class. Strong/Hausdorff continuity does not provide the required Lipschitz graph property. The tubular/global base-map arguments suppress global injectivity and moving-bundle issues; the derivative transform confuses its inhomogeneous and contraction terms; attraction/confinement and higher jets are underproved. Its Hopf branch is plausible through an exact theorem, but full orbital stability still requires every complementary root to be stable, and varying delay still needs fixed-phase-space treatment. See `ER014_A021_time_T_graph_Hopf/point_inventory.md`.

## ER015

ER015 returns to an external-theorem time-map route and provides a useful hypothesis table, but the claimed proof is not theorem-matched. It overstates global well-posedness and complete continuity, uses unstated finite-time confinement, proves only `C1` perturbation control while claiming quantitative `Cr` persistence, and does not establish the precise BLZ theorem’s hypotheses or uniqueness class. Its commutation argument still omits proof that intermediate images remain in that class; projection and attraction estimates have global-geometry and quantifier errors. Its Hopf proof varies delay without a fixed phase space, applies Rouché language to an unbounded half-plane, and claims nonlinear Hopf under insufficient standing smoothness. Parity again removes only the yield-gap certificate. See `ER015_A021_BLZ_time_map_report/point_inventory.md`.

## ER016

ER016 successfully repairs the uniform tubular-neighborhood argument, global stability of compact embeddings, and the derivative-transform term, and it supplies the correct strategy for proving intermediate images remain in the sampled graph’s uniqueness class. It is therefore the strongest time-map outline received. Publication is still premature: the intermediate-time bundle estimates and all higher jets are asserted rather than completed; the claimed BLZ 1999 TAMS citation is wrong; parameter-dependent dilation is not automatically smooth on a `C0` history space; the slack formula uses an injection outside `C`; full Hopf stability omits slack/full complementary spectrum in its displayed condition; and parity is overstated. See `ER016_A021_comprehensive_resolution/point_inventory.md`.

## ER017

ER017 is the strongest conservative synthesis and closes the announced audit sequence. It accepts the time-`T` route as promising while refusing to call it complete, preserves the external Banach-semiflow theorem as controlling, withdraws unsupported higher regularity and basin claims, and cleanly separates spectral crossing, nonlinear branch existence, center criticality, and full-space stability. Its repaired tube, embedding, bundle, derivative, and intermediate-time lemmas are valuable future proof material. Remaining corrections are the wrong BLZ bibliography, model-dependent delay normalization, exact restricted variational continuity at time zero, and full-operator spectral localization. Its final theorem hierarchy is adopted.

## ER018

ER018 correctly identifies that the standalone A021 source does not instantiate a binding vector field, parameter point, invariant object, slack decomposition, or complete characteristic/Floquet package. Its wording is too broad at the workspace level: corrected A018 contains explicit candidate three-, four-, and five-state cores, parameters, delay structure, characteristic data, and selected Floquet evidence. What is missing is the formal A021 crosswalk selecting one candidate and completing its NAIM data. ER018's equilibrium and periodic-orbit cases remain useful templates, and its prefactor-aware inverse-tangent inequalities correctly describe the required verification. Its history-cube, mapping-space, and BLZ statements require the recorded qualifications.

## ER019

ER019 is rejected as a concrete A021 verification. It invents an unrelated two-state radial oscillator and supplies no derivation from the recorded A021 companion blocks. Moreover, its claimed circle of radius `r_0` is not a solution when `d>0`: the radial equation is `dot r=r(r_0^2-d-r^2)`, so the nonzero cycle, if `r_0^2>d`, has radius `sqrt(r_0^2-d)` and radial exponent `-2(r_0^2-d)`. The proposed history-space normal complement, slack spectrum, perturbation norms, BLZ citation, and higher-regularity conclusions are also unverified. ER019 therefore closes none of the open concrete obligations and causes no manuscript change.

## Internal proof

Strengths:

- no invalid elementary graph transform;
- complete finite-time binding theorem;
- embedding-first graph formulation;
- direct characteristic-crossing proof already separates delay and coupling;
- narrow parity conclusion.

Corrections required before implementation:

- qualify noncompactness;
- generalize finite-time theorem to initial mismatch;
- replace forward-only NHIM rate template by inverse-tangent bunching;
- add stronger regularity for quantitative \(C^1\) closeness;
- distinguish spectral crossing from nonlinear Hopf branch;
- optionally add the corrected slack-neighborhood theorem.

---

# 10. Final claim hierarchy for implementation

## Proved

1. Soft-minimum yield-gap derivative estimate.
2. Finite-time perturbation theorem FT.

## Proved under explicit stronger local assumptions

3. Slack-neighborhood theorem SN with \(C^{1,1}/C^2\) remainder control and binding confinement.
4. Compactness of closed bounded equi-Lipschitz history families, plus positive invariance under explicit vector-field/barrier bounds.
5. Equilibrium persistence under an invertible equilibrium Jacobian.
6. Characteristic-crossing theorem HC.

## Conditional external-theorem template

7. Hyperbolic periodic-orbit persistence under an exact RFDE/semiflow theorem match.
8. Compact finite-dimensional Banach-semiflow NHIM persistence with exact bunching and geometry assumptions.
9. Vertical graph after a global projection-embedding proof.

## Conjectural for concrete A021

10. The concrete binding/slack blocks possess the compact NHIM and satisfy domination.
11. A concrete \(C^1\) vertical graph exists.
12. A concrete nonlinear Hopf branch persists after theorem-matched RFDE smoothness and nonlinear nondegeneracy checks.

## Not claimed

13. A graph over all histories in \(C([ -\tau,0],K_x)\).
14. Global all-time binding tracking.
15. Global periodic-fold persistence.

---

# 11. Implementation recommendation

Revise corrected A021 by:

1. retaining its finite-time theorem, upgraded to mismatch-aware FT;
2. adding SN under explicit \(C^{1,1}/C^2\) and binding-confinement hypotheses;
3. adding the equi-Lipschitz compact-history lemma while stating that it supplies neither a manifold nor a graph;
4. adding equilibrium persistence and, only conditionally, the hyperbolic-periodic-orbit special case;
5. replacing the broad invariant-graph conjecture with the precise compact-NHIM template and concrete verification checklist;
6. adding HC as a separate direct spectral theorem, with nonlinear Hopf branch language conditional on the exact RFDE theorem’s higher smoothness and nonlinear nondegeneracy assumptions;
7. retaining the parity limitation in the narrow form of §8;
8. removing every suggestion that slack stability alone proves an invariant graph;
9. correcting the Bates–Lu–Zeng citation to the 1998 Memoirs AMS source and matching any invoked result exactly.

No reviewer’s replacement text is adopted verbatim. ER013 fails as a proof package; ER014–ER016 progressively repair the time-`T` route; ER017 correctly leaves it as future proof material rather than a controlling theorem. ER018 confirms that concrete verification is blocked by the absence of an A021 instantiation and crosswalk, although candidate equations and spectral data exist in A018. ER019’s invented oscillator is not an A021 model and is mathematically incorrect as stated. The exact Banach-semiflow theorem template remains controlling. The accepted hierarchy is finite-time tracking, the confined slack tube, equilibrium continuation, and characteristic crossing as proved; compact-NAIM persistence and nonlinear Hopf as exactly matched conditional results; and the concrete A021 graph, coefficient, and stability as unverified. The corrected A021 source already implements this hierarchy; ER018–ER019 require no manuscript change.