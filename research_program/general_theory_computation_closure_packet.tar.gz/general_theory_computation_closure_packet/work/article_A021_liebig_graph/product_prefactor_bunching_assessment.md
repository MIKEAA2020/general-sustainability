# Product Prefactor and Bunching Assessment

## Objective

Advance the two-block periodic-NAIM scaffold from spectral-rate estimates to direct finite-discretization estimates of the stable evolution norms in the history supremum norm.

## Binding stable-complement norms

For the selected gated C4 binding cycle at `tau_x=4.5`, the phase direction was removed from each full-history monodromy matrix. Induced infinity norms of the stable-complement powers converge across three history resolutions:

| periods | `dt=0.25` | `dt=0.10` | `dt=0.05` |
|---:|---:|---:|---:|
| 10 | 16.9203 | 17.3623 | 17.4644 |
| 20 | 0.4007 | 0.4109 | 0.4132 |
| 25 | 0.06166 | 0.06320 | 0.06355 |
| 30 | 0.00949 | 0.00972 | 0.00977 |
| 35 | 0.00146 | 0.00150 | 0.00150 |
| 40 | 0.000225 | 0.000230 | 0.000231 |

The phase-projection infinity norm converges from about `141.99` to `163.15` to `170.16`, confirming substantial nonnormality. The phase-tangent history ratio is approximately

\[
M_c=4.55356.
\]

## Slack semigroup norms

For the identical C4 slack equilibrium at `tau_y=10`, induced infinity norms of the upwind method-of-lines semigroup were evaluated at integer multiples of the binding period `P_x=370.95 yr`:

| periods | 25 intervals | 50 intervals | 100 intervals |
|---:|---:|---:|---:|
| 10 | 9.0006 | 9.3646 | 9.5512 |
| 20 | 1.3581 | 1.4571 | 1.5092 |
| 25 | 0.4967 | 0.5415 | 0.5654 |
| 30 | 0.1687 | 0.1878 | 0.1982 |
| 35 | 0.05751 | 0.06534 | 0.06963 |
| 40 | 0.01896 | 0.02204 | 0.02375 |

The slack block dominates the product stable norm after the transients considered here.

## Numerical product bunching

For the product time map over `n` binding periods, use the direct finite-discrete estimate

\[
q_n^{\rm disc}
=M_c\max\{\|S_x^n\|_\infty,\|T_y(nP_x)\|_\infty\}.
\]

At the finest retained levels:

| periods `n` | product stable norm | `q_n^{disc}` |
|---:|---:|---:|
| 25 | 0.5654 | 2.574 |
| 30 | 0.1982 | 0.902 |
| 35 | 0.06963 | 0.317 |
| 40 | 0.02375 | 0.108 |

Thus one-period and 25-period bunching fail after transient prefactors are included. Refining the slack method-of-lines generator further to 200 and 400 history intervals gives the following empirical linear-in-`1/m` limits:

| periods | extrapolated slack norm | extrapolated `M_c` product |
|---:|---:|---:|
| 30 | 0.20898 | 0.95160 |
| 35 | 0.07414 | 0.33761 |
| 40 | 0.02557 | 0.11643 |

The numerical `C1` product bunching inequality closes only marginally at 30 periods but robustly by 35 periods:

\[
T=35P_x\approx12983~\mathrm{yr},
\qquad
q_{35}^{\rm disc,ext}\approx0.338<1.
\]

This directly confirms the audits' warning that the stable multiplier alone cannot establish bunching.

## Status

This is the strongest prefactor-aware numerical domination evidence currently available. It replaces illustrative assumed-`M_s` thresholds with direct finite-discretization operator norms. It is not a continuum operator bound:

- binding phase/stable projections are discretized;
- slack semigroup norms come from upwind method-of-lines generators;
- discretization-to-continuum operator errors are not enclosed.

The correct status is

`NUMERICALLY_VERIFIED_DISCRETE_PRODUCT_BUNCHING_AT_35_PERIODS`

and not `DOMINATION_VERIFIED` for the RFDE.

## Reproducibility

- `computations/c4_discrete_prefactor.py`
- `computations/c4_discrete_prefactor_convergence.json`
- `computations/c4_slack_semigroup_prefactor.py`
- `computations/c4_slack_semigroup_inf_convergence.json`
