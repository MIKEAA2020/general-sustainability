# Self-Audit of the A021 RFDE Proof Prompt

## Judgment on version 1

Version 1 was strong as an adversarial checklist but was not fully self-contained or maximally rigorous.

Main deficiencies:

1. It did not emphasize that a generic perturbed manifold need not be a vertical graph over the unchanged binding base.
2. It treated the slack coordinate as the normal bundle without requiring other directions transverse to the binding manifold.
3. It did not adequately address noninvertibility of RFDE semiflows and possible dependence on complete backward base trajectories.
4. It did not distinguish persistence of a time-T RFDE map from persistence for the full semiflow.
5. It did not force a choice among compact NHIM, Lipschitz graph, bounded-geometry, and finite-time-only routes.
6. It did not sufficiently separate direct full-RFDE Hopf perturbation from Hopf persistence through a proved graph.
7. The abstract model was self-contained for a conditional theorem, but not enough to claim that concrete A021 blocks satisfy the hypotheses.

## Version 2 improvements

The current prompt now:

- defines the Banach history spaces and RFDE functionals;
- diagnoses compactness, manifold, normal-bundle, backward-uniqueness, and vertical-graph problems;
- allows an embedding with both binding and slack displacement;
- requires proof that projection produces a vertical graph;
- requires full normal/tangent spectral domination;
- offers six distinct rigorous routes and forbids mixing their conclusions;
- introduces the time-T-map route for differentiable RFDE semiflows;
- requires exact theorem citation and hypothesis mapping and now supplies the Bates–Lu–Zeng 1998/1999/2000 Banach-semiflow references as candidates rather than automatic matches;
- requires complete graph-transform/Lyapunov–Perron construction when no theorem matches;
- separates direct Hopf perturbation from graph-based Hopf persistence;
- requires publication-ready replacement LaTeX and a concrete application checklist;
- explicitly accepts a finite-time theorem plus conjectural graph as the scientifically preferred fallback.

## Remaining inherent limitation

No prompt alone can verify the concrete A021 blocks because the complete binding/slack equations, invariant base object, tangent cocycle, normal spectra, and perturbation norms must be supplied or computed. Version 2 therefore correctly requests an abstract conditional theorem and requires a separate application-verification checklist rather than pretending those facts are already known.