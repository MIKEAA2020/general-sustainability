Paper 2 v47 source package: main tex+pdf, supplementary (v46, unchanged),
all figures, the coverage-audit script (regenerates Table 2 and its figure
verbatim), and two exact-arithmetic verification scripts: the v46 LP-
instantiation/decomposition record (12 checks) and the v47 two-patch audit
and belief-state safety-value record (12 checks, regenerates Tables 3 and 4
verbatim). Run: python3 paper2_coverage_audit.py (numpy, matplotlib);
python3 paper2_v46_a5a6_verification.py; python3 paper2_v47_verification.py
(standard library only).
Mirror: https://github.com/MIKEAA2020/general-sustainability
