# Supplementary package

Materials accompanying "Typed Flux Ledgers and Depletion Arithmetic: Conservation, Componentwise Diagnostics,
and the Semantics of Depletion Horizons" (Amin Abaee, independent researcher; ORCID 0000-0002-0019-1842).

## What the supplementary is

The supplementary material is one document and two records beside it.

* **The supplementary document** is `manuscript/paper3_supplementary_v18.pdf` (19 pp., sections S1 to S17). It
  carries the proofs, derivations, parameter tables, the version-sensitivity record and the reproduction protocol
  that the main text cites by section number: the lemmas and propositions stated without proof in the article, the
  exhibit values behind each figure it quotes, the record of which public release each number comes from, and the
  section that reports the overshoot-date recomputation (S17). It is typeset from `paper3_supplementary_v18.md`,
  whose ASCII transliteration `paper3_supplementary_v18.ascii.md` is included because that is the source the
  typesetter reads. Its role is checking, not argument: it reports what was verified and by which operation, which
  deviations from the standard are documented and on what grounds, which statements the record supports and at what
  predicate, and what remains unresolved. Proofs are given to the depth at which a reader can re-do a step with a
  calculator and the tables in this archive, and where a step is stated rather than demonstrated the text says so.
* **The exhibit bundle** is `code/`: three scripts that regenerate every computed figure in the article and the
  supplementary, the manifest that records what each reads and what it does not, and the output record of one run.
* **The analysis record** is `analysis/nfa_tau/`: the recomputation of the aggregate overshoot date with and
  without carbon demand on two editions of the National Footprint and Biocapacity Accounts, with its own README
  and manifest.

The two records differ in what a reader needs in order to repeat them. The exhibit bundle runs on synthesised
inputs and nothing else, and it asserts that the article's computed figures reproduce; the analysis record runs on
the two edition tables of the accounts and asserts that the overshoot date recomputes under the weighting its README
states. Neither needs the other, and neither needs the network.

The main text and the two companion papers are included so that cross-references resolve inside the archive. The
companions are papers in their own right, not appendices: `companionA_certification_procedure_v9.pdf` specifies
the certification procedure the article's predicates define, and `companionB_standards_horizon_v9.pdf` places the
accounting objects against the standards horizon.

## Contents

     7,246 B  `analysis/nfa_tau/README.md`
       224 B  `analysis/nfa_tau/checksums.txt`
    11,237 B  `analysis/nfa_tau/edition_delta.csv`
    14,894 B  `analysis/nfa_tau/recompute_tau.py`
     4,584 B  `analysis/nfa_tau/results.txt`
     3,354 B  `analysis/nfa_tau/source/MANIFEST.md`
    15,324 B  `analysis/nfa_tau/tau_by_year_2017edition.csv`
    15,205 B  `analysis/nfa_tau/tau_by_year_2018edition.csv`
    19,132 B  `builders/build_v42_formal.py`
    16,382 B  `builders/build_v42_package.py`
    57,506 B  `builders/build_v47_gbase.py`
       624 B  `builders/geometry_v42.json`
    13,989 B  `builders/mdtex_v1.py`
   225,299 B  `builders/paper3_material_ledgers_v47_prebaseline.md`
    10,997 B  `builders/revisions_v42_formal_log.json`
   463,289 B  `builders/revisions_v47_base_log.json`
    12,359 B  `builders/structure_v42.md`
     4,448 B  `builders/structure_v47_base.md`
   118,945 B  `builders/stylekit_v1.py`
     9,488 B  `builders/tablekit_v2.py`
    12,573 B  `builders/texkit_v1.py`
    25,714 B  `builders/verify_v42_build.py`
    40,096 B  `builders/verify_v47_base.py`
     3,103 B  `code/MANIFEST.md`
     5,048 B  `code/certification_lp.py`
     3,281 B  `code/curvature_and_crossover.py`
     5,388 B  `code/outputs.txt`
     2,225 B  `code/persistence_index_simulation.py`
    31,254 B  `manuscript/companionA_certification_procedure_v9.md`
    94,163 B  `manuscript/companionA_certification_procedure_v9.pdf`
    38,645 B  `manuscript/companionA_certification_procedure_v9.tex`
    27,190 B  `manuscript/companionB_standards_horizon_v9.md`
    89,433 B  `manuscript/companionB_standards_horizon_v9.pdf`
    30,405 B  `manuscript/companionB_standards_horizon_v9.tex`
   251,523 B  `manuscript/paper3_material_ledgers_v47.md`
   424,118 B  `manuscript/paper3_material_ledgers_v47.pdf`
   272,077 B  `manuscript/paper3_material_ledgers_v47.tex`
    59,955 B  `manuscript/paper3_supplementary_v18.ascii.md`
    59,801 B  `manuscript/paper3_supplementary_v18.md`
   175,747 B  `manuscript/paper3_supplementary_v18.pdf`
    73,881 B  `manuscript/paper3_supplementary_v18.tex`

## Verifying it

`MANIFEST.sha256` holds a hash of every file in this archive:

```
sha256sum -c MANIFEST.sha256          # in the top directory of the unpacked archive
```

The exhibit bundle needs nothing further; run the three scripts and compare their stdout with `code/outputs.txt`.
The analysis record reads two edition tables of the accounts which, as its own manifest states, are held for
re-running and are not redistributed here. Fetch them by the two commands recorded in
`analysis/nfa_tau/source/MANIFEST.md`, place them in `analysis/nfa_tau/source/`, then

```
cd analysis/nfa_tau && python3 recompute_tau.py
```

The script verifies the bytes it reads against the hashes recorded there, and reproduces
`tau_by_year_2018edition.csv`, `tau_by_year_2017edition.csv`, `edition_delta.csv` and `results.txt` byte for byte.

The scripts in `builders/` regenerate the typesetting and the checks from the markdown sources: `tectonic`
compiles each `.tex`, and `python3 builders/verify_v47_base.py` re-runs every check the line is built on. These
four files are the v47 line of the same paper, and the line is the draft: the humanized rendering in `humanize/`
is used as the document, and this paper's verified content is grafted into it. Section by section, the draft's
paragraphs are taken in the draft's own order and in the draft's own words; where the draft's figures have been
overtaken, this paper's numbers are transplanted into the draft's sentence; the paper supplies the skeleton the
draft does not hold - the headings and their numbering, the 61 stated theorems, propositions, lemmas and
definitions, the tables, the displayed equations, the front and back matter - and the prose of the ten sections
the draft has no paragraphs at the same heading for. Where this paper has a paragraph and the draft has nothing
beside it, this paper's stands; the draft's own statement-labelled paragraphs (33 of them) were dropped in
favour of this paper's numbering, and 7 draft paragraphs were refused because a figure in them is not a figure
this paper states in that section.

What that produced, measured on the shipped text: 164 paragraphs of the draft's prose are in, 128 of them the
draft's framing paragraphs where this paper had no counterpart, and 40 carry the draft's shape with this
paper's numbers ported in; 466 of the article's 969 prose sentences are verbatim in the draft, against 119 in
the line this replaces, and 58% are verbatim or within a few characters; 136 of the 293 flowing paragraphs of the
body are the draft's as written, 105 are this paper's own, and no two adjacent
paragraphs restate one another, and the remaining few are this paper's paragraphs with the
register rules applied (11, values untouched). The three companion documents are the v43 register line carried
byte for byte, because the draft is a humanization of the main text alone.

The gate is what makes that safe to read. It refuses the build unless no value this paper states has gone
unstated and no value appears that the paper does not state; unless the tables, the statements, the displayed
equations and the section numbering are byte-identical to the verified line; unless every paragraph the graft
took in is traceable to the draft and every paragraph it gave up is traceable to this paper; unless the flowing
prose is nearer the draft's own register profile than it was in aggregate and on every feature the profile can
name (36.8 to 21.8 units); and unless each document's compiled text carries every flowing paragraph of the
markdown its own header names as its source - the article prints on 62 pages with no overfull box and no
overhang, and its 293 flowing paragraphs are all in the PDF. The
counts that a merge necessarily changes are reported rather than hidden: 82 figures are stated a different
number of times than before, because the draft repeats or folds together what the article states once. Three of
the audit instrument's targets are exceeded and are named with the draft's own rate beside them - em-dashes
(231 here, 202 in the draft, against a cap of 60), semicolons (225 and 170) and the ", not Y" frame (71 and 52)
- because this line matches the draft rather than the cap, and where it still sits above the draft it is the
punctuation of the paper's retained paragraphs, which no pass is entitled to re-cut.

Two boundaries are worth stating plainly, because they were both got wrong on the way here. The first is the
PDF: until this run the article's LaTeX was the previous deposit's file, polished paragraph by paragraph beside
the markdown, so the compiled article kept prose the style line had displaced and lost prose it had admitted -
v45 and v46 shipped that way, and the tell was a page count that did not move after 3,352 words were added. The
LaTeX is now transpiled from the markdown (1,647 formulas lifted out and put back unchanged), and the gate reads
the compiled text back and requires every flowing paragraph of the markdown to be on the page. Three displays were
too wide for the measure and were scaled to it; one table had its columns narrowed. Each is named in the build
log, and none of it touches a word.

The second is the bibliography. The baseline this line answers to is the draft's PROSE. Its reference list is not
prose - the draft says so itself - so the graft is refused there, as it is refused on headings, tables, statements
and the front matter, and the article ships the 40-entry list it arrived with, entry for entry, including the
annotations the self-reference map once reached into. Two wrong corrections were tried before that: importing the
superseded article's list wholesale, and recutting the draft's reflowed paragraph into entries. Neither is a style
line's business. What the baseline owes the reader is recorded instead of repaired: the draft's list was reflowed
out of a PDF text layer, which dropped the year letters separating this author's five 2026 papers and glued some
words together, and its paragraph carries 25 of the 40 works. That is the author's to settle, and it is listed in
the open items.

`builders/structure_v47_base.md` states what the pass may touch and what it may not, with the sentence-length and
device measurements before and after, and is emitted by the build itself from the run log. They are the
production machinery, not part of the text. Two things the draft was not allowed to change: a
companion analysis is described as "under review" here and as "in review" in the draft, and the five words
that status accounts for are mapped back before the text ships; and the build's own navigation lead sentences,
which an earlier line added at the head of some sections, are gone entirely, because under this method they
would have been the only prose in the document that is neither the corpus's nor the author's.

## Licences and terms

* Text, figures and scripts: CC BY 4.0, attributing the article above.
* The two edition tables are Global Footprint Network data under CC BY-SA 4.0 and are redistributed by their
  publisher, not here; the attribution the deposits request is recorded in the analysis manifest.
* `code/` consumes no external data. `analysis/nfa_tau/` reads the two tables and nothing else.
* No personal data, no third-party proprietary code.

## Notes on the text

Numbers in the article and the supplementary are recomputed, not transcribed, where a public release allowed it;
the three that were (the persistence-index exhibit, the two-cohort reserve-life medians and the overshoot
recomputation) are each tied to a named release and a re-runnable script in the sections above. Where a release
could not be reached without registration, that is stated at the number rather than at the end.
