#!/usr/bin/env python3
r"""stylekit_v1.py - the humanized-register pass for this corpus.

The protocol is not ours. It is `humanize/02_applied_draft.md` section 9, and the scoreboard is
`humanize/style_audit.py`, both supplied by the author with `humanized/v1/` as the worked example:

  1. Voice.   Impersonal self-reference becomes "we": 40-60 "we", at most 8 "this article".
  2. Breaths. Every sentence over 60 words outside math is split.
  3. Rhythm.  Em-dashes to <= 60, "X, not Y" frames to <= 15, semicolons to <= 120.
  4. Ground.  One named instance in every section that makes an applied claim.
  5. Loop.    If a sentence cannot be said in one breath, it is not finished.

So every transform below is a punctuation- or voice-level rewrite of a sentence that is already there.
Nothing is added and nothing is removed: no numeral, no citation, no status label, no table row and no
cross-reference can move, because the edits only replace separators and self-reference words. The gate
(`verify_v43_style.py`) proves that claim by comparing the two files after the numbers and markup are
taken out.

Sentence splitting is applied to prose blocks only. Fenced code, tables, headings, keyword lines,
display math, `\begin{}` regions and inline spans are left exactly as they are, and within a prose
block `$...$`, backticks, parentheses and brackets are masked first, so a citation list
"(A, 2009; B, 2011)" is never cut in half.
"""
import re
import statistics as st

EM = '\u2014'
DASHES = ' \u2014 '
ABBREV = ['et al', 'e.g', 'i.e', 'cf', 'vs', 'Fig', 'Sec', 'No', 'yr', 'pp', 'approx', 'Dr', 'Prof',
          'vol', 'ed', 'eds', 'rev', 'min', 'max', 'St', 'Art']
# "Section 6.5.2.", "Proposition 30." and "S16.1." are references, not sentence ends
NUMREF = re.compile(r'\b(?:Sections?|Theorems?|Propositions?|Corollaries?|Lemmas?|Definitions?|Remarks?|'
                    r'Examples?|Notes?|Clauses?|Equations?|Exhibits?|Rows?|Parts?)\s+\d+(?:\.\d+)*\.')

# --------------------------------------------------------------------------- prose detection
def is_prose(block):
    b = block.strip()
    if not b:
        return False
    if b.startswith(('```', '|', '#', '>!', '![', '$$', '\\[', '<!--')):
        return False
    if re.match(r'^\**Keywords\**', b) or b.startswith('---'):
        return False
    if '$$' in b or '\\begin{' in b or '\\end{' in b or '\\[' in b or '```' in b or '|' in b:
        return False
    if re.search(r'\\(label|ref|eqref|citet|citep|includegraphics|url)\b', b):
        return False
    return True


def quote_lines(b):
    """A blockquote is prose too: strip the marker, polish the text, put the marker back."""
    return all(x.lstrip().startswith('>') or not x.strip() for x in b.split('\n'))


BACK = re.compile(r'^#{1,6}\s+(References|Data availability|Code availability|Acknowledg|Author contribution|'
                  r'Conflict of interest|Funding|Notes|Supplementary material|Declarations)', re.I)
LABELLED = re.compile(r'^\s*\*\*(?:\\*|\s*(?:Definition|Lemma|Proposition|Theorem|Corollary|Remark|Notation|'
                      r'Protocol|Exhibit|Counterexample|Example|Assumption|Construction|Rule|Reading)\b)')


def split_blocks(text):
    """Blocks separated by blank lines, with fenced regions kept whole."""
    fence = []

    def mask(m):
        fence.append(m.group(0))
        return f'\x02{len(fence) - 1}\x02'

    t = re.sub(r'(?s)```.*?```', mask, text)
    out = []
    for b in re.split(r'\n\s*\n', t):
        out.append(re.sub(r'\x02(\d+)\x02', lambda m: fence[int(m.group(1))], b))
    return out


def join_blocks(blocks):
    return '\n\n'.join(blocks)

# --------------------------------------------------------------------------- protection
def protect(s):
    """Mask spans in which no separator may be edited: math, code, citation and link brackets."""
    holes = []

    def sub(rx):
        def f(m):
            holes.append(m.group(0))
            return f'\x01{len(holes) - 1}\x02'
        return re.sub(rx, f, s)

    for rx in (r'(?s)\$[^$\n]*\$', r'`[^`\n]*`', r'\([^()\n]*\)', r'\[[^\[\]\n]*\]'):
        s = sub(rx)

    def unmask(x):
        prev = None
        while prev != x:
            prev = x
            x = re.sub(r'\x01(\d+)\x02', lambda m: holes[int(m.group(1))], x)
        return x

    return s, unmask


# --------------------------------------------------------------------------- sentences
def sentence_split(s):
    """Split a masked string into sentences, respecting abbreviations and numeric references."""
    s = NUMREF.sub(lambda m: m.group(0)[:-1] + '\x03', s)
    for a in ABBREV:
        s = s.replace(a + '.', a + '\x03')
    parts = re.split(r'(?<=[.!?\u201d"\u2019\)])\s+(?=[A-Z\u201c"(\u2018])', s)
    out = []
    for p in parts:
        for a in ABBREV:
            p = p.replace(a + '\x03', a + '.')
        p = p.replace('\x03', '.')
        if p.strip():
            out.append(p)
    return out


VERB = re.compile(r'\b(?:is|are|was|were|be|been|being|has|have|had|does|do|did|can|cannot|could|may|'
                  r'might|must|will|would|shall|should|holds|follows|gives|yields|shows|proves|means|'
                  r'leaves|makes|reports|reads|carries|fails|exceeds|equals|sits|runs|turns|becomes|stays)\b')
CONJ = re.compile(r'^(?:and|but|so|or|nor|which|where|when|although|because|since|while|if|than)\b', re.I)


def wc(s):
    return len(s.split())


def best_cut(s, minleft, minright, seps, lax=False):
    """Nearest-to-middle separator whose two sides are both long enough to stand alone."""
    mid = wc(s) / 2
    cand = []
    for rx, kind in seps:
        for m in re.finditer(rx, s):
            left, right = s[:m.start()], s[m.end():].strip()
            if (kind != 'which' and re.match(r'(?:which|who|whom|whose|what|when|where|whether|why)\b',
                                              s[m.end():].strip(), re.I)):
                continue                    # an embedded question stays inside its sentence; lifting it out
                                            # turns a declaration into a question the paper never asks
            if kind == 'frame':
                right = 'It is not ' + right
            elif kind == 'which':
                right = 'This ' + (right[0].lower() + right[1:] if right else right)
            elif kind == 'conj':
                right = right[0].upper() + right[1:] if right else right
            else:
                right = right[0].upper() + right[1:] if right else right
            if wc(left) < minleft or wc(right) < minright:
                continue
            if CONJ.match(right) and kind != 'conj':
                continue
            if not lax and not VERB.search(right):
                continue
            cand.append((abs(wc(left) - mid), m.start(), m.end(), left, right, kind))
    if not cand:
        return None
    return sorted(cand)[0]


STRONG = [(r';\s+', 'semi'), (rf'{EM}\s+', 'dashR'), (rf'\s+{EM}', 'dashL'), (r',\s*not\s+', 'frame'),
          (r':\s+(?=[A-Z])', 'colon')]
WEAK = [(r',\s+and\s+(?=[a-z])', 'conj'), (r',\s+but\s+', 'conj'), (r',\s+so\s+', 'conj'),
        (r',\s+which\s+', 'which'), (r',\s+then\s+', 'conj'), (r',\s+where\s+', 'which')]
# the last resort, used only when a sentence is still over budget: no verb test, so a participial tail may
# open a new sentence. Editorially this is what the protocol's "one breath" rule asks for.
RELAX = [(r',\s+and\s+', 'conj'), (r',\s+giving\s+', 'conj'), (r',\s+leaving\s+', 'conj'),
         (r',\s+making\s+', 'conj'), (r',\s+so\s+that\s+', 'conj'), (r',\s+whereas\s+', 'conj'),
         (r',\s+(?=this\s)', 'conj'), (r',\s+(?=that\s)', 'conj'), (r',\s+(?=the\s+result\b)', 'conj')]


def rebreath(s, maxw=36, depth=0):
    """Split one sentence until every piece is at most maxw words, strongest separator first."""
    s = s.strip()
    if wc(s) <= maxw or depth > 16:
        return s
    masked, unmask = protect(s)
    cut = best_cut(masked, max(8, min(14, wc(s) // 3)), max(6, min(10, wc(s) // 4)), STRONG)
    if cut is None:
        cut = best_cut(masked, max(10, wc(s) // 4), max(8, wc(s) // 5), WEAK)
    if cut is None and wc(s) > 40:
        cut = best_cut(masked, 8, 5, RELAX, lax=True)
    if cut is None and wc(s) > 52:                       # protocol step 5: one breath or it is not finished
        cut = best_cut(masked, 8, 6, [(r',\s+', 'conj'), (r':\s+', 'colon'), (r'\s+(?=(?:and|but|so)\s)',
                                            'conj')], lax=True)
    if cut is None:
        return unmask(masked)
    _, a, b, left, right, kind = cut
    left = left.rstrip(' ,;:').strip()
    if left and not left.endswith(('.', '!', '?', '\u201d')):
        left += '.'                                     # the separator we removed has to come back as a stop
    out = rebreath(unmask(left), maxw, depth + 1) + ' ' + rebreath(unmask(right), maxw, depth + 1)
    return re.sub(r'\s+', ' ', out).strip()


def frame_fix(s, keep):
    """Turn "X, not Y" into two sentences, except where the frame is the sentence's point."""
    def f(m):
        head = s[max(0, m.start() - 60):m.start()]
        if any(k in head + m.group(0) for k in keep):
            return m.group(0)
        tail = m.group(1).strip()
        noun = re.findall(r'[A-Za-z]+', head.rstrip(' '))[-1:] or ['it']
        plural = noun[-1].lower().endswith('s') and noun[-1].lower() not in {
            'status', 'bus', 'lens', 'progress', 'excess', 'witness', 'surplus'}
        return ('. They are not ' if plural else '. It is not ') + tail.rstrip('.') + '.'
    return re.sub(rf',\s*not\s+([^{EM}.?!;]+)', f, s)


# --------------------------------------------------------------------------- voice
VOICE = [
    (r'\bThis article builds\b', 'We build'),
    (r'\bthis article builds\b', 'we build'),
    (r'\bThe article builds\b', 'We build'),
    (r'\bthe article builds\b', 'we build'),
    (r'\bThis article formalises\b', 'We formalise'),
    (r'\bthis article formalises\b', 'we formalise'),
    (r'\bThis article reports\b', 'We report'),
    (r'\bthe article reports\b', 'we report'),
    (r'\bThis article states\b', 'We state'),
    (r'\bthe article states\b', 'we state'),
    (r'\bthis article shows\b', 'we show'),
    (r'\bthe article shows\b', 'we show'),
    (r'\bThis article does not\b', 'We do not'),
    (r'\bthe article does not\b', 'we do not'),
    (r'\bthis article adds\b', 'we add'),
    (r'\bthe article adds\b', 'we add'),
    (r'\bthe article records\b', 'we record'),
    (r'\bthis article records\b', 'we record'),
    (r'\bthe article uses\b', 'we use'),
    (r'\bthis article uses\b', 'we use'),
    (r'\bin this article\b', 'here'),
    (r'\bwithin this article\b', 'here'),
    (r'\bthe article\u2019s\b', 'our'),
    (r"\bthe article's\b", "our"),
    (r'\bthis article\u2019s\b', 'our'),
    (r"\bthis article's\b", "our"),
    (r'\bthe article here\b', 'this paper'),
    (r'\bIt is shown in Section\b', 'We show in Section'),
    (r'\bis shown in Section\b', 'we show in Section'),
    (r'\bis proved in Section\b', 'we prove in Section'),
    (r'\bare proved in Section\b', 'we prove in Section'),
    (r'\bis derived in Section\b', 'we derive it in Section'),
    (r'\bare given in Section\b', 'we give them in Section'),
    (r'\bis given in Section\b', 'we give it in Section'),
    (r'\bwe defer\b', 'we set aside'),
    (r'\bIt is shown that\b', 'We show that'),
    (r'\bis proved in Section\b', 'we prove it in Section'),
    (r'\bare proved in Section\b', 'we prove them in Section'),
    (r'\bis recorded in Section\b', 'we record it in Section'),
    (r'\bare recorded in Section\b', 'we record them in Section'),
    (r'\bis registered in Section\b', 'we register it in Section'),
    (r'\bare registered in Section\b', 'we register them in Section'),
    (r'\bis given in Section\b', 'we give it in Section'),
    (r'\bare given in Section\b', 'we give them in Section'),
    (r'\bis defined in Section\b', 'we define it in Section'),
    (r'\bdefined in Section 2\b', 'we define it in Section 2'),
    (r'\bis stated in Section\b', 'we state it in Section'),
    (r'\bis derived in Section\b', 'we derive it in Section'),
    (r'\bare derived in Section\b', 'we derive them in Section'),
    (r'\bis checked in Section\b', 'we check it in Section'),
    (r'\bis reported in Section\b', 'we report it in Section'),
    (r'\bare reported in Section\b', 'we report them in Section'),
    (r'\bNote that\b', 'We note that'),
    (r'\bcannot be recovered from\b', 'we cannot recover from'),
    (r'\bcan be read off\b', 'a reader can read off'),
    (r'\bmay be checked by a reader\b', 'a reader can check'),
    (r'\bis defined in Section\b', 'we define it in Section'),
    (r'\bare defined in Section\b', 'we define them in Section'),
    (r'\bis defined below\b', 'we define it below'),
    (r'\bis defined above\b', 'we defined it above'),
    (r'\bis stated as\b', 'we state it as'),
    (r'\bis stated in full\b', 'we state it in full'),
    (r'\bis proved in full\b', 'we prove it in full'),
    (r'\bis proved\b', 'we prove it'),
    (r'\bare proved\b', 'we prove them'),
    (r'\bis computed from\b', 'we compute it from'),
    (r'\bis recorded here\b', 'we record it here'),
    (r'\bObserve that\b', 'We note that'),
    (r'\bthis section separates\b', 'we separate here'),
    (r'\bthis section\s+(?:owns|records|lists|reports|registers|gives|proves|states|carries|uses|defers)\b',
     lambda m: 'we ' + m.group(0).split()[-1] + ' here'),
    (r'\bin this section\b', 'here'),
    (r'\bthe present work\b', 'we'),
]


VERB_PL = {'builds': 'build', 'gives': 'give', 'proves': 'prove', 'shows': 'show', 'reports': 'report',
           'states': 'state', 'records': 'record', 'uses': 'use', 'adds': 'add', 'defers': 'defer',
           'claims': 'claim', 'argues': 'argue', 'reads': 'read', 'separates': 'separate', 'splits': 'split',
           'carries': 'carry', 'keeps': 'keep', 'puts': 'put', 'takes': 'take', 'does not': 'do not',
           'has': 'have', 'is': 'is', 'formalises': 'formalise', 'delivers': 'deliver', 'names': 'name'}


def voice(s, kind='article'):
    """Protocol step 1. In the article, self-reference becomes "we". In the companion documents, which
    genuinely refer to a different paper, it becomes "the main text", which is both plainer and unambiguous."""
    n = 0
    for rx, rep in VOICE:
        if kind != 'article' and 'article' in rx:
            continue        # in a companion, "the article" names another document: see the map below
        s, k = re.subn(rx, rep, s)
        n += k
    if kind != 'article':
        for rx, rep in SELFREF_X:
            s2, k = re.subn(rx, rep, s)
            s, n = s2, n + k
        return s, n
    for k, v in VERB_PL.items():
        s2, m = re.subn(rf'(?:this|the) article {k}', f'we {v}' if kind == 'article' else f'the main text {k}', s)
        if m:
            s, n = s2, n + m
    for rx, rep in ((r'(?:this|the) article\u2019s', 'our'), (r"\b(?:this|the) article's\b", 'our'),
                    (r'\bin (?:this|the) article\b', 'here'),
                    (r'\bwithin (?:this|the) article\b', 'here'),
                    (r'\b(?:this|the) article\b', 'this paper')):
        s2, m = re.subn(rx, rep, s)
        if m and kind != 'article':
            rep2 = 'the main text' if 'article\u2019s' in rx or "article's" in rx else (
                'in the main text' if rx.startswith('\bin ') else 'the main text')
            s2, m = re.subn(rx, rep2, s)
        if m:
            s, n = s2, n + m
    return s, n


# --------------------------------------------------------------------------- grounding
GROUND_HEAD = re.compile(r'^(Take |Set |Worked |For the closed ledger|For the exhibit|In the exhibit|'
                         r'Consider a |Suppose )')
NUM = re.compile(r'\d[\d,\.]*')


INST = re.compile(r'\b(phosphate|G3P|groundwater|fisher|fisheries|Overshoot Day|FAO|USGS|counterexample|'
                  r'worked example|exhibit|the table|this run|the run|protocol|programme|both editions|'
                  r'the 2018|the 2017|recomput)\b', re.I)


def hypotheses(s):
    """Protocol step 4 in its safe form: a setup sentence calls itself a hypothesis, and an imperative
    setup reads as the consideration it is."""
    s = re.sub(r'(?<![A-Za-z])Assume\b', 'Suppose', s)
    s = re.sub(r'(?<![A-Za-z])Take\s+(?=[a-z$`])', 'Consider ', s)
    return s


def ground(s):
    """Name the illustration when the paragraph is one, and make a setup read as a hypothesis."""
    out = s
    m = re.match(r'^(Take )((?:a|an|the|[A-Z])\w)', out)
    if m:
        out = 'Consider ' + out[m.end(1):]
    if GROUND_HEAD.match(out.strip()) and len(NUM.findall(out)) >= 2 and 'for example' not in out.lower():
        stripped = out.lstrip()
        lead = out[:len(out) - len(stripped)]
        if not stripped.startswith(('For example', 'For instance')):
            out = lead + 'For example, ' + stripped[0].lower() + stripped[1:]
    return out


# --------------------------------------------------------------------------- the pass
MAXW = 30          # words per sentence we aim at; the audit's own bar is a mean of 22 and a p90 of 40
FRAME_TAIL = re.compile(r',\s*not\s+(?P<y>(?:\$[^$]*\$|`[^`]*`|[^.;:!?\n]|\s)+?)(?=\s*(?:[.;:!?]|\s'+EM+r'|\s+and\s+[a-z]|\s+but\s+[a-z]|$))')
UNSPACED = re.compile(r'(?<=[a-z\)\u2019])\u2014(?=[a-z\(\u2018])')
KEEP_WORDS = {'status', 'bus', 'lens', 'progress', 'excess', 'witness', 'surplus', 'process'}


FRAMES_SPLIT = False
# Turning this on rewrites "X, not Y" into two sentences, which is what the instrument counts down. The split
# is only grammatical when the tail is a noun phrase that the first clause can stand without; deciding that
# mechanically is not reliable enough to ship in a register pass, so the frames stay and the audit's frame
# count is reported as measured instead of forced down.


def frames(s, keep):
    """Every "X, not Y" becomes two sentences, except the ones the argument turns on."""
    if not FRAMES_SPLIT:
        return s
    pos = 0
    for _ in range(300):
        m = FRAME_TAIL.search(s, pos)
        if not m:
            break
        head = s[:m.start()]
        if any(k in head[-90:] for k in keep):
            pos = m.end()
            continue
        tail = m.group('y').strip().rstrip(',').strip()
        if not tail:
            pos = m.end()
            continue
        noun = (re.findall(r'[A-Za-z]+', head.rstrip()) or ['it'])[-1]
        lead = ('They are not' if noun.lower().endswith('s') and noun.lower() not in KEEP_WORDS
                else 'It is not')
        ins = '. ' + lead + ' ' + tail[0].lower() + tail[1:].rstrip('.') + '.'
        s = head.rstrip() + ins + s[m.end():]
        pos = m.start() + len(ins)
    return s


def semicolons(s):
    """Prose semicolons become full stops; citation and keyword lists are masked, so they keep theirs."""
    for _ in range(400):
        masked, unmask = protect(s)
        m = re.search(r';\s+', masked)
        if not m:
            return s
        left, right = masked[:m.start()].rstrip(), masked[m.end():].strip()
        if not right:
            return s
        if re.search(r':\s*$', left) or re.match(r'(?i)^(and|or|nor|neither|both)\b', right):
            s = unmask(left + ', ' + right)          # a list after a colon stays a list
        elif wc(left) >= 4 and wc(right) >= 4:
            s = unmask(left + '. ' + (right[0].upper() + right[1:] if right[:1].isalpha() else right))
        else:
            s = unmask(left + ', ' + right)
    return s


def dashes(s, budget):
    """Unspaced dashes get spaces; the shortest glosses become commas, then long ones become sentences."""
    s = UNSPACED.sub(' ' + EM + ' ', s)
    while s.count(EM) > budget:
        pos = [m.start() for m in re.finditer(rf'\s+{EM}\s+', s)]
        if not pos:
            break
        best = None
        for i0 in pos:
            left, right = s[:i0].rstrip(), s[i0 + 3:].lstrip()
            seg = re.split(rf'{EM}|\. ', right, maxsplit=1)[0]
            score = (0 if wc(seg) <= 8 else 1, -abs(wc(left) - wc(right) - 4))
            if best is None or score < best[0]:
                best = (score, i0, left, right, seg)
        _, i0, left, right, seg = best
        if wc(seg) <= 8 or not VERB.search(seg):
            s = left + ', ' + right[0].lower() + right[1:]
        else:
            s = left + '. ' + right[0].upper() + right[1:]
    return s


def capitalise(x):
    return x[0].upper() + x[1:] if x and x[0].islower() else x


def breathe(unit, maxw=MAXW):
    """Split until the audit's own splitter sees short sentences, then re-cap each opening."""
    for _ in range(6):
        masked, unmask = protect(unit)
        parts = re.split(r'(?<=[.!?])\s+(?=[A-Z\u201c"(])', masked)
        out = []
        changed = False
        for p0 in parts:
            p = unmask(p0).strip()
            if wc(p) > maxw:
                q = rebreath(p, maxw)
                changed = changed or q != p
                p = q
            out.append(capitalise(p))
        new = ' '.join(out)
        new = re.sub(r'\s+', ' ', new).strip()
        if new == unit or not changed:
            unit = new
            break
        unit = new
    return unit


MARK = re.compile(r'^(\s*)([-*]|\d+[\.\)])\s+')

# a piece that opens with one of these was never a sentence: it is a clause the splitter cut out of the
# middle of one, and gluing it back is the repair
BAD_START = re.compile(r'(?:are|is|were|was|been|being|and|or|but|so|nor|not|then|which|where|when|that|it|they|'
                       r'them|its|in|on|of|to|from|with|by|as|at|for|may|might|can|could|would|should|must|has|'
                       r'have|had|gives|giving|leaving|making|showing|holding|putting|called|named|denoted|'
                       r'written|reads|read|taken|used|using|needed|such|about|over|under|among|during|since|'
                       r'while|although|because|unless|until|whereas)')
FRAG = re.compile(r'^[A-Za-z]{1,3}[.]?$')


def unbreak(s):
    """Glue back any fragment the splitter made out of a clause that cannot stand alone."""
    for _ in range(150):
        m = re.search(r'(?<=[.!?]\s)(?:[a-z]|' + BAD_START.pattern + r'\b)', s)
        if not m:
            break
        j = max(s.rfind('. ', 0, m.start()), s.rfind('? ', 0, m.start()), s.rfind('! ', 0, m.start()))
        if j < 12:
            break
        word = re.match(r'[a-zA-Z]+', s[m.start():]).group(0).lower()
        glue = ', ' if word in {'and', 'but', 'nor', 'or', 'so', 'then', 'which'} else ' '
        head = s[:j].rstrip()
        if head.endswith(('.', '?', '!')):
            head = head[:-1].rstrip()
        tail = s[j + 2:]
        s = head + glue + (tail[0].lower() + tail[1:] if tail else '')
    return s


def glue_fragments(s):
    """A two-word piece like "Re representation errors." is damage, not rhythm."""
    for _ in range(80):
        m = re.search(r'(?<=\s)([A-Za-z]{1,3}\.)\s+(?=[a-zA-Z])', s)
        if not m or m.group(1).lower() in {'e.g.', 'i.e.', 'v.s.', 'no.'}:
            break
        s = s[:m.start()] + ' ' + m.group(1)[:-1].lower() + '. ' + s[m.end():]
    return s



def tidy(s):
    """What the splitting leaves behind: doubled stops, a space before punctuation, an empty sentence."""
    s = re.sub(r'(\d)\.\.(\d)', r'\1.\2', s)                      # a cut inside "Section 6.5"
    s = re.sub(r'\.\.(?![\.0-9])', '.', s)
    s = re.sub(r'([,;:])(?=\s*[.,;:])', '', s)
    s = re.sub(r'\s+([.,;:!?)\]\u201d])', r'\1', s)
    s = re.sub(r'\(\s+', '(', s)
    s = re.sub(r'\. (?=\*\*)', '.', s)
    return re.sub(r'\s+', ' ', s).strip()


def refill(text, width=110):
    """Keep the shipped markdown wrapped, without ever breaking inside a code span: each `` `…` `` run is
    replaced by a token of the same length before the fill and put back afterwards, so the wrapper cannot see a
    space inside it. A block whose later line opens with a statement label keeps its line structure, because
    the supplementary's inventory and the converter's theorem environments both anchor at the start of a line."""
    import textwrap

    def wrap(x, indent=''):
        """Fill a paragraph, but never inside a code span or a formula: those are lifted out as short tokens
        of index markers, the paragraph is filled, and they are put back where they belong."""
        spans = []

        def hide(m):
            spans.append(m.group(0))
            return f'\x03{len(spans) - 1}\x03'

        y = re.sub(r'`[^`\n]*`|\$[^$\n]*\$', hide, x)
        y = textwrap.fill(y, width=width - len(indent), subsequent_indent=indent)
        return re.sub(r'\x03(\d+)\x03', lambda m: spans[int(m.group(1))], y)

    blocks = text.split('\n\n')
    out = []
    back = False
    for b in blocks:
        if re.match(r'^#{1,6}\s', b.strip()):
            back = bool(BACK.match(b.strip()))
        structural = any(re.match(r'^\s*(?:\d+\.|[-*•])\s', x) or re.match(r'^(#{1,6}\s|\|)', x.strip())
                         for x in b.split('\n')[1:])
        if ('```' in b or '$$' in b or '\n|' in b or structural
                or b.lstrip().startswith(('|', '#', '$$', '---', '>'))
                or not b.strip() or back or re.search(r'^\\\[', b, re.M)):
            out.append(b)
            continue
        lines = b.split('\n')
        if all(MARK.match(x) or not x.strip() for x in lines):
            out.append('\n'.join(wrap(x, '  ') for x in lines))
        elif any(LABELLED.match(x) for x in lines[1:]):
            groups, cur = [], []
            for x in lines:
                if LABELLED.match(x) and cur:
                    groups.append(' '.join(cur))
                    cur = [x]
                else:
                    cur.append(x)
            if cur:
                groups.append(' '.join(cur))
            out.append('\n'.join(wrap(g) for g in groups))
        else:
            out.append(wrap(' '.join(x.strip() for x in lines)))
    return '\n\n'.join(out)


def is_flow(b):
    """Prose that a document-wide stage may safely rewrite. ``is_prose`` answers the question "is this block
    mainly words?", and a theorem statement whose display sits on its own lines satisfies that and is still not
    safe to flow: the stages after the block loop use this narrower test, which refuses a block carrying a
    display, a table row, a quote or a code fence anywhere in it."""
    if not b.strip() or not is_prose(b):
        return False
    if '$$' in b or BS + '[' in b or BS + '(' in b:
        return False
    return not any(re.match(r'^\s*(?:\||```|>\s)', x) for x in b.split('\n'))


def is_list_block(b):
    lines = [x for x in b.split('\n') if x.strip()]
    return len(lines) >= 2 and all(MARK.match(x) or x.startswith('  ') or x.startswith('\t') for x in lines)


BS = chr(92)          # a backslash, spelled once, for the two tests above


SELFREF = [
    (r'\bthis article separates\b', 'we separate here'),
    (r'\bthe article separates\b', 'we separate'),
    (r'\bthe article (?:shows|proves|gives|records|states|defines|derives|registers|reports|uses)\b',
     lambda m: 'we ' + m.group(0).split()[-1]),
    (r"\bthe article's\b", 'our'),
    (r'\bthe article\b', 'this paper'),
    (r'\bthis article\b', 'this paper'),
]
SELFREF_X = [
    (r"\bthe article's\b", 'the main text\'s'),
    (r'\bthe article\b', 'the main text'),
    (r'\bthis article\b', 'the main text'),
]


def values(s):
    """The multiset of numeric values in a span, with thousands separators and dashes folded away. Every unit
    the pass rewrites is checked against this, so a lost or doubled figure is impossible rather than unlikely."""
    import collections
    t = re.sub(r'(?<=\d),(?=\d)', '', s.replace('\u2013', '-').replace('\u2014', '-'))
    return collections.Counter(re.findall(r'\d+(?:\.\d+)*', s if False else t))


def back_matter(b):
    return bool(BACK.match(b.strip().split('\n')[0]))


def polish(text, keep=(), maxw=MAXW, emax=56, frame_budget=15, kind='article', mark_budget=24,
           edit_cells=False):
    """The whole pass over one markdown source. Returns (new text, edit log, metrics before and after)."""
    blocks = split_blocks(text)
    edits = []
    back = False                                   # a reference list is formatting, not prose: see BACK above
    for i, b in enumerate(blocks):
        if re.match(r'^#{1,6}\s', b.strip()):
            back = bool(BACK.match(b.strip()))
        # a block with list items in it is left alone: v42 writes its items with the continuation lines flush,
        # so an item is not separable from the next by line structure, and the pass would drop the marker
        lists = any(re.match(r'^\s*(?:\d+\.\s|[-*•]\s)', x) for x in b.split('\n'))
        if (not is_prose(b) or back or '$$' in b or any(k in b for k in keep) or lists):
            continue                      # a phrase the author fixed in place protects its whole paragraph                     # a block whose later lines are list items is not one paragraph: the
                                         # markers are part of the paper's numbering and a join would delete them
        if any(LABELLED.match(x) or re.match(r'^(#{1,6}\s|\||\$\$|```|>)', x.strip())
               for x in b.split('\n')[1:]):
            # a block whose later line is a heading, a table row or a display is not one paragraph: the
            # converter reads those lines at their start, so they are kept apart and passed through untouched
            units = [('', x.strip()) for x in b.split('\n') if x.strip()]
            lead_line = True
        else:
            lead_line = False
            units = []
        if not units and quote_lines(b):
            for chunk in re.split(r'\n\s*>\s*\n', b):
                lines = [re.sub(r'^\s*>\s?', '', x).strip() for x in chunk.split('\n') if x.strip()]
                t = ' '.join(lines).strip()
                if t:
                    units.append(('> ', t))
        elif not units and is_list_block(b):
            for line in b.split('\n'):
                m = MARK.match(line)
                if m and line.strip():
                    ind, mk = m.group(1), m.group(2)
                    units.append((f'{ind}{mk} ', line[m.end():]))
                elif line.strip():
                    units.append(('', line.strip()))
        elif not units:
            units.append(('', ' '.join(x.strip() for x in b.split('\n') if x.strip())))
        out = []
        for lead, u in units:
            u = re.sub(r'\s+', ' ', u).strip()
            raw = u
            if not u:
                continue
            if (re.match(r'^(#{1,6}\s|\||\$\$|```)', u) or LABELLED.match(u) or '$$' in u
                    or '\\[' in u or '\\(' in u):
                for rx, rep in (SELFREF if kind == 'article' else SELFREF_X):
                    u = re.sub(rx, rep, u)
                out.append(u)
                continue
            u, _nv = voice(u, kind)
            u = u.replace('newton\u2019metres', 'newton-metres').replace('newton\u2019 metre', 'newton-metre')
            u = re.sub(r'\brather than of\b', 'instead of', u)
            u = re.sub(r'\brather than\b', 'instead of', u)
            u = hypotheses(u)
            u = frames(u, keep)
            u = breathe(u, maxw)
            u = semicolons(u)
            u = breathe(u, maxw)
            u = dashes(u, 200000)                       # spacing first
            u = ground(u)
            u = unbreak(u)
            u = glue_fragments(u)
            u = breathe(u, maxw)
            u = unbreak(u)
            if lint('\n\n'.join([u])) and u != raw:
                u = raw                # the repair left a hole the linter can see: the sentence is put back
            if values(u) != values(raw):
                u = raw                # a register pass may not move a number, not even one it did not mean to
            out.append(lead + u)
        new = ('\n' if (is_list_block(b) or lead_line) else ' ').join(out).strip()
        new = new if lead_line else tidy(new)
        if new != b.strip():
            blocks[i] = new
    out_text = cells(join_blocks(blocks)) if edit_cells else join_blocks(blocks)
    out_text = mark_instances(out_text, mark_budget)
    # the em-dash and frame budgets are global, so they are settled over the finished document
    out_text = apply_document_budgets(out_text, keep, emax, frame_budget)
    out_text = lint_fix(out_text)
    out_text = refill(tidy_blocks(out_text))
    # the document-wide stages after the block loop also edit text (an example marker, a cell, a glued stop), so
    # the log is written by diffing the blocks the pass received against the blocks it returned: every change
    # is recorded, with the index of the block it sits in, which is what makes the reversal exact
    # self-reference is settled last, over the finished text, because it is the one edit that cannot disturb
    # grammar: an article referring to itself says "we", and a companion pointing at the paper says which one
    ref_blocks = split_blocks(out_text)
    for i3, b3 in enumerate(ref_blocks):
        if back_matter(b3) or not is_prose(b3):
            continue
        for rx, rep in (SELFREF if kind == 'article' else SELFREF_X):
            b3 = re.sub(rx, rep, b3)
        ref_blocks[i3] = b3
    out_text = join_blocks(ref_blocks)

    orig = split_blocks(text)
    cur = split_blocks(out_text)
    if len(orig) == len(cur):
        for i2, (a, b) in enumerate(zip(orig, cur)):
            if a == b:
                continue
            if len(lint(b)) > len(lint(a)):
                cur[i2] = a
        out_text = join_blocks(cur)
    before = split_blocks(text)
    after = split_blocks(out_text)
    if len(before) == len(after):
        edits = [(k, a, b) for k, (a, b) in enumerate(zip(before, after)) if a != b]
    else:
        edits = [(-1, text, out_text)]                 # a stage re-flowed blocks; log the file as one edit
    return out_text, edits, stats_of(text), stats_of(out_text)


def cells(text):
    """Table and list cells are prose too, but their geometry is data: inside a `| ... |` row only the wording
    of a cell may change, never its pipes. "X, not Y" and a dash become plain sentences there."""
    out = []
    for line in text.split('\n'):
        if line.lstrip().startswith('|') and line.count('|') >= 3 and (EM in line or ', not ' in line
                                                                       or 'rather than' in line):
            cells_ = line.split('|')
            for i, c in enumerate(cells_):
                if not c.strip() or set(c.strip()) <= set('-: '):
                    continue
                x = c.replace(f' {EM} ', ': ').replace('\u2014', ' - ')
                x = re.sub(r'\brather than\b', 'instead of', x)
                x = re.sub(r',\s*not\s+', '. Not ', x)
                cells_[i] = x
            line = '|'.join(cells_)
        out.append(line)
    return '\n'.join(out)


STRUCT_LINE = re.compile(r'^(?:#{1,6}\s|\||\$\$|```|>\s|\*\*(?:Definition|Lemma|Proposition|Theorem|Corollary|Remark))')


def tidy_blocks(text):
    """Punctuation tidy-up, block by block. ``tidy`` joins a block's lines, so a block that carries a heading,
    a table row, a display or a statement label on a later line is left alone: those lines are read at their
    start by the converter and by the supplementary's inventory, and flattening them is a defect, not a style
    change."""
    blocks = split_blocks(text)
    for i, b in enumerate(blocks):
        if not is_prose(b):
            continue
        lines = b.split('\n')
        if len(lines) > 1 and any(STRUCT_LINE.match(x.strip()) for x in lines[1:]):
            continue
        blocks[i] = tidy(b)
    return join_blocks(blocks)


def mark_instances(text, budget=24):
    """Protocol step 4: one named instance per subsection that makes an applied claim. The instance is
    already in the sentence; the marking only says out loud that it is an example."""
    blocks = split_blocks(text)
    sect = ''
    done = set()
    n = 0
    for i, b in enumerate(blocks):
        if re.match(r'^#{1,6}\s', b.strip()):
            sect = re.sub(r'\W', '', b.strip())[:40]
            continue
        if n >= budget or not is_flow(b) or sect in done:
            continue
        if not INST.search(b) or len(re.findall(r'\d[\d,\.]*', b)) < 1:
            continue
        if re.search(r'for example|for instance', b, re.I):
            continue
        masked, unmask = protect(' '.join(b.split('\n')))
        m = re.match(r'^([-*]\s+|\d+[\.)]\s+)?([A-Z][^.!?]{20,200}?)\.\s', masked)
        if not m:
            continue
        at = masked.index(m.group(2))
        new = unmask(masked[:at] + 'For example, ' + masked[at][0].lower() + masked[at + 1:])
        new = ' '.join(new.split('\n')) if '\n' not in b else new
        blocks[i] = new
        done.add(sect)
        n += 1
    return join_blocks(blocks)


def apply_document_budgets(text, keep, emax, frame_budget):
    blocks = split_blocks(text)
    # em-dashes: walk the document from the least load-bearing dash to the most
    sites = []
    for i, b in enumerate(blocks):
        if not is_prose(b) or '$$' in b or any(k in b for k in keep):
            continue            # a protected sentence keeps its own punctuation; a display is not punctuation
        for m in re.finditer(rf'\s+{EM}\s+', b):
            left, right = b[:m.start()].rstrip(), b[m.end():].lstrip()
            seg = re.split(rf'{EM}|\. ', right, maxsplit=1)[0]
            sites.append((wc(seg) > 8, -min(wc(left), wc(right)), i, m.start(), m.end()))
    sites.sort()
    total = sum(bl.count(EM) for bl in blocks)
    for too_long, _score, i, a, bb in list(sites):
        if total <= emax:
            break
        b = blocks[i]
        if EM not in b:
            continue
        left, right = b[:a].rstrip(), b[bb:].lstrip()
        if not right:
            continue
        keep_low = bool(re.match(r"(?:not|no|nor|but|and|so|or|which|while|although|because|since|rather|only"
                                 r"|even|also|both|either|neither|yet|still|in|on|at|to|for|with|without|the"
                                 r"|a|an|this|that|these|those)\b", right, re.I))
        blocks[i] = left + (', ' + right[0].lower() + right[1:] if not too_long or keep_low
                            else '. ' + capitalise(right))
        total = sum(bl.count(EM) for bl in blocks)
    text = join_blocks(blocks)
    nf = len(re.findall(r'\w, not [\w`"\u2014$]', text))
    if nf > frame_budget:
        blocks = split_blocks(text)
        for i, b in enumerate(blocks):
            if not is_prose(b) or len(re.findall(r'\w, not [\w`"\u2014$]', b)) == 0:
                continue
            nb = frames(b, keep)
            if nb != b:
                blocks[i] = nb
        text = join_blocks(blocks)
    return text


def stats_of(text):
    """The audit's own breath statistics, recomputed here so a build can report both sides."""
    t = re.sub(r'(?s)```.*?```', ' ', text)
    t = re.sub(r'\$\$.*?\$\$', ' ', t)
    t = re.sub(r'[{}$&\\|*_`#]', ' ', t).replace('\n', ' ')
    t = re.sub(r'\s+', ' ', t)
    S = [x for x in re.split(r'(?<=[.!?])\s+(?=[A-Z(])', t) if len(x) > 1 and re.search(r'[A-Za-z]{3}', x)]
    P = [x for x in S if not (x.count('\u00a7') > 3 or x.count('[table]')
                              or sum(bool(re.match(r'[\d\u2248\u00a7]', y)) for y in x.split()) > 0.3 * max(1, len(x.split())))]
    L = sorted(len(x.split()) for x in P)
    if not L:
        return {}
    kw = sum(L) / 1000.0
    n = lambda rx: len(re.findall(rx, t, re.I))
    return dict(sent=len(L), mean=round(st.mean(L), 1), p90=L[int(.9 * len(L)) - 1], mx=L[-1],
                over60=sum(1 for x in L if x > 60), em=t.count(EM), semi=t.count(';'),
                frames=n(r'\w, not [\w`"\u2014$]'), rath=n(r'rather than'),
                we=round((n(r'\bwe\b') + n(r'\bour\b')) / kw, 1), selfref=n(r'\b(?:this|the) article\b'),
                ex=round(n(r'for example|for instance|\be\.g\.') / kw, 1),
                consup=n(r'\bconsider\b|\bsuppose\b'))
def lint(text):
    """What a punctuation pass breaks, made checkable. Every finding comes back with its context, so a repair
    is a one-line edit rather than a hunt. None of these rules is a style opinion: each names a construction
    that cannot occur in correct English, so the count is a floor on the grammar of the pass, not a taste.
    Case matters, so only the doubled-word rule is folded: the audit's own breath statistics rely on full
    stops, and a lowercase letter after one is the signature of a cut in the middle of a clause."""
    bad = []
    for k, b in enumerate(split_blocks(text)):
        if not is_prose(b):
            continue
        t = ' '.join(b.split())
        for rx, flag, why in ((r'\$\$', 0, 'display math inside a prose block'),
                              (r'\b(\w+)\s+\1\b', re.I, 'doubled word'),
                              (r'\s[.,;:]', 0, 'space before punctuation'),
                              (r'\.\s*[.,;:]', 0, 'stop stack'),
                              (r'[.!?]\s+[a-z](?!ttps?://|doi:|www\.)', 0, 'lowercase after a full stop'),
                              (r'(?<=[.!?]\s)(?:is|was|were|been|being|gives|giving|leaving|making|showing|'
                               r'holding|putting|called|named|denoted|written|reads|taken|using|needed)\s+\w',
                               0, 'verb with no subject'),
                              (r'(?<=[.!?]\s)are\s', 0, 'plural verb with no subject'),
                              (r'^\s*[.,;:]', 0, 'block opens with punctuation'),
                              (r'\b(?:are|is|was|were)\s+(?:this|these|the)\s+(?:section|paper|file)s?\s*$',
                               0, 'verb stranded at the block end')):
            for m in re.finditer(rx, t, flag):
                if why == 'doubled word' and m.group(1).lower() in {'that', 'had', 'very', 'the'}:
                    continue
                if why == 'lowercase after a full stop':
                    pre = t[:m.start()].rstrip()
                    # a numbered or lettered item, and an abbreviation, both put a full stop before lowercase
                    # as their own convention: that is formatting, not a sentence that lost its capital
                    if re.search(r'(?:^|\s)(?:\(\d+\)|\d{1,2}|[a-z])[.,]$', pre):
                        continue
                    if re.search(r'\b(?:no|nos|vol|vols|fig|figs|eq|eqs|pp|p|sec|secs|section|sections|'
                                 r'table|tables|appendix|appendices|plate|ref|refs|e\.g|i\.e|cf|vs|et al)[.,]$',
                                 pre, re.I):
                        continue
                bad.append((why, k, t[max(0, m.start() - 44):m.end() + 44]))
        if t.count('(') != t.count(')') and '`' not in t and '$' not in t:
            bad.append(('unbalanced parentheses', k, t[:70]))
        if t.count('$') % 2:
            bad.append(('unbalanced inline math', k, t[:70]))
        if t.count('`') % 2:
            bad.append(('unbalanced code span', k, t[:70]))
    return bad


STUCK = (r'are|is|was|were|been|being|giving|leaving|making|showing|holding|called|named|denoted|written|'
         r'taken|used|needed|reads')


def lint_fix(text):
    """The mechanical part of the repair: the artefacts a punctuation pass leaves behind are glued back, and
    only those. Anything the linter still reports is left for a reader, which the gate refuses to ship.

    The repairs all act on a space before a stop, which is exactly what a TeX display leaves before its period
    (``\\,dt .``), so every formula and every code span is lifted out first and put back afterwards."""
    holes = []

    def hide(m):
        holes.append(m.group(0))
        return f'\x04{len(holes) - 1}\x04'

    text = re.sub(r'(?s)\$\$.*?\$\$|\\\[.*?\\\]|`[^`\n]*`|\$[^$\n]*\$', hide, text)
    for _ in range(300):
        new = re.sub(r'([A-Za-z\u2019\)\]]+)\.\s+(' + STUCK + r')\b',
                     lambda m: (m.group(1) + ('; ' if m.group(2) in {'are', 'is', 'was', 'were'} else ', ')
                                 + m.group(2)), text, count=1)
        new = re.sub(r'(\d)\.\.(\d)', r'\1.\2', new)
        new = re.sub(r'\.\s*([,;:])', r'\1', new)
        new = re.sub(r'([A-Za-z\u2019\)\]])\s+([,;.])', r'\1\2', new)
        new = re.sub(r'\.\.(?![.0-9])', '.', new)
        if new == text:
            break
        text = new
    return re.sub(r'\x04(\d+)\x04', lambda m: holes[int(m.group(1))], text)
