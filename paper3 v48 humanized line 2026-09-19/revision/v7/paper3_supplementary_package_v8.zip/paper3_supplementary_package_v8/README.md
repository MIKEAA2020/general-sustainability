# Supplementary package

Materials accompanying "Typed Flux Ledgers and Depletion Arithmetic: Conservation, Componentwise Diagnostics,
and the Semantics of Depletion Horizons" (Amin Abaee, independent researcher; ORCID 0000-0002-0019-1842).

## What the supplementary is

The supplementary material is one document and two records beside it.

* **The supplementary document** is `manuscript/paper3_supplementary_v18.pdf` (19 pp., sections S1 to S17). It
  carries the proofs, derivations, parameter tables, the version-sensitivity record and the reproduction protocol
  that the main text cites by section number: the lemmas and propositions stated without proof in the article, the
  exhibit values behind each figure it quotes, the record of which public release each number comes from, and the
  section that reports the overshoot-date recomputation (S17). It is typeset from `paper3_supplementary_v18.md`,
  whose ASCII transliteration `paper3_supplementary_v18.ascii.md` is included because that is the source the
  typesetter reads. Its role is checking, not argument: it reports what was verified and by which operation, which
  deviations from the standard are documented and on what grounds, which statements the record supports and at what
  predicate, and what remains unresolved. Proofs are given to the depth at which a reader can re-do a step with a
  calculator and the tables in this archive, and where a step is stated rather than demonstrated the text says so.
* **The exhibit bundle** is `code/`: three scripts that regenerate every computed figure in the article and the
  supplementary, the manifest that records what each reads and what it does not, and the output record of one run.
* **The analysis record** is `analysis/nfa_tau/`: the recomputation of the aggregate overshoot date with and
  without carbon demand on two editions of the National Footprint and Biocapacity Accounts, with its own README
  and manifest.

The two records differ in what a reader needs in order to repeat them. The exhibit bundle runs on synthesised
inputs and nothing else, and it asserts that the article's computed figures reproduce; the analysis record runs on
the two edition tables of the accounts and asserts that the overshoot date recomputes under the weighting its README
states. Neither needs the other, and neither needs the network.

The main text and the two companion papers are included so that cross-references resolve inside the archive. The
companions are papers in their own right, not appendices: `companionA_certification_procedure_v9.pdf` specifies
the certification procedure the article's predicates define, and `companionB_standards_horizon_v9.pdf` places the
accounting objects against the standards horizon.

## Contents

     7,246 B  `analysis/nfa_tau/README.md`
       224 B  `analysis/nfa_tau/checksums.txt`
    11,237 B  `analysis/nfa_tau/edition_delta.csv`
    14,894 B  `analysis/nfa_tau/recompute_tau.py`
     4,584 B  `analysis/nfa_tau/results.txt`
     3,354 B  `analysis/nfa_tau/source/MANIFEST.md`
    15,324 B  `analysis/nfa_tau/tau_by_year_2017edition.csv`
    15,205 B  `analysis/nfa_tau/tau_by_year_2018edition.csv`
    19,132 B  `builders/build_v42_formal.py`
    16,382 B  `builders/build_v42_package.py`
    57,506 B  `builders/build_v47_gbase.py`
    68,600 B  `builders/build_v48_base.py`
   301,748 B  `builders/claim_ledger_v1.csv`
   968,025 B  `builders/claim_ledger_v1.json`
   117,307 B  `builders/claim_ledger_v1.md`
    53,047 B  `builders/claim_ledger_v1.py`
    21,533 B  `builders/claim_ledger_v1_attribution_review.md`
    48,249 B  `builders/claim_ledger_v1_complement.csv`
     9,495 B  `builders/claim_ledger_v1_complement.md`
    11,053 B  `builders/claim_ledger_v1_mutation_test.md`
       624 B  `builders/geometry_v42.json`
    13,989 B  `builders/mdtex_v1.py`
   225,299 B  `builders/paper3_material_ledgers_v47_prebaseline.md`
   225,299 B  `builders/paper3_material_ledgers_v48_prebaseline.md`
    10,997 B  `builders/revisions_v42_formal_log.json`
   463,289 B  `builders/revisions_v47_base_log.json`
   426,088 B  `builders/revisions_v48_base_log.json`
    12,359 B  `builders/structure_v42.md`
     4,448 B  `builders/structure_v47_base.md`
    10,004 B  `builders/structure_v48_base.md`
   118,945 B  `builders/stylekit_v1.py`
     9,488 B  `builders/tablekit_v2.py`
    12,573 B  `builders/texkit_v1.py`
     2,154 B  `builders/v48_audit_selftest.md`
     6,150 B  `builders/v48_audit_selftest_v1.py`
    16,735 B  `builders/v48_notation_drift.md`
    10,153 B  `builders/v48_notation_drift_v1.py`
       301 B  `builders/v48_overrules.csv`
     6,259 B  `builders/v48_pointer_read.md`
   280,008 B  `builders/v48_pointers.json`
    11,751 B  `builders/v48_pointers_v1.py`
    12,688 B  `builders/v48_readme_v1.py`
   139,276 B  `builders/v48_reuse_audit.csv`
   377,923 B  `builders/v48_reuse_audit.json`
    19,210 B  `builders/v48_reuse_audit_v1.py`
    15,977 B  `builders/v48_reuse_findings.md`
    10,497 B  `builders/v48_reuse_findings_v1.py`
    10,264 B  `builders/v48_reuse_read.md`
   463,866 B  `builders/v48_reuse_split.json`
     4,331 B  `builders/v48_reuse_split.md`
    13,669 B  `builders/v48_reuse_split_v1.py`
    63,875 B  `builders/v48_splice_log.json`
    18,011 B  `builders/v48_splice_v1.py`
    25,714 B  `builders/verify_v42_build.py`
    40,096 B  `builders/verify_v47_base.py`
    19,956 B  `builders/verify_v48_base.py`
     3,103 B  `code/MANIFEST.md`
     5,048 B  `code/certification_lp.py`
     3,281 B  `code/curvature_and_crossover.py`
     5,388 B  `code/outputs.txt`
     2,225 B  `code/persistence_index_simulation.py`
    31,254 B  `manuscript/companionA_certification_procedure_v9.md`
    94,163 B  `manuscript/companionA_certification_procedure_v9.pdf`
    38,645 B  `manuscript/companionA_certification_procedure_v9.tex`
    27,190 B  `manuscript/companionB_standards_horizon_v9.md`
    89,433 B  `manuscript/companionB_standards_horizon_v9.pdf`
    30,405 B  `manuscript/companionB_standards_horizon_v9.tex`
   217,920 B  `manuscript/paper3_material_ledgers_v48.md`
   388,840 B  `manuscript/paper3_material_ledgers_v48.pdf`
   236,672 B  `manuscript/paper3_material_ledgers_v48.tex`
    59,955 B  `manuscript/paper3_supplementary_v18.ascii.md`
    59,801 B  `manuscript/paper3_supplementary_v18.md`
   175,746 B  `manuscript/paper3_supplementary_v18.pdf`
    73,881 B  `manuscript/paper3_supplementary_v18.tex`

## Verifying it

`MANIFEST.sha256` holds a hash of every file in this archive:

```
sha256sum -c MANIFEST.sha256          # in the top directory of the unpacked archive
```

The exhibit bundle needs nothing further; run the three scripts and compare their stdout with `code/outputs.txt`.
The analysis record reads two edition tables of the accounts which, as its own manifest states, are held for
re-running and are not redistributed here. Fetch them by the two commands recorded in
`analysis/nfa_tau/source/MANIFEST.md`, place them in `analysis/nfa_tau/source/`, then

```
cd analysis/nfa_tau && python3 recompute_tau.py
```

The script verifies the bytes it reads against the hashes recorded there, and reproduces
`tau_by_year_2018edition.csv`, `tau_by_year_2017edition.csv`, `edition_delta.csv` and `results.txt` byte for byte.

The scripts in `builders/` regenerate the typesetting and the checks from the markdown sources: `tectonic`
compiles each `.tex`, and `python3 builders/verify_v48_base.py` re-runs every check the line is built on.

These files are the v48 line of the same paper. v47 took the author's humanized draft as the document and
grafted this paper's verified content into it. v48 keeps the goal - the author's own prose, not a style
approximation of it - and replaces the method. Nothing is carried from the draft because a paragraph reads
alike. What may be carried is decided one sentence at a time by a claim ledger
(`builders/claim_ledger_v1.py`) that pairs every sentence of the draft asserting a fact, claim, hedge,
scope or attribution with the proposition of the deposited article it rests on, and marks it supported,
drifted, contradicted or not stated; the author adjudicates that ledger and the pipeline does not. The 290
sentences the ruling cleared for reuse are in as the draft wrote them - the splice placed 208, 19 of those carry a figure the article states somewhere else, and the rest of the set
(82) could not be placed: 33 are halves of sentences the extractor cut at a display, 17 run
through a display or a table, 23 are not in the document verbatim once the ledger's line filters are applied, and
4 were refused because the sentence that follows the one they replace takes its antecedent from it, and
2 have no deposit sentence to stand in for. They ship from the deposited article, which is where this
method is deliberately conservative. The 268 sentences the ruling sent back were regenerated from the
deposit in the draft's register (188 on a medium or low match, 64 flagged by a line-by-line read of the
reuse set against the passage each was paired with, 16 the author overruled out of reuse over a notation
defect). 17 of the reused sentences the register pass rewrote were set back to the draft's wording after it,
and 2 row(s) were refused because the swap would have retitled a stated proposition - a label is the
document, not prose.

The reuse is disclosed as screened, not certified. 1 swap was refused because it would have
left a figure unstated. The 8 figures named in `builders/v48_splice_log.json` changed separator
style and nothing else, because the draft writes `240,000` in text where the deposit keeps its maths as `240{,}000`,
and no arithmetic was re-typed to make the two agree. Eight rows carry a defect found by
the line read or the pointer read. 7 of the eight were placed, so they ship reused against that
recorded recommendation: D0158 (`each` for the deposit’s `every`); D0129 (the review cycle that closes at the rate of use); D0108 (the only `Survey (USGS)` expansion); D0309 (the locator `S6`); D0530 (the phrase `recorded in S5`); D0618 (the locators `S2` and `S14`); D0620 (the same locators again).
The other 1 (D0089) were not placed by the splice, so the deposited wording stands there -
the outcome the recommendation asked for, reached by a guard rather than by a ruling, and reported as such rather
than counted as a fix. Each of the eight is named in `builders/structure_v48_base.md` with what it lost,
and none of them is repaired behind the author's back. The one draft
sentence with no counterpart in the deposit (D0081) was regenerated at the deposit's scope rather than kept.
Reused prose keeps the draft's own symbols where they differ typographically from the article's, because
normalising an author's sentences at build time is the pipeline deciding content; `builders/v48_notation_drift.md` and
`builders/v48_reuse_findings.md` are the row-by-row record of what that means, and the 16 rows it concerns are the
ones the author then overruled.

Measured on the shipped text: 166 of 670 flowing prose sentences are verbatim in the draft, against
101 of 767 in the deposited article they replace, and the distance to the draft’s own register profile fell from 36.8 units to 28.6; the accepted v47 line reached 21.8 by carrying draft paragraphs
whole that this line has since sent back for regeneration, so the difference is the price of the ruling and is
stated rather than tuned away. The features that moved away from the draft along the way are em-dashes, the ", not Y" frame, parentheses,
and the build note gives each number; where they sit above or below the draft's rate it is the punctuation of
retained deposit prose, which no pass is entitled to re-cut for a metric. The gate passes on all of it: no value
the paper states has gone unstated and none has been invented; the 70 table rows, 79 displayed equations,
63 statement labels, 74 heading lines and the whole of the back matter are byte-identical to the
verified line; the 20 figures whose count differs between the two texts are the merge of two documents, reported and
not adjusted; every placed sentence is verbatim up to the two document conventions the ruling itself imposes;
no regenerated row ships the draft's wording unless the deposit already carried it; and the compiled article prints on
54 pages with no overfull box, no unresolved reference, and all 250 of its flowing paragraphs on the page.

The bibliography question the last two lines turned on is answered the same way here. The reference list, the
availability statements and the declarations belong to the document, so the article's own list is carried
untouched and the draft's reflowed list is not adopted: the draft's came out of a PDF text layer, which
dropped the year letters that separate this author's 2026 papers and glued entries together. That is reported,
not repaired. In-text self-reference is the document's too, which is why the citation-status wording and the
article-names-itself map run after the splice and reach reused sentences as well as regenerated ones.

## Licences and terms

* Text, figures and scripts: CC BY 4.0, attributing the article above.
* The two edition tables are Global Footprint Network data under CC BY-SA 4.0 and are redistributed by their
  publisher, not here; the attribution the deposits request is recorded in the analysis manifest.
* `code/` consumes no external data. `analysis/nfa_tau/` reads the two tables and nothing else.
* No personal data, no third-party proprietary code.

## Notes on the text

Numbers in the article and the supplementary are recomputed, not transcribed, where a public release allowed it;
the three that were (the persistence-index exhibit, the two-cohort reserve-life medians and the overshoot
recomputation) are each tied to a named release and a re-runnable script in the sections above. Where a release
could not be reached without registration, that is stated at the number rather than at the end.
