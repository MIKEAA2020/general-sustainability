# Supplementary package

Materials accompanying "Typed Flux Ledgers and Depletion Arithmetic: Conservation, Componentwise Diagnostics,
and the Semantics of Depletion Horizons" (Amin Abaee, independent researcher; ORCID 0000-0002-0019-1842).

## What the supplementary is

The supplementary material is one document and two records beside it.

* **The supplementary document** is `manuscript/paper3_supplementary_v13.pdf` (19 pp., sections S1 to S17). It
  carries the proofs, derivations, parameter tables, the version-sensitivity record and the reproduction protocol
  that the main text cites by section number: the lemmas and propositions stated without proof in the article, the
  exhibit values behind each figure it quotes, the record of which public release each number comes from, and the
  section that reports the overshoot-date recomputation (S17). It is typeset from `paper3_supplementary_v13.md`,
  whose ASCII transliteration `paper3_supplementary_v13.ascii.md` is included because that is the source the
  typesetter reads. Its role is checking, not argument: it reports what was verified and by which operation, which
  deviations from the standard are documented and on what grounds, which statements the record supports and at what
  predicate, and what remains unresolved. Proofs are given to the depth at which a reader can re-do a step with a
  calculator and the tables in this archive, and where a step is stated rather than demonstrated the text says so.
* **The exhibit bundle** is `code/`: three scripts that regenerate every computed figure in the article and the
  supplementary, the manifest that records what each reads and what it does not, and the output record of one run.
* **The analysis record** is `analysis/nfa_tau/`: the recomputation of the aggregate overshoot date with and
  without carbon demand on two editions of the National Footprint and Biocapacity Accounts, with its own README
  and manifest.

The two records differ in what a reader needs in order to repeat them. The exhibit bundle runs on synthesised
inputs and nothing else, and it asserts that the article's computed figures reproduce; the analysis record runs on
the two edition tables of the accounts and asserts that the overshoot date recomputes under the weighting its README
states. Neither needs the other, and neither needs the network.

The main text and the two companion papers are included so that cross-references resolve inside the archive. The
companions are papers in their own right, not appendices: `companionA_certification_procedure_v4.pdf` specifies
the certification procedure the article's predicates define, and `companionB_standards_horizon_v4.pdf` places the
accounting objects against the standards horizon.

## Contents

     7,246 B  `analysis/nfa_tau/README.md`
       224 B  `analysis/nfa_tau/checksums.txt`
    11,237 B  `analysis/nfa_tau/edition_delta.csv`
    14,894 B  `analysis/nfa_tau/recompute_tau.py`
     4,584 B  `analysis/nfa_tau/results.txt`
     3,354 B  `analysis/nfa_tau/source/MANIFEST.md`
    15,324 B  `analysis/nfa_tau/tau_by_year_2017edition.csv`
    15,205 B  `analysis/nfa_tau/tau_by_year_2018edition.csv`
    19,132 B  `builders/build_v42_formal.py`
    16,382 B  `builders/build_v42_package.py`
       624 B  `builders/geometry_v42.json`
    10,997 B  `builders/revisions_v42_formal_log.json`
    12,359 B  `builders/structure_v42.md`
     9,488 B  `builders/tablekit_v2.py`
    12,573 B  `builders/texkit_v1.py`
    25,719 B  `builders/verify_v42_build.py`
     3,103 B  `code/MANIFEST.md`
     5,048 B  `code/certification_lp.py`
     3,281 B  `code/curvature_and_crossover.py`
     5,388 B  `code/outputs.txt`
     2,225 B  `code/persistence_index_simulation.py`
    31,018 B  `manuscript/companionA_certification_procedure_v4.md`
    93,859 B  `manuscript/companionA_certification_procedure_v4.pdf`
    38,368 B  `manuscript/companionA_certification_procedure_v4.tex`
    26,852 B  `manuscript/companionB_standards_horizon_v4.md`
    89,025 B  `manuscript/companionB_standards_horizon_v4.pdf`
    30,091 B  `manuscript/companionB_standards_horizon_v4.tex`
   224,482 B  `manuscript/paper3_material_ledgers_v42.md`
   394,447 B  `manuscript/paper3_material_ledgers_v42.pdf`
   241,086 B  `manuscript/paper3_material_ledgers_v42.tex`
    59,646 B  `manuscript/paper3_supplementary_v13.ascii.md`
    59,492 B  `manuscript/paper3_supplementary_v13.md`
   175,542 B  `manuscript/paper3_supplementary_v13.pdf`
    73,671 B  `manuscript/paper3_supplementary_v13.tex`

## Verifying it

`MANIFEST.sha256` holds a hash of every file in this archive:

```
sha256sum -c MANIFEST.sha256          # in the top directory of the unpacked archive
```

The exhibit bundle needs nothing further; run the three scripts and compare their stdout with `code/outputs.txt`.
The analysis record reads two edition tables of the accounts which, as its own manifest states, are held for
re-running and are not redistributed here. Fetch them by the two commands recorded in
`analysis/nfa_tau/source/MANIFEST.md`, place them in `analysis/nfa_tau/source/`, then

```
cd analysis/nfa_tau && python3 recompute_tau.py
```

The script verifies the bytes it reads against the hashes recorded there, and reproduces
`tau_by_year_2018edition.csv`, `tau_by_year_2017edition.csv`, `edition_delta.csv` and `results.txt` byte for byte.

The scripts in `builders/` regenerate the typesetting and the checks from the markdown sources: `tectonic`
compiles each `.tex`, and `python3 builders/verify_v42_build.py` re-runs the verification described in
`builders/structure_v42.md`. They are the production machinery, not part of the text.

## Licences and terms

* Text, figures and scripts: CC BY 4.0, attributing the article above.
* The two edition tables are Global Footprint Network data under CC BY-SA 4.0 and are redistributed by their
  publisher, not here; the attribution the deposits request is recorded in the analysis manifest.
* `code/` consumes no external data. `analysis/nfa_tau/` reads the two tables and nothing else.
* No personal data, no third-party proprietary code.

## Notes on the text

Numbers in the article and the supplementary are recomputed, not transcribed, where a public release allowed it;
the three that were (the persistence-index exhibit, the two-cohort reserve-life medians and the overshoot
recomputation) are each tied to a named release and a re-runnable script in the sections above. Where a release
could not be reached without registration, that is stated at the number rather than at the end.
