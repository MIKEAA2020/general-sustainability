Paper 2 v48 source package: main tex+pdf, supplementary (v46, unchanged),
all figures, the coverage-audit script, and the two exact-arithmetic
verification records (v46 LP-instantiation/decomposition; v47 two-patch audit
and belief-state safety values). v48 is the editorial-sweep revision: three
accepted edits, dispositions in the v48 addendum; no numerical claims changed.
Run: python3 paper2_coverage_audit.py (numpy, matplotlib);
python3 paper2_v46_a5a6_verification.py; python3 paper2_v47_verification.py
(standard library only).
Mirror: https://github.com/MIKEAA2020/general-sustainability
