# E1 reproducibility package — paperE1 cod (v62 series)

Companion to: Abaee (2026), "Forecasting biomass under structural non-stationarity:
an out-of-sample evaluation of surplus-production models for Northern cod
(Gadus morhua)", Fisheries Research (v62 series), and its Supplementary Information.

## Contents
- `wave_e_cod/src/`        scoring engine (`run_ladder.py`, untouched) + Spec B/capelin scripts
- `wave_e_cod/data/`       all input series (NCAM Table A2 SSB, Schijns et al. 2021 landings
                           and Table 3 RV autumn survey index 1983-2015, xteNCAM Table 17, DFO landings, capelin 3L)
- `wave_e_cod/results/`    frozen reference outputs for Spec A and Spec B
- `campaigns/`             post-freeze layers: DM + moving-block bootstrap (Spec A/B),
                           the pre-registered Spec C survey-target campaign, and its q# sensitivity run
- `campaigns/results/`     frozen outputs of the campaign layer
- `phase_c/`               simulation layer cited in Section 3.7 and Section 4.3
                           (power, misspecification D6/D7, smoother re-runs, origins, SNR)
- `phase_c/results/`       frozen simulation artifacts with provenance JSONs
- `docs/`                  pre-registered Spec C design (frozen before any score was read)
                           + the Supplementary Information (markdown)
- `verify_package.py`      end-to-end verification (runs everything in a scratch copy; see below)

## Environment
Deterministic under python 3.13 with numpy 2.3.5, pandas 2.2.3,
scipy 1.17.1 (versions recorded at packaging, Linux).
No GUI, no network access needed at run time. Randomness is pinned (seed 0, 20,000
bootstrap replications) inside the scripts.

## Verify
    python verify_package.py
Copies the package to a scratch directory, executes run_ladder.py (Spec A and B engine),
the survey-target campaign, the q# sensitivity, and the DM layers, then diffs md5s of
every regenerated output against the frozen copies in this package. First run takes a
few minutes (two 20,000-replication bootstrap layers). Exit code 0 = byte-identical.

To run the engine manually, copy the whole tree first (scripts write next to their inputs):
    cp -r E1_REPRODUCIBILITY_PACKAGE_v62 /tmp/pkg && cd /tmp/pkg
    python wave_e_cod/src/run_ladder.py
    python campaigns/campaign_e1_survey_target.py
    python campaigns/campaign_e1_survey_qsensitivity.py
    python campaigns/campaign_e1_dm_uncertainty.py

A note on float determinism: byte-identity is guaranteed on the pinned stack above; on
other library versions, optimiser iterations may differ in the last digits of fitted
parameters. Verdicts (retention sets, rankings, DM signs) are robust to such perturbations
by construction, as the q# sensitivity layer demonstrates for scale parameters.
