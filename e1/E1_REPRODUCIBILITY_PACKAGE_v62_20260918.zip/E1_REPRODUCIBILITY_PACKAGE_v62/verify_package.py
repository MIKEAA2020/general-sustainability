#!/usr/bin/env python3
"""Re-execute the deterministic layers of this package in a scratch copy and
md5-diff every regenerated output against its frozen archived copy."""
import hashlib, os, shutil, subprocess, sys, tempfile
PKG = os.path.dirname(os.path.abspath(__file__))
PAIRS = [
    ("campaigns/results/e1_survey_target_rolling_forecasts.csv", ["campaigns/campaign_e1_survey_target.py"]),
    ("campaigns/results/e1_survey_target_rolling_summary.csv", []),
    ("campaigns/results/e1_survey_target_fixed_window_scores.csv", []),
    ("campaigns/results/e1_survey_dm_uncertainty.csv", []),
    ("campaigns/results/e1_survey_qsensitivity.csv", ["campaigns/campaign_e1_survey_qsensitivity.py"]),
    ("campaigns/results/e1_dm_uncertainty.csv", ["campaigns/campaign_e1_dm_uncertainty.py"]),
]
def md5(p):
    h=hashlib.md5()
    with open(p,'rb') as f:
        for ch in iter(lambda: f.read(1<<20), b''): h.update(ch)
    return h.hexdigest()
with tempfile.TemporaryDirectory() as t:
    work=os.path.join(t,'pkg'); shutil.copytree(PKG, work)
    seen=set()
    for rel, cmds in PAIRS:
        for c in cmds:
            if c in seen: continue
            seen.add(c)
            print('run', c, '...'); sys.stdout.flush()
            r=subprocess.run([sys.executable, c], cwd=work, capture_output=True, text=True)
            if r.returncode: print(r.stdout[-2000:], r.stderr[-2000:]); sys.exit(1)
        a=md5(os.path.join(PKG,rel)); b=md5(os.path.join(work,rel))
        print(rel, 'BYTE-IDENTICAL' if a==b else 'DIFFERS', a[:8])
        if a!=b: sys.exit(2)
print('VERIFY OK: all listed outputs byte-identical')
